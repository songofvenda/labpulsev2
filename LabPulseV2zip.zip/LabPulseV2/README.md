# LabPulse V2 — laboratory operations intelligence

Prototype for UDBHAV 1.0 (Diagnostic Lab Equipment Downtime & Reagent Wastage Predictor).
Synthetic data only. Not clinically validated.

## Run the demo

Double-click `run-demo.bat`, or:

```
cd web
python -m http.server 8765 --bind 127.0.0.1
```

Then open http://127.0.0.1:8765. Everything is local; no internet is needed. `web/index.html` also opens directly from the file system.

## Regenerate the data and models

```
set OPENBLAS_NUM_THREADS=1
python ml/pipeline.py        (about 1 minute; needs numpy, pandas, scikit-learn, scipy)
node ml/report.js            (prints model metrics)
node ml/check_engine.js      (sanity-checks the browser engines)
```

The pipeline is seeded, so results are reproducible. It needs roughly 500 MB of free memory.

## Layout

| Path | What |
|---|---|
| `ml/pipeline.py` | Synthetic data generator, failure-risk model, anomaly baseline, demand forecast, reagent policy back-test, export |
| `data/` | The four synthetic datasets as CSV |
| `web/data/lp-data.js` | Everything the app reads, produced by the pipeline |
| `web/js/engine.js` | Reagent twin, pre-load advisor, reorder levels, decision engine, savings (rule-based, deterministic) |
| `web/js/analyzer3d.js` | Procedural 3D analyzer and laboratory floor (three.js) |
| `web/js/views-*.js` | The eight screens |
| `docs/` | One-page summary, demo script, plan |

## Screens

Command centre · Analyzer twin · Decision engine · Reagent twins · Cold chain and stores · Savings and return · Model evidence · Adoption path
