"""
LabPulse V2 - synthetic data + model pipeline (UDBHAV 1.0 prototype)

Generates four synthetic datasets (no real patient or hospital data), trains and
honestly evaluates the models, and exports everything the web app needs.

  1. Equipment telemetry  - 24 biochemistry analyzers x 540 days, hourly
  2. Failure / maintenance events
  3. Test-volume logs     - 16 assays x 540 days
  4. Reagent inventory    - lot-level, with manufacturer stability rules

Run:  python ml/pipeline.py        (from the LabPulseV2 folder)
"""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
import json, math, sys
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor, IsolationForest
from sklearn.metrics import average_precision_score
from scipy.signal import lfilter
from sklearn.isotonic import IsotonicRegression

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RNG = np.random.default_rng(20261118)

END = pd.Timestamp("2026-11-18 06:00")      # demo "now"
DAYS, FUT = 540, 21                          # history + hidden future (simulator ground truth)
START = END - pd.Timedelta(days=DAYS)
H = (DAYS + FUT) * 24
NOW_H = DAYS * 24
TS = pd.date_range(START, periods=H, freq="h")
HOD = TS.hour.values
DOY = TS.day_of_year.values
DOW = TS.day_of_week.values
DATE0 = START.normalize()
CAL_DAY = ((np.arange(H) + 6) // 24)         # calendar-day index of each hour

# ----------------------------------------------------------------------------
# 1. TEST-VOLUME LOGS (daily, per assay, lab-wide for the demo site)
# ----------------------------------------------------------------------------
# Stability / pack values are ILLUSTRATIVE of typical package inserts, not taken
# from any specific manufacturer IFU. A deployment loads the real IFU rules.
ASSAYS = [
    # code, name, panel, base/day, bottle tests (L), price L, onboard d, open-vial d, cal d, cal tests, qc/day, dead, small pack tests
    ("GLU",  "Glucose (GOD-POD)",        "Diabetes", 150, 800, 2400, 30, 60, 30, 6, 4, 15, 300),
    ("UREA", "Urea (Urease-GLDH)",       "Renal",    120, 600, 2700, 28, 45, 14, 6, 4, 12, 250),
    ("CREA", "Creatinine (Jaffe)",       "Renal",    130, 600, 2400, 21, 30, 7,  6, 4, 12, 250),
    ("ALT",  "ALT / SGPT",               "Liver",     95, 500, 3500, 28, 45, 30, 6, 4, 10, 200),
    ("AST",  "AST / SGOT",               "Liver",     95, 500, 3500, 28, 45, 30, 6, 4, 10, 200),
    ("ALP",  "Alkaline phosphatase",     "Liver",     60, 400, 2600, 21, 30, 14, 6, 4, 10, 150),
    ("TBIL", "Bilirubin total",          "Liver",     70, 400, 2800, 21, 30, 14, 6, 4, 10, 150),
    ("DBIL", "Bilirubin direct",         "Liver",     40, 300, 2400, 14, 21, 14, 6, 4, 8,  100),
    ("CHOL", "Cholesterol total",        "Lipid",     70, 500, 4000, 28, 45, 30, 6, 4, 10, 200),
    ("TG",   "Triglycerides",            "Lipid",     70, 500, 6000, 28, 45, 30, 6, 4, 10, 200),
    ("HDL",  "HDL cholesterol (direct)", "Lipid",     55, 300, 9000, 28, 30, 30, 6, 4, 8,  100),
    ("CRP",  "C-reactive protein",       "Inflammation", 41, 760, 21280, 14, 21, 14, 8, 4, 10, 250),
    ("HBA1C","HbA1c (immunoturbidimetric)","Diabetes", 30, 300, 24000, 30, 30, 30, 8, 4, 8, 100),
    ("AMY",  "Amylase",                  "Pancreatic", 12, 300, 9000, 21, 30, 21, 6, 4, 8, 100),
    ("LIP",  "Lipase",                   "Pancreatic",  8, 200, 14000, 14, 21, 14, 6, 4, 6, 60),
    ("CKMB", "CK-MB",                    "Cardiac",     6, 200, 16000, 14, 21, 14, 6, 4, 6, 60),
]
A_COLS = ["code", "name", "panel", "base", "bottle", "price", "obs", "openVial", "calDays", "calTests", "qcPerDay", "dead", "smallBottle"]
ASSAY = [dict(zip(A_COLS, a)) for a in ASSAYS]
for a in ASSAY:
    a["smallPrice"] = int(round(a["price"] / a["bottle"] * a["smallBottle"] * 1.12, -1))   # small pack costs ~12% more per test
    a["perTest"] = round(a["price"] / a["bottle"], 2)
    a["excursionBudgetH"] = 4 if a["code"] in ("TG", "LIP", "CKMB") else 8             # cumulative hours allowed at 8-25 C (illustrative)
    a["shelfMonths"] = 12 if a["code"] in ("CRP", "HBA1C", "CKMB", "LIP") else 18

MENU = {   # which analyzers are validated for which assay (vendor-agnostic, open-system reagents)
    "BA-01": [a["code"] for a in ASSAY],
    "BA-02": [a["code"] for a in ASSAY if a["code"] not in ("HBA1C", "CKMB")],
    "BA-03": [a["code"] for a in ASSAY if a["code"] not in ("HBA1C", "CKMB", "CRP")],
}
ND = DAYS + 61
DATES = pd.date_range(DATE0, periods=ND, freq="D")
HOLIDAYS = pd.to_datetime(["2025-08-15", "2025-08-27", "2025-10-02", "2025-10-20", "2025-10-21", "2025-12-25", "2026-01-01",
                           "2026-01-26", "2026-03-04", "2026-03-21", "2026-08-15", "2026-09-14", "2026-10-02",
                           "2026-11-08", "2026-11-09", "2026-12-25", "2027-01-01"])
CAMPS = pd.to_datetime(["2025-11-14", "2025-11-15", "2026-04-07", "2026-04-08", "2026-11-13", "2026-11-14"])  # screening camps (known in advance)
DOWF = np.array([1.08, 1.0, 1.0, 0.98, 0.97, 0.8, 0.35])


def gen_demand():
    dow = DATES.day_of_week.values
    doy = DATES.day_of_year.values
    t = np.arange(ND)
    hol = np.isin(DATES, HOLIDAYS)
    camp = np.isin(DATES, CAMPS)
    monsoon = np.exp(-((doy - 235) / 42.0) ** 2)
    out = {}
    for a in ASSAY:
        season = np.ones(ND)
        if a["panel"] == "Liver":
            season += 0.25 * monsoon
        if a["code"] == "CRP":
            season += 0.60 * np.exp(-((doy - 250) / 50.0) ** 2)
        if a["panel"] == "Renal":
            season += 0.10 * np.exp(-((doy - 140) / 35.0) ** 2)      # summer dehydration / AKI
        mu = a["base"] * DOWF[dow] * season * (1 + 0.08 * t / DAYS)
        mu = np.where(hol, mu * 0.4, mu)
        if a["panel"] in ("Diabetes", "Lipid"):
            mu = np.where(camp, mu * 1.9, mu)
        k = 30.0                                                       # negative-binomial dispersion
        lam = RNG.gamma(k, mu / k)
        out[a["code"]] = RNG.poisson(lam).astype(float)
    return pd.DataFrame(out, index=DATES), hol, camp


DEMAND, HOL, CAMP = gen_demand()
LAB_TOTAL = DEMAND.sum(axis=1).values

# ----------------------------------------------------------------------------
# 2. EQUIPMENT TELEMETRY + FAILURE EVENTS
# ----------------------------------------------------------------------------
MODELS = {
    "Mindray BS-480": dict(bath=37.00, probe=62.0, vib=1.10, pow=950.0, bay=5.0, blank=22.0, thr=400),
    "Erba XL-640":    dict(bath=37.10, probe=55.0, vib=0.80, pow=780.0, bay=4.5, blank=18.0, thr=640),
    "Beckman AU480":  dict(bath=36.95, probe=70.0, vib=1.40, pow=1200.0, bay=5.2, blank=25.0, thr=400),
}
MODES = {   # Weibull life (days), precursor window (days), typical unplanned downtime (h)
    "lamp":   dict(scale=1400, shape=2.5, pre=(35, 60), down=6,  comp="Photometer lamp"),
    "probe":  dict(scale=1000, shape=1.6, pre=(8, 20),  down=10, comp="Sample probe & syringe", abrupt=0.30),
    "cooler": dict(scale=1500, shape=1.5, pre=(7, 16),  down=30, comp="Reagent refrigeration"),
    "wash":   dict(scale=1250, shape=1.8, pre=(12, 24), down=14, comp="Cuvette wash station"),
    "drive":  dict(scale=1700, shape=2.0, pre=(18, 32), down=40, comp="Carousel drive"),
    "board":  dict(scale=1500, shape=1.0, pre=(0, 0),   down=56, comp="Power / control electronics"),
}
UNITS = [("BA-01", "Mindray BS-480", "LAB-01", 2019), ("BA-02", "Erba XL-640", "LAB-01", 2023), ("BA-03", "Beckman AU480", "LAB-01", 2021)]
_mk = list(MODELS)
for i in range(4, 41):
    UNITS.append((f"RF-{i:02d}", _mk[i % 3], f"REF-{(i - 4) // 3 + 2:02d}", 2017 + (i * 5) % 8))
DEMO = ["BA-01", "BA-02", "BA-03"]
HOURPROF = np.array([.05, .05, .05, .05, .05, .05, .08, .3, .7, 1, 1, .95, .85, .6, .55, .5, .45, .35, .25, .15, .1, .06, .05, .05])
HOURPROF_N = HOURPROF / HOURPROF.sum()
DEMO_SHARE = {"BA-01": 0.36, "BA-02": 0.38, "BA-03": 0.26}

amb_out = 27 + 6 * np.cos(2 * np.pi * (DOY - 135) / 365) + 3 * np.sin(2 * np.pi * (HOD - 9) / 24)
HUM = 55 + 25 * np.exp(-((DOY - 220) / 45.0) ** 2)


def gen_events(uid):
    pm_days = np.arange(RNG.integers(5, 90), DAYS + FUT, 90).astype(float)
    ev = []
    for m, p in MODES.items():
        t = -RNG.uniform(0, 1) * p["scale"] * 0.9
        while True:
            tf = t + max(p["scale"] * RNG.weibull(p["shape"]), 25)
            if tf > DAYS + FUT:
                break
            if tf < 3:
                t = tf
                continue
            pre, abrupt = (RNG.uniform(*p["pre"]) if p["pre"][1] > 0 else 0.0), False
            if p.get("abrupt") and RNG.random() < p["abrupt"]:
                pre, abrupt = RNG.uniform(1, 2.5), True
            t0, caught = tf - pre, None
            if pre > 5:      # a routine PM visit sometimes fixes the degradation before it becomes a failure
                cand = pm_days[(pm_days > t0 + 0.25 * pre) & (pm_days < tf - 0.1 * pre)]
                if len(cand) and RNG.random() < 0.5:
                    caught = float(cand[0])
            end = caught if caught is not None else tf
            sev = 0.08 if (pre > 5 and RNG.random() < 0.12) else float(RNG.uniform(0.5, 1.0))   # some failures give weak or no warning
            ev.append(dict(unit=uid, mode=m, t_start=t0, t_end=end, pre=pre, caught=caught is not None, abrupt=abrupt, sev=sev,
                           down_h=0.0 if caught is not None else float(p["down"] * RNG.lognormal(0, 0.4))))
            t = end + 0.5
    return ev, pm_days


def force_demo(uid, ev):
    """Controlled narrative for the three demo analyzers near 'now'."""
    ev = [e for e in ev if e["t_end"] < DAYS - 50]
    if uid == "BA-01":
        ev.append(dict(unit=uid, mode="probe", t_start=DAYS + 5.2 - 16, t_end=DAYS + 5.2, pre=16.0, caught=False, abrupt=False, down_h=13.0, sev=1.0))
        ev.append(dict(unit=uid, mode="lamp", t_start=DAYS + 44 - 60, t_end=DAYS + 44, pre=60.0, caught=False, abrupt=False, down_h=6.0, sev=0.9))
    if uid == "BA-03":
        ev.append(dict(unit=uid, mode="cooler", t_start=DAYS + 11.5 - 20, t_end=DAYS + 11.5, pre=20.0, caught=False, abrupt=False, down_h=34.0, sev=1.0))
    return ev


def simulate_unit(uid, model, k):
    mp = MODELS[model]
    ev, pm_days = gen_events(uid)
    if uid in DEMO:
        ev = force_demo(uid, ev)
    d = {m: np.zeros(H) for m in MODES}
    down = np.zeros(H, bool)
    lamp_reset = [0.0 - RNG.uniform(0, 300)]
    for e in ev:
        h0, h1 = int(max(e["t_start"], 0) * 24), int(min(e["t_end"], DAYS + FUT) * 24)
        if e["pre"] > 0 and h1 > h0:
            x = (np.arange(h0, h1) / 24 - e["t_start"]) / e["pre"]
            d[e["mode"]][h0:h1] = np.maximum(d[e["mode"]][h0:h1], e["sev"] * np.clip(x, 0, 1) ** 1.7)
        if not e["caught"]:
            down[h1:min(H, h1 + max(2, int(e["down_h"])))] = True
        if e["mode"] == "lamp":
            lamp_reset.append(e["t_end"])
    for pmd in pm_days:
        hp = int(pmd * 24) + 8
        down[hp:hp + 3] = True
    lamp_reset = np.array(sorted(lamp_reset))
    dayf = np.arange(H) / 24
    since_lamp = dayf - lamp_reset[np.searchsorted(lamp_reset, dayf, side="right") - 1]

    # load
    if uid in DEMO:
        exp_tests = LAB_TOTAL[CAL_DAY] * DEMO_SHARE[uid] * HOURPROF_N[HOD]
    else:
        vol = RNG.uniform(0.55, 1.25)
        exp_tests = vol * 330 * DOWF[DOW] * (1 + 0.12 * np.exp(-((DOY - 235) / 40.0) ** 2)) * HOURPROF_N[HOD]
    peak = np.percentile(exp_tests, 99.5)
    load = exp_tests / peak
    tests = RNG.poisson(exp_tests).astype(float)

    amb = 24 + 0.35 * (amb_out - 27) + RNG.normal(0, 0.4, H)
    volt = 230 + RNG.normal(0, 2.5, H)
    sag = np.zeros(H)
    for _ in range(RNG.poisson(54)):
        s = RNG.integers(0, H - 6)
        ln = RNG.integers(1, 6)
        volt[s:s + ln] -= RNG.uniform(20, 45)
        sag[s:s + ln] = 1
    u = {key: mp[key] * (1 + RNG.normal(0, 0.015)) for key in ("probe", "vib", "pow", "blank")}
    u["bath"] = mp["bath"] + RNG.normal(0, 0.03)
    u["bay"] = mp["bay"] + RNG.normal(0, 0.2)
    N = lambda s=1.0: RNG.normal(0, s, H)
    qc_shift = np.zeros(H)
    for s in range(RNG.integers(0, 45 * 24), H, 45 * 24):          # QC / reagent lot change: a benign level shift
        qc_shift[s:s + RNG.integers(48, 120)] += RNG.uniform(0.25, 0.5)

    def wander(sd, phi=0.996):                       # slow, benign drift that every real sensor shows
        return (0.45 if uid == "BA-02" else 1.0) * lfilter([1.0], [1.0, -phi], RNG.normal(0, sd * math.sqrt(1 - phi * phi), H))
    burst = np.zeros(H)
    for _ in range(RNG.poisson(25)):                  # operator / sample-quality error bursts unrelated to hardware health
        s0 = RNG.integers(0, H - 40)
        burst[s0:s0 + RNG.integers(2, 14)] += RNG.uniform(0.4, 1.2)
    sig = dict(
        bath_temp=u["bath"] + N(0.03) + wander(0.03) + 0.2 * d["wash"] * N() + 0.02 * (amb - 24),
        lamp_int=100 - 0.003 * since_lamp - 22 * d["lamp"] + N(0.4) + wander(0.5),
        probe_kpa=u["probe"] * (1 - 0.09 * d["probe"]) + u["probe"] * (0.012 * N() * (1 + 3 * d["probe"]) + wander(0.007)),
        vib=u["vib"] * (1 + 0.8 * d["drive"]) + 0.18 * load + N(0.06) + wander(0.04),
        power=u["pow"] + 260 * load + 70 * d["cooler"] + 35 * d["drive"] + N(12) + wander(9) + 4 * (amb - 24),
        bay_temp=u["bay"] + 6.5 * d["cooler"] + 0.12 * (amb - 24) + 0.35 * load + N(0.15) + wander(0.18),
        blank_abs=u["blank"] + 16 * d["wash"] + N(0.8) + wander(0.9),
        qc_sdi=np.abs(N(0.5)) + qc_shift + 0.8 * d["lamp"] + 0.7 * d["probe"] + 0.4 * d["wash"] + 0.3 * d["cooler"],
    )
    err_rate = 0.03 + 0.05 * load + burst + 1.2 * d["probe"] + 0.8 * d["wash"] + 0.6 * d["drive"] + 0.3 * d["lamp"] + 0.3 * d["cooler"] + 1.5 * sag
    errors = RNG.poisson(err_rate).astype(float)

    # --- things that make real-world models fail -------------------------------------------------
    sensor_faults = []
    drift_mag = dict(bath_temp=0.35, probe_kpa=-0.07 * u["probe"], vib=0.6 * u["vib"], bay_temp=4.0, blank_abs=11.0)
    if uid not in DEMO or True:
        for _ in range(RNG.poisson(2.2)):                           # sensor drift that looks like degradation, but is not
            s_name = list(drift_mag)[RNG.integers(0, 5)]
            s = RNG.integers(24 * 20, NOW_H - 24 * 70) if uid in DEMO else RNG.integers(24 * 20, H - 24 * 12)
            ln = RNG.integers(4 * 24, 10 * 24)
            sig[s_name][s:s + ln] += drift_mag[s_name] * RNG.uniform(0.5, 0.9) * np.linspace(0, 1, ln)
            sensor_faults.append(dict(unit=uid, signal=s_name, t_start=s / 24, t_end=(s + ln) / 24))
    for _ in range(RNG.poisson(2)):                                 # stuck sensor
        s_name = list(sig)[RNG.integers(0, 8)]
        s, ln = RNG.integers(0, H - 60), RNG.integers(12, 48)
        if uid in DEMO and s > NOW_H - 24 * 30:
            continue
        sig[s_name][s:s + ln] = sig[s_name][s]
    miss_all = down.copy()
    for _ in range(RNG.poisson(8)):                                 # IoT gateway / network outage
        s, ln = RNG.integers(0, H - 40), RNG.integers(6, 30)
        if uid in DEMO and s > NOW_H - 24 * 21:
            continue
        miss_all[s:s + ln] = True
    for key in sig:
        m = miss_all | (RNG.random(H) < 0.015)
        sig[key] = np.where(m, np.nan, sig[key])
    tests[down] = 0
    errors[miss_all] = np.nan

    f32 = lambda x: np.asarray(x, dtype=np.float32)
    df = pd.DataFrame(dict(unit=uid, h=np.arange(H, dtype=np.int32), ts=TS, tests=f32(tests), errors=f32(errors), ambient=f32(amb),
                           humidity=f32(HUM + RNG.normal(0, 3, H)), voltage=f32(volt), load=f32(load), down=down, **{k2: f32(v2) for k2, v2 in sig.items()}))
    for e in ev:
        e["model"] = model
    return df, ev, pm_days, sensor_faults, u


# ----------------------------------------------------------------------------
# 3. FEATURES (per-analyzer baselines), LABELS
# ----------------------------------------------------------------------------
SIGS = ["bath_temp", "lamp_int", "probe_kpa", "vib", "power", "bay_temp", "blank_abs", "qc_sdi"]
GLOBAL_STATS = {}


def build_features(g):
    g = g.sort_values("h").reset_index(drop=True)
    out = pd.DataFrame({"unit": g["unit"], "h": g["h"]})
    first = g[(g.h > 24 * 5) & (g.h < 24 * 70)]
    adj = {}
    for s in ("power", "vib", "bay_temp"):          # load-normalise using this analyzer's own first weeks
        ok = first[[s, "tests"]].dropna()
        slope = np.polyfit(ok["tests"], ok[s], 1)[0] if len(ok) > 100 else 0.0
        adj[s] = g[s] - slope * g["tests"]
    for s in SIGS:
        x = adj.get(s, g[s])
        m24 = x.rolling(24, min_periods=8).mean()
        base = m24.rolling(24 * 40, min_periods=24 * 10).median().shift(24 * 20)
        resid = (m24 - base)
        scale = resid[(g.h < 24 * 150)].std()
        scale = scale if scale and scale > 1e-6 else 1.0
        out[f"{s}_z"] = resid / scale
        out[f"{s}_slope"] = (m24 - m24.shift(168)) / scale
        sd = x.rolling(24, min_periods=8).std()
        out[f"{s}_vol"] = sd / (sd[(g.h < 24 * 150)].median() + 1e-9)
        out[f"{s}_m24"] = m24
        out[f"{s}_base"] = base
    out["lamp_abs"] = out["lamp_int_m24"]
    out["bay_abs"] = out["bay_temp_m24"]
    out["err24"] = g["errors"].rolling(24, min_periods=6).sum()
    out["err72"] = g["errors"].rolling(72, min_periods=18).sum()
    out["miss24"] = g["probe_kpa"].isna().rolling(24, min_periods=1).mean()
    out["tests24"] = g["tests"].rolling(24, min_periods=6).sum()
    out["amb24"] = g["ambient"].rolling(24, min_periods=6).mean()
    out["vmin72"] = g["voltage"].rolling(72, min_periods=6).min()
    pm_h = PMS[str(g["unit"].iloc[0])] * 24
    idx = np.searchsorted(pm_h, g["h"].values, side="right") - 1
    out["since_pm"] = np.where(idx >= 0, (g["h"].values - pm_h[np.clip(idx, 0, None)]) / 24, 120)
    out["down"] = g["down"].values
    return out


print("simulating telemetry + building features (one analyzer at a time) ...", flush=True)
unit_model = {u[0]: u[1] for u in UNITS}
EVENTS, PMS, SFAULTS, UBASE, TEL_DEMO, FEAT_DEMO, grids, N_ROWS = [], {}, [], {}, {}, {}, [], 0
os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
TEL_CSV = os.path.join(ROOT, "data", "equipment_telemetry_hourly.csv")
for k, (uid, model, site, yr) in enumerate(UNITS):
    g, ev, pm, sf, ub = simulate_unit(uid, model, k)
    EVENTS += ev; PMS[uid] = pm; SFAULTS += sf; UBASE[uid] = ub
    hist_part = g[g.h <= NOW_H]
    N_ROWS += len(hist_part)
    hist_part.drop(columns=["h", "load"]).round(3).to_csv(TEL_CSV, mode="w" if k == 0 else "a", header=(k == 0), index=False)
    fz = build_features(g)
    hh = fz["h"].values
    fh = np.array(sorted(e["t_end"] * 24 for e in ev if not e["caught"]))
    yv = np.zeros(len(fz), bool); rr = np.zeros(len(fz), bool)
    if len(fh):
        nxt = np.searchsorted(fh, hh, side="right")
        dt = np.where(nxt < len(fh), fh[np.clip(nxt, 0, len(fh) - 1)] - hh, 1e9)
        yv = dt <= 168
        prv = nxt - 1
        rr = np.where(prv >= 0, hh - fh[np.clip(prv, 0, None)], 1e9) < 72
    fz["y"] = yv
    fz["model"] = model
    gr = fz[(fz.h % 6 == 0) & (fz.h >= 24 * 32) & (~fz.down) & (~rr)].copy()
    fcols = gr.select_dtypes("float64").columns
    gr[fcols] = gr[fcols].astype(np.float32)
    grids.append(gr)
    if uid in DEMO:
        FEAT_DEMO[uid] = fz.set_index("h"); TEL_DEMO[uid] = g
    del fz, g, hist_part
GRID = pd.concat(grids, ignore_index=True)
del grids
FAILS = [e for e in EVENTS if not e["caught"]]
print(f"  rows={N_ROWS:,}  failures={len(FAILS)}  pm-corrected degradations={len(EVENTS) - len(FAILS)}", flush=True)

Z = [f"{s}_z" for s in SIGS]
BASE_FEATS = Z + [f"{s}_slope" for s in SIGS] + [f"{s}_vol" for s in SIGS] + ["lamp_abs", "bay_abs", "err24", "err72", "miss24", "tests24", "amb24", "vmin72", "since_pm"]
T1, T2 = int(NOW_H * 0.55), int(NOW_H * 0.70)
tr, va, te = GRID[GRID.h < T1], GRID[(GRID.h >= T1) & (GRID.h < T2)], GRID[(GRID.h >= T2) & (GRID.h <= NOW_H)]
print(f"  grid rows: train={len(tr):,} val={len(va):,} test={len(te):,}  positive rate={GRID[GRID.h <= NOW_H].y.mean():.3f}", flush=True)


def fit_gbm(d, feats):
    m = HistGradientBoostingClassifier(max_iter=220, learning_rate=0.06, max_depth=4, l2_regularization=2.0,
                                       min_samples_leaf=60, random_state=7)
    return m.fit(d[feats], d["y"])


def event_eval(rows, score, thr, h_lo, h_hi, persist=3):
    """Event-level scoring: did we warn before each failure, and how many alert episodes were false?"""
    det, leads, by_mode, episodes = 0, [], {}, []
    rows = rows.assign(s=score)
    alerts = {}
    for uid, g in rows.groupby("unit", sort=False):
        a = (g["s"].values >= thr)
        for _ in range(persist - 1):               # an alert must persist (3 x 6 h) before it is raised
            a = a & np.r_[False, a[:-1]]
        hh = g["h"].values[a]
        alerts[uid] = hh
        if len(hh):
            brk = np.r_[True, np.diff(hh) > 72]
            starts = hh[brk]
            ends = hh[np.r_[brk[1:], True]]
            episodes += [(uid, s, e) for s, e in zip(starts, ends)]
    ev_in = [e for e in FAILS if h_lo <= e["t_end"] * 24 <= h_hi and e["unit"] in alerts]
    for e in ev_in:
        tf = e["t_end"] * 24
        hh = alerts[e["unit"]]
        w = hh[(hh >= tf - 14 * 24) & (hh < tf)]
        bm = by_mode.setdefault(e["mode"], [0, 0])
        bm[1] += 1
        if len(w):
            det += 1; bm[0] += 1; leads.append((tf - w.min()) / 24)
    cls = dict(true=0, pm_corrected=0, sensor_fault=0, unexplained=0)
    for uid, s, e in episodes:
        if not (h_lo <= s <= h_hi):
            continue
        if any(ev["unit"] == uid and s <= ev["t_end"] * 24 and e >= ev["t_end"] * 24 - 30 * 24 for ev in FAILS):
            cls["true"] += 1
        elif any(ev["unit"] == uid and ev["caught"] and s <= ev["t_end"] * 24 + 48 and e >= ev["t_start"] * 24 for ev in EVENTS):
            cls["pm_corrected"] += 1
        elif any(sf["unit"] == uid and s <= sf["t_end"] * 24 + 48 and e >= sf["t_start"] * 24 for sf in SFAULTS):
            cls["sensor_fault"] += 1
        else:
            cls["unexplained"] += 1
    um = rows["unit"].nunique() * (h_hi - h_lo) / 720.0
    fa = cls["sensor_fault"] + cls["unexplained"]
    n_al = sum(cls.values())
    return dict(events=len(ev_in), detected=det, recall=det / max(1, len(ev_in)), median_lead_d=float(np.median(leads)) if leads else 0.0,
                p25_lead_d=float(np.percentile(leads, 25)) if leads else 0.0, false_alarms=fa, fa_per_unit_month=fa / um,
                episodes=cls, alert_precision=(cls["true"] + cls["pm_corrected"]) / max(1, n_al),
                by_mode={k: dict(detected=v[0], events=v[1]) for k, v in by_mode.items()})


def pick_threshold(rows, score, h_lo, h_hi, budget=0.05):
    best = None
    for q in np.linspace(0.85, 0.998, 60):
        thr = float(np.quantile(score, q))
        r = event_eval(rows, score, thr, h_lo, h_hi)
        key = (r["fa_per_unit_month"] <= budget, r["recall"], -r["fa_per_unit_month"])
        if best is None or key > best[0]:
            best = (key, thr, r)
    return best[1]


print("training failure-risk model ...", flush=True)
gbm = fit_gbm(tr, BASE_FEATS)
s_va, s_te = gbm.predict_proba(va[BASE_FEATS])[:, 1], gbm.predict_proba(te[BASE_FEATS])[:, 1]
THR = pick_threshold(va, s_va, T1, T2)
R_GBM = event_eval(te, s_te, THR, T2, NOW_H)
# calibrate raw scores to a 7-day failure probability on the validation period (never seen in training)
CAL = IsotonicRegression(out_of_bounds="clip", y_min=0, y_max=1).fit(s_va, va["y"].astype(float))
# operating curve on the held-out test period: every threshold is a recall / false-alarm trade-off
CURVE = []
for q in np.linspace(0.70, 0.999, 36):
    t_ = float(np.quantile(s_te, q))
    r_ = event_eval(te, s_te, t_, T2, NOW_H)
    CURVE.append(dict(thr=t_, prob=float(CAL.predict([t_])[0]), recall=r_["recall"], fa=r_["fa_per_unit_month"], lead=r_["median_lead_d"], precision=r_["alert_precision"]))
R_GBM["pr_auc"] = float(average_precision_score(te["y"], s_te))
print("  GBM test:", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in R_GBM.items() if k != "by_mode"}, flush=True)

# baseline 1: fixed universal thresholds (what a simple alarm panel does)
def rule_score(d):
    return np.nanmax(np.c_[(100 - d["lamp_abs"]) / 24, (d["bay_abs"] - 4) / 5.5, d["err24"] / 30,
                           (d["vib_m24"] - 0.8) / 1.3, (d["blank_abs_m24"] - 18) / 20, np.zeros(len(d))], axis=1)
THR_R = pick_threshold(va, rule_score(va), T1, T2)
R_RULE = event_eval(te, rule_score(te), THR_R, T2, NOW_H)
R_RULE["pr_auc"] = float(average_precision_score(te["y"], rule_score(te)))

# baseline 2: unsupervised anomaly detection on per-analyzer z-scores (needs no failure labels at all)
ISO_FEATS = Z + ["err24"]
iso = IsolationForest(n_estimators=150, contamination=0.03, random_state=7, n_jobs=1).fit(tr[ISO_FEATS].fillna(0))
iso_s = lambda d: -iso.score_samples(d[ISO_FEATS].fillna(0))
THR_I = pick_threshold(va, iso_s(va), T1, T2)
R_ISO = event_eval(te, iso_s(te), THR_I, T2, NOW_H)
R_ISO["pr_auc"] = float(average_precision_score(te["y"], iso_s(te)))
print("  rule recall", round(R_RULE["recall"], 2), "iso recall", round(R_ISO["recall"], 2), flush=True)

# ---- stress tests: the ways predictive-maintenance models fail in practice ---------------------
print("stress tests ...", flush=True)
STRESS = []
def add_stress(name, why, res, mitig):
    STRESS.append(dict(name=name, why=why, mitigation=mitig, recall=res["recall"], fa=res["fa_per_unit_month"],
                       lead=res["median_lead_d"], pr_auc=res.get("pr_auc", None), events=res["events"]))
add_stress("Reference: held-out future period", "Chronological split, unseen final 30% of the timeline", R_GBM, "-")

te_drop = te.copy()
sr = np.random.default_rng(5)
for s in SIGS:                                           # 30% of sensors silent
    m = sr.random(len(te_drop)) < 0.30
    for suf in ("_z", "_slope", "_vol"):
        te_drop.loc[m, s + suf] = np.nan
    if s == "lamp_int": te_drop.loc[m, "lamp_abs"] = np.nan
    if s == "bay_temp": te_drop.loc[m, "bay_abs"] = np.nan
sd = gbm.predict_proba(te_drop[BASE_FEATS])[:, 1]
r = event_eval(te_drop, sd, THR, T2, NOW_H); r["pr_auc"] = float(average_precision_score(te_drop["y"], sd))
add_stress("30% of sensor readings missing", "Gateway outages, unplugged probes, older analyzers with fewer signals", r,
           "Model accepts missing values natively; data-quality score shown beside every prediction")

pool = dict(events=0, detected=0, fa=0, um=0.0, leads=[], in_det=0)
for m3 in MODELS:                                       # leave one analyzer model out, three times, pooled
    g_other = fit_gbm(tr[tr.model != m3], BASE_FEATS)
    te3 = te[te.model == m3]
    r3 = event_eval(te3, g_other.predict_proba(te3[BASE_FEATS])[:, 1], THR, T2, NOW_H)
    r3in = event_eval(te3, gbm.predict_proba(te3[BASE_FEATS])[:, 1], THR, T2, NOW_H)
    pool["events"] += r3["events"]; pool["detected"] += r3["detected"]; pool["fa"] += r3["false_alarms"]
    pool["um"] += te3["unit"].nunique() * (NOW_H - T2) / 720.0; pool["in_det"] += r3in["detected"]
    if r3["detected"]:
        pool["leads"].append(r3["median_lead_d"])
r = dict(events=pool["events"], recall=pool["detected"] / max(1, pool["events"]), fa_per_unit_month=pool["fa"] / pool["um"],
         median_lead_d=float(np.mean(pool["leads"])) if pool["leads"] else 0.0, pr_auc=None)
add_stress("Analyzer model never seen in training", f"Leave-one-model-out across all three analyzer models (same units with the model in training: {pool['in_det']}/{pool['events']} detected)", r,
           "Per-analyzer baselines make features transferable; a new model starts in anomaly-only mode until validated")

UNI = [c.replace("_z", "_uz") for c in Z]
for s in SIGS:                                           # universal thresholds instead of per-analyzer baselines
    mu, sdv = tr[f"{s}_m24"].mean(), tr[f"{s}_m24"].std()
    for d in (tr, va, te):
        d.loc[:, f"{s}_uz"] = (d[f"{s}_m24"] - mu) / sdv
feats_u = UNI + ["err24", "err72", "miss24", "tests24", "amb24", "vmin72", "since_pm"]
g_u = fit_gbm(tr, feats_u)
thr_u = pick_threshold(va, g_u.predict_proba(va[feats_u])[:, 1], T1, T2)
su = g_u.predict_proba(te[feats_u])[:, 1]
r = event_eval(te, su, thr_u, T2, NOW_H); r["pr_auc"] = float(average_precision_score(te["y"], su))
add_stress("One universal threshold for every analyzer", "No machine-specific baseline: a Beckman's normal vibration is an Erba's alarm", r,
           "Every analyzer learns its own rolling baseline, re-anchored after maintenance")

allrows = GRID[GRID.h <= NOW_H]
perm = np.random.default_rng(3).permutation(len(allrows))
cut = int(len(perm) * 0.8)
g_leak = fit_gbm(allrows.iloc[perm[:cut]], BASE_FEATS)
leak_ap = float(average_precision_score(allrows.iloc[perm[cut:]]["y"], g_leak.predict_proba(allrows.iloc[perm[cut:]][BASE_FEATS])[:, 1]))

board = R_GBM["by_mode"].get("board", dict(detected=0, events=0))
POS_RATE = float(te["y"].mean())
ALWAYS_NORMAL_ACC = 1 - POS_RATE
imp_base = average_precision_score(te["y"], s_te)
IMPORT = []
ir = np.random.default_rng(11)
for grp, cols in [("Sample probe pressure", ["probe_kpa_z", "probe_kpa_slope", "probe_kpa_vol"]), ("Lamp intensity", ["lamp_int_z", "lamp_int_slope", "lamp_abs", "lamp_int_vol"]),
                  ("Reagent bay temperature", ["bay_temp_z", "bay_temp_slope", "bay_abs", "bay_temp_vol"]), ("Cuvette blank absorbance", ["blank_abs_z", "blank_abs_slope", "blank_abs_vol"]),
                  ("Vibration", ["vib_z", "vib_slope", "vib_vol"]), ("Error-code frequency", ["err24", "err72"]), ("QC deviation", ["qc_sdi_z", "qc_sdi_slope", "qc_sdi_vol"]),
                  ("Power draw", ["power_z", "power_slope", "power_vol"]), ("Bath temperature", ["bath_temp_z", "bath_temp_slope", "bath_temp_vol"]),
                  ("Context (load, ambient, voltage, days since PM)", ["tests24", "amb24", "vmin72", "since_pm", "miss24"])]:
    tmp = te[BASE_FEATS].copy()
    p = ir.permutation(len(tmp))
    for c in cols:
        tmp[c] = tmp[c].values[p]
    IMPORT.append(dict(group=grp, drop=float(imp_base - average_precision_score(te["y"], gbm.predict_proba(tmp)[:, 1]))))
IMPORT.sort(key=lambda d: -d["drop"])

# ----------------------------------------------------------------------------
# 4. DEMAND FORECASTING
# ----------------------------------------------------------------------------
print("forecasting demand ...", flush=True)
HO = 56
codes = [a["code"] for a in ASSAY]
Y = DEMAND[codes].values                                  # (ND, n_assay); history is rows [0, DAYS)


def fc_feats(series, t, ai):
    lags = [series[t - 7], series[t - 14], series[t - 21], series[t - 28]]
    lvl = np.mean(series[t - 34:t - 6])
    d = DATES[t]
    return lags + [lvl, d.day_of_week, d.month, float(HOL[t]), float(CAMP[t]), ai], lvl


Xf, yf, meta = [], [], []
for ai, c in enumerate(codes):
    s = Y[:, ai]
    for t in range(40, DAYS):
        f, lvl = fc_feats(s, t, ai)
        Xf.append(f[:4] + [f[4]] + f[5:]); yf.append(s[t] / max(lvl, 1.0)); meta.append((ai, t, lvl))
Xf, yf, meta = np.array(Xf), np.array(yf), np.array(meta)
Xr = Xf.copy(); Xr[:, :4] = Xr[:, :4] / np.maximum(Xr[:, 4:5], 1.0)       # scale-free lags so one model serves all assays
is_ho = meta[:, 1] >= DAYS - HO
reg = HistGradientBoostingRegressor(max_iter=250, learning_rate=0.05, max_depth=4, random_state=7).fit(Xr[~is_ho], yf[~is_ho])
pred_gbm = reg.predict(Xr[is_ho]) * np.maximum(meta[is_ho, 2], 1.0)
act = np.array([Y[int(t), int(ai)] for ai, t, _ in meta[is_ho]])
pred_naive = Xf[is_ho, 0]
pred_ma = Xf[is_ho, :4].mean(axis=1)
def fmet(p):
    return dict(mae=float(np.mean(np.abs(p - act))), wape=float(np.sum(np.abs(p - act)) / np.sum(act)), bias=float((np.sum(p) - np.sum(act)) / np.sum(act)))
FC_METRICS = {"Seasonal naive (same weekday last week)": fmet(pred_naive), "4-week weekday average": fmet(pred_ma), "Gradient boosting (pooled, calendar-aware)": fmet(pred_gbm)}
FC_BEST = min(FC_METRICS, key=lambda k: FC_METRICS[k]["wape"])
use_gbm = FC_BEST.startswith("Gradient")
best_pred = pred_gbm if use_gbm else pred_ma
ai_ho = meta[is_ho, 0].astype(int)
FC_ASSAY = {}
for ai, c in enumerate(codes):
    m = ai_ho == ai
    ratio = (act[m] + 1) / (best_pred[m] + 1)
    FC_ASSAY[c] = dict(wape=float(np.sum(np.abs(best_pred[m] - act[m])) / max(1, np.sum(act[m]))), p10=float(np.quantile(ratio, 0.10)), p90=float(np.quantile(ratio, 0.90)))
reg_full = HistGradientBoostingRegressor(max_iter=250, learning_rate=0.05, max_depth=4, random_state=7).fit(Xr, yf)
FC = {}
for ai, c in enumerate(codes):
    s = Y[:, ai].copy()
    for t in range(DAYS, ND):                              # recursive: forecasts feed later lags; the true future is never read
        f, lvl = fc_feats(s, t, ai)
        if use_gbm:
            x = np.array(f, float); x[:4] = x[:4] / max(lvl, 1.0)
            s[t] = max(0.0, reg_full.predict(x.reshape(1, -1))[0] * max(lvl, 1.0))
        else:
            s[t] = np.mean(f[:4]) * (0.4 if HOL[t] else 1.0)
    FC[c] = s[DAYS:]
print("  forecast WAPE:", {k: round(v["wape"], 3) for k, v in FC_METRICS.items()}, flush=True)

# ----------------------------------------------------------------------------
# 5. REAGENT POLICY BACK-TEST (last 365 days of the same demand, two policies)
# ----------------------------------------------------------------------------
print("reagent policy back-test ...", flush=True)
AN = DEMO
down_day = {a: np.zeros(ND, bool) for a in AN}
for e in FAILS:
    if e["unit"] in AN and e["t_end"] < DAYS:
        d0 = int(e["t_end"] + 0.25)
        down_day[e["unit"]][d0:d0 + max(1, int(round(e["down_h"] / 24 + 0.3)))] = True
te_scores = pd.Series(gbm.predict_proba(GRID[BASE_FEATS])[:, 1], index=GRID.index)
warned_day = {a: np.zeros(ND, bool) for a in AN}           # days on which the risk model was alerting for this analyzer
for a in AN:
    g = GRID[GRID.unit == a]
    hh = g["h"].values[te_scores[g.index].values >= THR]
    warned_day[a][np.unique(((hh + 6) // 24).astype(int))] = True


def backtest(policy):
    r = np.random.default_rng(99)
    BT0 = DAYS - 365
    months = {}
    tot = dict(spend=0.0, waste_obs=0.0, waste_shelf=0.0, qc=0.0, stockout_tests=0.0, used_tests=0.0, loads=0, holds=0)
    for ai, a in enumerate(ASSAY):
        c = a["code"]
        menu = [x for x in AN if c in MENU[x]]
        hist = Y[:, ai]
        mean_all = hist[:BT0].mean()
        onb = {x: None for x in menu}
        stock, orders = [], []
        pack = ("L", a["bottle"], a["price"])
        routing = list(menu)
        def new_bottle(day, short=False):
            shelf = r.uniform(20, 60) if short else r.uniform(150, 400)
            return dict(tests=pack[1], price=pack[2], exp=day + shelf)
        for _ in range(3):
            stock.append(new_bottle(BT0))
        for day in range(BT0, DAYS):
            mk = DATES[day].strftime("%Y-%m")
            M = months.setdefault(mk, dict(waste_obs=0.0, waste_shelf=0.0, qc=0.0, stockout=0.0, spend=0.0))
            mu = np.mean(hist[day - 28:day])
            sdv = np.std(hist[day - 28:day])
            # ---- routing / pack decision
            if policy == "LP" and (day - BT0) % 28 == 0:
                best = None
                for k in range(1, len(menu) + 1):
                    if mu >= 60 and k < 2 and len(menu) >= 2:
                        continue                        # keep redundancy for high-volume assays
                    for pk in (("L", a["bottle"], a["price"]), ("S", a["smallBottle"], a["smallPrice"])):
                        use = mu / k + a["qcPerDay"]
                        life = min(a["obs"], (pk[1] - a["dead"]) / use)
                        cost_day = k * (pk[2] / life)   # each loaded position burns one bottle per 'life' days
                        if best is None or cost_day < best[0]:
                            best = (cost_day, k, pk)
                pack = best[2]
                routing = menu[:best[1]] if c not in ("CRP",) else menu[:best[1]]
            if policy == "BASE":                      # sensible manual practice: low-volume assays on one analyzer, mid on two
                routing = menu[:1] if a["base"] < 20 else (menu[:2] if a["base"] < 50 else list(menu))
            # ---- receive orders, expire shelf stock
            for o in [o for o in orders if o[0] <= day]:
                short = r.random() < 0.18             # short-dated consignment
                nbs = [new_bottle(day, short=short) for _ in range(o[1])]
                if policy == "LP" and short:           # goods-receipt check: accept only what can be consumed before expiry
                    can = max(0, int((mu + len(routing) * a["qcPerDay"]) * 45 / pack[1]) + 1 - len(stock))
                    rej = max(0, len(nbs) - can)
                    tot["spend"] -= rej * pack[2]; M["spend"] -= rej * pack[2]
                    nbs = nbs[:can]
                stock += nbs
                orders.remove(o)
            for b in [b for b in stock if b["exp"] < day]:
                tot["waste_shelf"] += b["price"]; M["waste_shelf"] += b["price"]; stock.remove(b)
            stock.sort(key=lambda b: b["exp"])
            # ---- ordering
            on_order = sum(o[1] for o in orders)
            if policy == "BASE" and (day - BT0) % 90 == 0:
                target = 130 * mean_all / pack[1] * 1.15
                q = int(math.ceil(target - len(stock) - on_order))
                if q > 0:
                    orders.append((day + max(4, int(r.normal(10, 3))), q)); tot["spend"] += q * pack[2]; M["spend"] += q * pack[2]
            if policy == "LP" and (day - BT0) % 7 == 0:
                need = (mu + len(routing) * a["qcPerDay"]) * 24 + 1.65 * sdv * math.sqrt(24)
                onboard_tests = sum(max(0, onb[x]["rem"]) for x in menu if onb[x])
                q = int(math.ceil((need - onboard_tests * 0.5) / pack[1] - len(stock) - on_order))
                if q > 0:
                    orders.append((day + max(4, int(r.normal(10, 3))), q)); tot["spend"] += q * pack[2]; M["spend"] += q * pack[2]
            # ---- run the day
            up = [x for x in routing if not down_day[x][day]]
            dem = hist[day]
            if not up:
                up_alt = [x for x in menu if not down_day[x][day] and onb[x]]
                up = up_alt[:1]
            share = dem / len(up) if up else 0.0
            if not up:
                tot["stockout_tests"] += dem; M["stockout"] += dem
            for x in menu:
                b = onb[x]
                if b:
                    b["age"] += 1
                active = x in up
                if b and (b["age"] >= a["obs"] or b["exp"] < day or b["rem"] <= a["dead"]):
                    w = max(0.0, b["rem"]) * b["ptest"]
                    cause = "waste_shelf" if (b["exp"] < day and b["age"] < a["obs"]) else "waste_obs"
                    tot[cause] += w; M[cause] += w; onb[x] = None; b = None
                if not active:
                    continue
                if b is None:
                    if policy == "LP" and warned_day[x][day] and len(up) > 1:
                        tot["holds"] += 1          # predicted failure: do not open a fresh bottle here, reroute instead
                        others = [z for z in up if z != x and onb[z]]
                        if others:
                            onb[others[0]]["rem"] -= share
                            tot["used_tests"] += share
                            continue
                    if stock:
                        nb = stock.pop(0)
                        b = onb[x] = dict(rem=nb["tests"] - a["calTests"], age=0, exp=nb["exp"], ptest=nb["price"] / nb["tests"])
                        tot["loads"] += 1
                    else:
                        tot["stockout_tests"] += share; M["stockout"] += share
                        continue
                b["rem"] -= share + a["qcPerDay"]
                tot["used_tests"] += share
                tot["qc"] += a["qcPerDay"] * b["ptest"]; M["qc"] += a["qcPerDay"] * b["ptest"]
    tot["months"] = months
    return tot


BT_BASE, BT_LP = backtest("BASE"), backtest("LP")
print("  waste (on-board + shelf) base=%.0f  labpulse=%.0f" % (BT_BASE["waste_obs"] + BT_BASE["waste_shelf"], BT_LP["waste_obs"] + BT_LP["waste_shelf"]), flush=True)

# ----------------------------------------------------------------------------
# 6. DEMO-SITE EXPORT: telemetry, risk, component health, RUL, inventory, cold chain
# ----------------------------------------------------------------------------
print("exporting ...", flush=True)
iso_dt = lambda t: pd.Timestamp(t).strftime("%Y-%m-%dT%H:%M")
day_dt = lambda dnum: (START + pd.Timedelta(days=float(dnum))).strftime("%Y-%m-%dT%H:%M")
COMP = {   # component -> wear index in [0,1+], from this analyzer's own baseline
    "lamp":   lambda f, ub: (100 - f["lamp_int_m24"]) / 24.0,
    "probe":  lambda f, ub: (f["probe_kpa_base"] - f["probe_kpa_m24"]) / (0.09 * f["probe_kpa_base"]),
    "cooler": lambda f, ub: (f["bay_temp_m24"] - f["bay_temp_base"]) / 6.5,
    "wash":   lambda f, ub: (f["blank_abs_m24"] - f["blank_abs_base"]) / 16.0,
    "drive":  lambda f, ub: (f["vib_m24"] - f["vib_base"]) / (0.8 * ub["vib"]),
    "bath":   lambda f, ub: (f["bath_temp_m24"] - f["bath_temp_base"]).abs() / 0.5,
}
LABEL = dict(bath_temp_z="Reaction bath temperature", lamp_int_z="Lamp intensity", probe_kpa_z="Aspiration pressure", vib_z="Carousel vibration",
             power_z="Power draw (load-normalised)", bay_temp_z="Reagent bay temperature", blank_abs_z="Cuvette blank absorbance", qc_sdi_z="QC deviation (SDI)")
ANALYZERS = []
for uid, model, site, yr in UNITS[:3]:
    g = TEL_DEMO[uid]
    f = FEAT_DEMO[uid]
    hist = g[(g.h > NOW_H - 21 * 24) & (g.h <= NOW_H)]
    grid = GRID[(GRID.unit == uid) & (GRID.h > NOW_H - 60 * 24) & (GRID.h <= NOW_H)]
    raw = gbm.predict_proba(grid[BASE_FEATS])[:, 1]
    risk = CAL.predict(raw)
    alerting = bool(np.all(raw[-3:] >= THR))
    anom = iso_s(grid)
    now = f.loc[NOW_H]
    # explanation: which signals have moved furthest from this analyzer's own baseline
    drivers = sorted([dict(signal=LABEL[z], z=float(now[z]), slope=float(now[z.replace("_z", "_slope")]),
                           now=float(now[z.replace("_z", "_m24")]), base=float(now[z.replace("_z", "_base")])) for z in Z], key=lambda d: -abs(d["z"]))
    comps = {}
    daily_h = np.arange(NOW_H - 120 * 24, NOW_H + 1, 24)
    for cname, fn in COMP.items():
        wear = fn(f, UBASE[uid]).clip(lower=0).rolling(24, min_periods=1).mean()
        w = wear.reindex(daily_h).ffill().fillna(0).values
        # remaining useful life: power-law fit of the recent wear trend, extrapolated to the service limit
        rul = None
        recent = w[-12:]
        if w[-1] > 0.15 and recent[-1] - recent[0] > 0.06:
            t = np.arange(len(recent), dtype=float)
            sl = max(np.polyfit(t[-7:], recent[-7:], 1)[0], 1e-4)
            rem = max(0.0, 1.0 - w[-1])
            lin = rem / sl                                          # wear keeps its current pace
            gr = np.polyfit(t, np.log(np.clip(recent, 0.02, None)), 1)[0]
            acc = math.log(1.0 / max(w[-1], 0.02)) / gr if gr > 1e-3 else lin   # wear keeps accelerating
            lo, hi = sorted((lin, acc))
            rul = dict(mid=float(math.sqrt(max(lo, 0.3) * max(hi, 0.3))), lo=float(lo), hi=float(min(150, hi)))
        comps[cname] = dict(health=float(max(0, 100 * (1 - w[-1]))), series=[float(max(0, 100 * (1 - x))) for x in w], rul=rul)
    comps["board"] = dict(health=None, series=[], rul=None)   # sudden-failure class: no precursor telemetry, stated honestly
    evs = [dict(mode=e["mode"], comp=MODES[e["mode"]]["comp"], at=day_dt(e["t_end"]), downH=round(e["down_h"], 1), caught=e["caught"])
           for e in EVENTS if e["unit"] == uid and e["t_end"] < DAYS]
    hidden = [dict(mode=e["mode"], comp=MODES[e["mode"]]["comp"], at=day_dt(e["t_end"]), downH=round(e["down_h"], 1), inDays=round(e["t_end"] - DAYS, 1))
              for e in EVENTS if e["unit"] == uid and e["t_end"] >= DAYS and not e["caught"]]
    dd = g[(g.h > NOW_H - 180 * 24) & (g.h <= NOW_H)].copy()
    dd["d"] = (dd.h - (NOW_H - 180 * 24) - 1) // 24
    daily = dd.groupby("d").agg(tests=("tests", "sum"), errors=("errors", "sum"), down=("down", "sum"), **{s: (s, "mean") for s in SIGS})
    hh24 = g[(g.h > NOW_H - 365 * 24) & (g.h <= NOW_H)]
    ANALYZERS.append(dict(
        id=uid, model=model, site=site, installed=yr, throughput=MODELS[model]["thr"], menu=MENU[uid], share=DEMO_SHARE[uid],
        risk=float(risk[-1]), rawScore=float(raw[-1]), alerting=alerting, riskSeries=[float(x) for x in risk], riskTs=[iso_dt(TS[h]) for h in grid.h.values], anomSeries=[float(x) for x in anom],
        drivers=drivers, components=comps, events=sorted(evs, key=lambda e: e["at"]), hidden=hidden,
        pm=[day_dt(p + 8 / 24) for p in PMS[uid] if p < DAYS + 60],
        hourly=dict(ts=[iso_dt(t) for t in hist.ts], tests=hist.tests.tolist(), errors=hist.errors.tolist(), **{s: hist[s].tolist() for s in SIGS}),
        daily=dict(start=iso_dt(TS[NOW_H - 180 * 24 + 1]), tests=daily.tests.tolist(), errors=daily.errors.tolist(), downH=daily.down.tolist(), **{s: daily[s].tolist() for s in SIGS}),
        baseline={s: float(now[f"{s}_base"]) for s in SIGS}, dataQuality=float(1 - hist[SIGS].isna().mean().mean()),
        uptime365=float(1 - hh24.down.mean()), tests30=float(g[(g.h > NOW_H - 30 * 24) & (g.h <= NOW_H)].tests.sum()),
    ))

# ---- reagent inventory snapshot (current manual practice: every assay loaded on every validated analyzer) ----
IR = np.random.default_rng(424242)
TODAY = END.normalize()
dstr = lambda d: pd.Timestamp(d).strftime("%Y-%m-%d")
LOTS, lot_n = [], [1000]
SUPPLIERS = [("Meridian Diagnostics", 9, 2.5), ("Sahyadri Biosciences", 12, 3.5), ("Kaveri Lab Supplies", 6, 1.5)]
BINS = ["CR1-A1", "CR1-A2", "CR1-A3", "CR1-B1", "CR1-B2", "CR1-B3", "CR1-C1", "CR1-C2", "LF1-S1", "LF1-S2", "LF2-S1", "LF2-S2"]


def mk_lot(a, **kw):
    lot_n[0] += 1
    sup = SUPPLIERS[(ASSAY.index(a)) % 3]
    lot = dict(id=f"LOT-{lot_n[0]}", assay=a["code"], lotNo=f"{a['code'][:3]}{IR.integers(24000, 26999)}{'ABCDEFG'[IR.integers(0, 7)]}",
               bottleTests=a["bottle"], price=a["price"], pack="L", state="stored", analyzer=None, location=None, remaining=a["bottle"],
               expiry=None, received=None, opened=None, loaded=None, excursionUsedH=0.0, supplier=sup[0])
    lot.update(kw)
    return lot


for a in ASSAY:
    c = a["code"]
    menu = [x for x in DEMO if c in MENU[x]]
    mu = float(np.mean(DEMAND[c].values[DAYS - 28:DAYS]))
    menu = menu[:1] if (a["base"] < 20 or c == "CRP") else (menu[:2] if a["base"] < 50 else menu)
    for x in menu:
        use = mu / len(menu) + a["qcPerDay"]
        age = float(IR.uniform(0.15, 0.9) * min(a["obs"], a["bottle"] / use))
        rem = max(25.0, a["bottle"] - a["calTests"] - use * age * IR.uniform(0.9, 1.05))
        exp = TODAY + pd.Timedelta(days=int(IR.integers(40, 320)))
        LOTS.append(mk_lot(a, state="onboard", analyzer=x, location=f"{x} bay", remaining=round(rem), expiry=dstr(exp),
                           received=dstr(TODAY - pd.Timedelta(days=int(age) + int(IR.integers(6, 40)))),
                           opened=dstr(TODAY - pd.Timedelta(days=int(round(age)))), loaded=dstr(TODAY - pd.Timedelta(days=int(round(age))))))
    cover_target = IR.uniform(18, 70)
    nb = int(np.clip(round(cover_target * mu / a["bottle"]), 1, 6))
    for i in range(nb):
        LOTS.append(mk_lot(a, location=BINS[int(IR.integers(0, 10))], expiry=dstr(TODAY + pd.Timedelta(days=int(IR.integers(60, 380)))),
                           received=dstr(TODAY - pd.Timedelta(days=int(IR.integers(3, 60))))))


def find(code, state, analyzer=None):
    return [l for l in LOTS if l["assay"] == code and l["state"] == state and (analyzer is None or l["analyzer"] == analyzer)]


# hero lot: the exact situation in the brief (400 tests left, ~45/day, 6 days on-board, 45 days to expiry)
h = find("CRP", "onboard", "BA-01")[0]
h.update(remaining=400, loaded=dstr(TODAY - pd.Timedelta(days=8)), opened=dstr(TODAY - pd.Timedelta(days=8)), expiry=dstr(TODAY + pd.Timedelta(days=45)),
         lotNo="CRP26118C", received=dstr(TODAY - pd.Timedelta(days=20)))
for i, l in enumerate(find("CRP", "stored")):
    l.update(lotNo="CRP26118C" if i == 0 else "CRP26204A", expiry=dstr(TODAY + pd.Timedelta(days=45 if i == 0 else 210)), location="CR1-B2")
a_ = {a["code"]: a for a in ASSAY}
s = find("AMY", "stored")
s[0].update(expiry=dstr(TODAY + pd.Timedelta(days=12)), lotNo="AMY25331F", location="CR1-C1", received=dstr(TODAY - pd.Timedelta(days=58)))   # will expire unused
for l in find("HBA1C", "stored")[:1]:
    l.update(location="LF2-S1", excursionUsedH=3.5)
tg = find("TG", "stored")
tg[0].update(location="LF2-S2", excursionUsedH=3.5)       # 3.5 h of a 4 h budget already consumed
for l in find("HDL", "stored")[1:]:
    LOTS.remove(l)                                          # HDL is under its reorder point
LOTS.append(mk_lot(a_["GLU"], state="transit", location="In transit - PO-2611-07", expiry=dstr(TODAY + pd.Timedelta(days=300)), received=None))
LOTS.append(mk_lot(a_["GLU"], state="transit", location="In transit - PO-2611-07", expiry=dstr(TODAY + pd.Timedelta(days=300)), received=None))
LOTS.append(mk_lot(a_["LIP"], state="quarantine", location="LF2-S2", expiry=dstr(TODAY + pd.Timedelta(days=95)), excursionUsedH=5.5,
                   received=dstr(TODAY - pd.Timedelta(days=30))))

# ---- cold-chain storage temperature logs (last 14 days, hourly) ----
SR = np.random.default_rng(77)
nlog = 14 * 24
tlog = pd.date_range(END - pd.Timedelta(hours=nlog - 1), periods=nlog, freq="h")
cr1 = 4.4 + 0.35 * np.sin(np.arange(nlog) / 3.1) + SR.normal(0, 0.12, nlog)
lf1 = 5.0 + 0.5 * np.sin(np.arange(nlog) / 2.2) + SR.normal(0, 0.2, nlog) + np.where((tlog.hour >= 9) & (tlog.hour <= 16), 0.6, 0)
lf2 = 5.4 + 0.6 * np.sin(np.arange(nlog) / 2.0) + SR.normal(0, 0.25, nlog) + np.where((tlog.hour >= 9) & (tlog.hour <= 16), 0.5, 0)
exc_start = nlog - 3 * 24 - 16                             # power cut three days ago, back-up did not hold LF-2
lf2[exc_start:exc_start + 5] = [9.2, 11.6, 13.1, 12.2, 8.6]
STORAGE = [
    dict(id="CR1", name="Cold room CR-1", kind="Walk-in cold room", range=[2, 8], capacity=48, logger="LOG-CR1 (dual probe)", temps=cr1.tolist()),
    dict(id="LF1", name="Lab refrigerator LF-1", kind="Pharmacy-grade refrigerator", range=[2, 8], capacity=12, logger="LOG-LF1", temps=lf1.tolist()),
    dict(id="LF2", name="Lab refrigerator LF-2", kind="Domestic-type refrigerator", range=[2, 8], capacity=12, logger="LOG-LF2", temps=lf2.tolist()),
]
for an in ANALYZERS:
    bt = np.array(an["hourly"]["bay_temp"], float)[-nlog:]
    STORAGE.append(dict(id=an["id"], name=f"{an['id']} reagent bay", kind="On-board refrigerated bay", range=[2, 8], capacity=len(an["menu"]),
                        logger="Analyzer telemetry", temps=[None if np.isnan(x) else float(x) for x in bt]))

fleet_events = [dict(unit=e["unit"], mode=e["mode"], day=round(e["t_end"], 2), downH=round(e["down_h"], 1), pre=round(e["pre"], 1), abrupt=e["abrupt"])
                for e in FAILS if e["t_end"] < DAYS]
site_fail_365 = [dict(unit=e["unit"], mode=e["mode"], comp=MODES[e["mode"]]["comp"], at=day_dt(e["t_end"]), downH=round(e["down_h"], 1))
                 for e in FAILS if e["unit"] in DEMO and DAYS - 365 <= e["t_end"] < DAYS]
mode_recall = {m: (R_GBM["by_mode"][m]["detected"] / max(1, R_GBM["by_mode"][m]["events"]) if m in R_GBM["by_mode"] else None) for m in MODES}


def bt_pub(b):
    return dict(spend=b["spend"], wasteOnboard=b["waste_obs"], wasteShelf=b["waste_shelf"], qc=b["qc"], stockoutTests=b["stockout_tests"],
                usedTests=b["used_tests"], loads=b["loads"], holds=b["holds"],
                months=[dict(m=k, **v) for k, v in sorted(b["months"].items())])


OUT = dict(
    meta=dict(now=iso_dt(END), start=iso_dt(START), days=DAYS, site="District Hospital Laboratory, LAB-01", generated=pd.Timestamp.now().strftime("%Y-%m-%d %H:%M"),
              note="All data is synthetic. Prototype - not clinically validated."),
    assays=ASSAY, menu=MENU, analyzers=ANALYZERS, lots=LOTS, storage=STORAGE, storageStart=iso_dt(tlog[0]),
    suppliers=[dict(name=n, leadMean=l, leadSd=s) for n, l, s in SUPPLIERS],
    demand=dict(start=dstr(DATES[DAYS - 180]), history={c: DEMAND[c].values[DAYS - 180:DAYS].tolist() for c in codes},
                forecast={c: FC[c].tolist() for c in codes}, fcStart=dstr(DATES[DAYS]), band=FC_ASSAY,
                holidays=[dstr(d) for d in HOLIDAYS], camps=[dstr(d) for d in CAMPS]),
    hourProfile=HOURPROF_N.tolist(),
    models=dict(
        risk=dict(gbm=R_GBM, rule=R_RULE, iso=R_ISO, threshold=THR, thresholdProb=float(CAL.predict([THR])[0]), curve=CURVE, posRate=POS_RATE, alwaysNormalAcc=ALWAYS_NORMAL_ACC,
                  leakPrAuc=leak_ap, stress=STRESS, importance=IMPORT, modeRecall=mode_recall, board=board,
                  split=dict(train=len(tr), val=len(va), test=len(te), trainEnd=iso_dt(TS[T1]), valEnd=iso_dt(TS[T2])),
                  fleet=dict(units=len(UNITS), rows=int(N_ROWS), failures=len([e for e in FAILS if e["t_end"] < DAYS]),
                             pmCorrected=len([e for e in EVENTS if e["caught"] and e["t_end"] < DAYS]), sensorFaults=len(SFAULTS),
                             byMode={m: len([e for e in FAILS if e["mode"] == m and e["t_end"] < DAYS]) for m in MODES})),
        forecast=dict(metrics=FC_METRICS, best=FC_BEST, holdoutDays=HO, perAssay=FC_ASSAY)),
    backtest=dict(base=bt_pub(BT_BASE), lp=bt_pub(BT_LP)),
    siteFailures=site_fail_365, fleetEvents=fleet_events,
    modes={m: dict(comp=p["comp"], down=p["down"], pre=list(p["pre"])) for m, p in MODES.items()},
)


def clean(o):
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, (np.floating, float)):
        return None if (o != o or o in (float("inf"), float("-inf"))) else round(float(o), 3)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    return o


os.makedirs(os.path.join(ROOT, "web", "data"), exist_ok=True)
with open(os.path.join(ROOT, "web", "data", "lp-data.js"), "w", encoding="utf-8") as fh:
    fh.write("window.LP_DATA = " + json.dumps(clean(OUT), separators=(",", ":")) + ";\n")

os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
pd.DataFrame([dict(unit=e["unit"], model=e["model"], failure_mode=e["mode"], component=MODES[e["mode"]]["comp"], degradation_start=day_dt(e["t_start"]),
                   event_time=day_dt(e["t_end"]), outcome="corrected_at_pm" if e["caught"] else "unplanned_failure", downtime_h=round(e["down_h"], 1),
                   abrupt=e["abrupt"]) for e in EVENTS if e["t_end"] < DAYS]).to_csv(os.path.join(ROOT, "data", "failure_events.csv"), index=False)
DEMAND.iloc[:DAYS].rename_axis("date").to_csv(os.path.join(ROOT, "data", "test_volume_daily.csv"))
pd.DataFrame(LOTS).to_csv(os.path.join(ROOT, "data", "reagent_inventory.csv"), index=False)
pd.DataFrame(ASSAY).to_csv(os.path.join(ROOT, "data", "assay_stability_rules.csv"), index=False)
print("done.", flush=True)
