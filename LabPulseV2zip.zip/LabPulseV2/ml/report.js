// Quick console summary of the exported model results:  node ml/report.js
global.window = {};
require('../web/data/lp-data.js');
const D = window.LP_DATA, r = D.models.risk, f = o => JSON.stringify(o);
for (const k of ['gbm', 'rule', 'iso']) {
  const g = r[k];
  console.log(k, 'recall', g.recall, `(${g.detected}/${g.events})`, 'FA/unit-month', g.fa_per_unit_month, 'lead d', g.median_lead_d, 'PR-AUC', g.pr_auc, 'precision', g.alert_precision, f(g.episodes), f(g.by_mode));
}
console.log('positive rate', r.posRate, 'random-split PR-AUC (leaky)', r.leakPrAuc, 'threshold', r.threshold);
r.stress.forEach(s => console.log('  stress:', s.name, '| recall', s.recall, 'fa', s.fa, 'lead', s.lead, 'ap', s.pr_auc, 'events', s.events));
console.log('importance', r.importance.map(i => i.group + ':' + i.drop).join(' | '));
console.log('fleet', f(r.fleet));
for (const k of ['base', 'lp']) {
  const b = D.backtest[k];
  console.log(k, 'spend', Math.round(b.spend), 'waste on-board', Math.round(b.wasteOnboard), 'waste shelf', Math.round(b.wasteShelf), 'qc', Math.round(b.qc), 'stockout tests', Math.round(b.stockoutTests), 'used', Math.round(b.usedTests), 'holds', b.holds);
}
D.analyzers.forEach(a => {
  console.log(a.id, a.model, 'risk', a.risk, '| drivers', a.drivers.slice(0, 3).map(d => d.signal + ' z=' + d.z).join('; '));
  for (const c in a.components) if (a.components[c].rul || (a.components[c].health !== null && a.components[c].health < 90)) console.log('    ', c, a.components[c].health, f(a.components[c].rul));
  console.log('     hidden', a.hidden.map(h => h.mode + ' in ' + h.inDays + 'd').join(', '), '| risk tail', a.riskSeries.slice(-8).join(','), '| past failures', a.events.filter(e => !e.caught).length);
});
console.log('CRP forecast next 7d', D.demand.forecast.CRP.slice(0, 7).join(','));
console.log('forecast metrics', f(D.models.forecast.metrics));
