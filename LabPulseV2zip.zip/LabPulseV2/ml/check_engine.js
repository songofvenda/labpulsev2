// Sanity harness for the browser engines, run outside the browser:  node ml/check_engine.js
global.window = global;
require('../web/data/lp-data.js');
require('../web/js/engine.js');
const LP = global.LP, D = LP.D, r = x => Math.round(x * 10) / 10;
let bad = 0;
const chk = (name, v) => { if (v == null || Number.isNaN(v) || !Number.isFinite(v)) { bad++; console.log('  !! non-finite:', name, v); } };

console.log('== brief example: 400 tests, 45/day, 6 d on board, 45 d to expiry');
console.log('  opened  :', JSON.stringify(LP.quickTwin(400, 45, 6, 45, true, 0, 0)));
console.log('  unopened:', JSON.stringify(LP.quickTwin(400, 45, 6, 45, false, 0, 0)));

console.log('== on-board twins');
let atRisk = 0;
D.lots.filter(l => l.state === 'onboard').forEach(l => {
  const t = LP.twin(l);
  ['usable', 'waste', 'wasteValue', 'windowDays'].forEach(k => chk(l.id + '.' + k, t[k]));
  atRisk += t.wasteValue;
  if (t.status !== 'ok') console.log('  ', l.assay.padEnd(6), l.analyzer, 'rem', l.remaining, 'window', r(t.windowDays), '(' + t.binding.key + ')', 'usable', r(t.usable), 'waste', r(t.waste), '[' + r(t.wasteLo) + '-' + r(t.wasteHi) + ']', 'Rs', Math.round(t.wasteValue), t.status);
});
console.log('  on-board value at risk Rs', Math.round(atRisk));

console.log('== stored lots at risk');
D.lots.filter(l => l.state !== 'onboard').forEach(l => { const t = LP.twin(l); chk(l.id, t.wasteValue); if (t.status !== 'ok') console.log('  ', l.assay, l.lotNo, l.state, 'exp in', LP.daysTo(l.expiry), 'waste', r(t.waste), 'Rs', Math.round(t.wasteValue), t.status); });

console.log('== advisor: CRP on BA-01');
const ad = LP.advise('CRP', 'BA-01');
console.log('  verdict', ad.verdict, 'saving Rs', Math.round(ad.saving), 'cover', r(ad.coverDays));
ad.options.forEach(o => console.log('   -', o.title, '| waste', r(o.waste), 'Rs', Math.round(o.wasteValue)));

console.log('== reorder');
LP.abc(D.assays.map(a => LP.reorder(a.code))).forEach(x => {
  ['mu', 'rop', 'safety', 'cover', 'usable'].forEach(k => chk(x.code + '.' + k, x[k]));
  console.log('  ', x.code.padEnd(6), x.abc + x.xyz, 'mu', r(x.mu), 'ROP', Math.round(x.rop), 'SS', Math.round(x.safety), 'usable', Math.round(x.usable), 'onOrder', x.onOrder, 'cover', x.cover, 'd', x.status.padEnd(8), 'qty', x.qty, x.pack, 'effL', r(x.effL), 'effS', r(x.effS), 'wasteRs', Math.round(x.wasteValue));
});

console.log('== analyzers');
D.analyzers.forEach(a => { const s = LP.analyzerStatus(a.id); const b = LP.bayOutlook(a.id); console.log('  ', a.id, s.label, 'health', s.health, 'worst', s.worst.key, r(s.worst.health), 'bay', r(b.now), 'slope', r(b.slope), 'cross', b.crossIn == null ? '-' : r(b.crossIn)); });

console.log('== decision engine');
['BA-01', 'BA-03'].forEach(id => {
  const d = LP.decide(id);
  ['unplannedCost', 'plannedCost', 'avoided', 'routed', 'held'].forEach(k => chk(id + '.' + k, d[k]));
  console.log('  ', id, d.mode, 'deadline', d.deadline, 'slot', LP.fmtDay(d.slot.day), d.slot.hour + ':00', d.dur + 'h', 'displaced', r(d.slot.displaced), 'routed', r(d.routed), 'held', r(d.held));
  console.log('     cost unplanned', Math.round(d.unplannedCost), 'planned', Math.round(d.plannedCost), 'avoided', Math.round(d.avoided), 'waste base/unpl/plan', Math.round(d.wasteBase), Math.round(d.wasteUnplanned), Math.round(d.wastePlanned), 'truth', JSON.stringify(d.truth));
  d.capacity.forEach(c => console.log('     capacity', c.id, r(c.own), '+', r(c.extra), '/', c.limit, c.ok));
  d.reagent.slice(0, 4).forEach(x => console.log('     reagent:', x.text));
  d.reroute.filter(x => x.kind === 'hold').forEach(x => console.log('     hold:', x.code, r(x.tests)));
});

console.log('== savings');
const s = LP.savings();
['total', 'net', 'roi', 'paybackMonths', 'downGross', 'reagentGross'].forEach(k => chk('savings.' + k, s[k]));
console.log('  downtime base', Math.round(s.baseDown), 'lp', Math.round(s.lpDown), 'hours', r(s.hoursBase), '->', r(s.hoursLp), 'events', s.rows.length);
console.log('  reagent waste', Math.round(s.waste), 'qc', Math.round(s.qc), 'stockout', Math.round(s.stockout), '| total(realised)', Math.round(s.total), 'net', Math.round(s.net), 'roi', r(s.roi), 'payback mo', r(s.paybackMonths));
console.log(bad ? ('FAILED: ' + bad + ' non-finite values') : 'OK: all engine outputs finite');
