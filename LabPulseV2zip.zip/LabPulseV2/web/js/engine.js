/* LabPulse V2 - decision engines (deterministic, rule-based; runs in the browser and in Node for tests).
   AI forecasts demand and failure risk. Stability and expiry are RULES taken from the manufacturer insert:
   the engine never lets a model override them. */
(function (root) {
  'use strict';
  const D = root.LP_DATA;
  const DAY = 86400000;
  const NOW = new Date(D.meta.now);
  const TODAY = new Date(D.meta.now.slice(0, 10) + 'T00:00');
  const A = {}; D.assays.forEach(a => { A[a.code] = a; });
  const AN = {}; D.analyzers.forEach(a => { AN[a.id] = a; });
  const daysTo = d => Math.round((new Date(d + 'T00:00') - TODAY) / DAY);
  const addDays = n => new Date(TODAY.getTime() + n * DAY);
  const sum = a => a.reduce((x, y) => x + y, 0);
  const mean = a => a.length ? sum(a) / a.length : 0;
  const sd = a => { const m = mean(a); return Math.sqrt(mean(a.map(x => (x - m) * (x - m)))); };

  // ---- shared, user-adjustable operating state -------------------------------------------------
  const state = {
    routing: {},          // assay -> { analyzerId: share }
    downDays: {},         // analyzerId -> { dayIndex: fractionOfDayUnavailable }
    override: {},         // assay -> { an, until }: temporary 'run it all here until day N' instruction
    approved: [],         // audit trail of human approvals
    params: {             // cost assumptions - every one is editable on the Savings screen
      premiumPerTest: 90, calloutCost: 18000, plannedVisitCost: 6000, workHourShare: 0.45, plannedHoursFactor: 0.35,
      plannedCostFactor: 0.25, realisation: 0.5, subscription: 120000,
    },
  };
  function defaultRouting() {
    const r = {};
    D.assays.forEach(a => {
      const on = D.lots.filter(l => l.assay === a.code && l.state === 'onboard').map(l => l.analyzer);
      const ids = on.length ? on : [D.analyzers.find(x => x.menu.includes(a.code)).id];
      r[a.code] = {}; ids.forEach(id => { r[a.code][id] = 1 / ids.length; });
    });
    return r;
  }
  state.routing = defaultRouting();

  // ---- demand ----------------------------------------------------------------------------------
  function fc(code, i) {                       // forecast patient tests for day offset i (0 = today)
    const f = D.demand.forecast[code];
    return i < f.length ? f[i] : f[f.length - 28 + ((i - f.length) % 28)];
  }
  function avail(an, i) { const d = state.downDays[an]; return d && d[i] != null ? 1 - d[i] : 1; }
  function need(code, an, i, routing) {        // tests this analyzer will draw from its bottle on day i
    const r = (routing || state.routing)[code] || {};
    let share = r[an] || 0;
    const ov = state.override[code];
    if (ov && i < ov.until) share = an === ov.an ? 1 : 0;      // time-boxed; normal routing resumes afterwards
    if (!share) return { patient: 0, qc: 0 };
    const av = avail(an, i);
    return { patient: fc(code, i) * share * av, qc: av > 0 ? A[code].qcPerDay : 0 };
  }

  // ---- analyzer cold-bay outlook (links machine health to reagent stability) -------------------
  function bayOutlook(anId) {
    const t = AN[anId].hourly.bay_temp.filter(x => x != null);
    const last = t.slice(-24), prev = t.slice(-120, -96);
    const now = mean(last), slope = (now - mean(prev)) / 4;        // deg C per day over the last 4 days
    const crossIn = now >= 8 ? 0 : (slope > 0.05 ? (8 - now) / slope : null);
    return { now, slope, crossIn, limit: 8 };
  }

  // ---- the reagent digital twin ----------------------------------------------------------------
  /* Each lot is governed by several independent manufacturer clocks. Which one binds depends on the
     lot's state - an unopened kit is NOT limited by on-board stability, an on-board bottle is limited
     by BOTH its on-board clock and its printed expiry, and a bottle on a warm bay loses its claim early. */
  function clocks(lot) {
    const a = A[lot.assay];
    const out = [];
    const shelf = daysTo(lot.expiry);
    out.push({ key: 'shelf', label: 'Manufacturer expiry (unopened / stored 2-8 °C)', total: a.shelfMonths * 30, left: shelf, applies: true,
      note: 'Printed expiry ' + lot.expiry });
    if (lot.state === 'onboard') {
      const onb = -daysTo(lot.loaded);
      out.push({ key: 'onboard', label: 'On-board stability (' + a.obs + ' days on a 2-8 °C bay)', total: a.obs, left: a.obs - onb, applies: true,
        note: 'Loaded ' + lot.loaded + ' on ' + lot.analyzer });
      const bay = bayOutlook(lot.analyzer);
      if (bay.crossIn != null) out.push({ key: 'bay', label: 'Bay temperature claim (' + lot.analyzer + ' bay drifting)', total: a.obs, left: bay.crossIn, applies: true,
        note: 'Bay at ' + bay.now.toFixed(1) + ' °C, rising ' + bay.slope.toFixed(2) + ' °C/day - on-board claim is void above 8 °C' });
      const calLeft = a.calDays - (onb % a.calDays);
      out.push({ key: 'cal', label: 'Calibration interval (' + a.calDays + ' days)', total: a.calDays, left: calLeft, applies: true, soft: true,
        note: 'Recalibration consumes ' + a.calTests + ' tests - it does not end the bottle' });
    } else {
      out.push({ key: 'onboard', label: 'On-board stability (' + a.obs + ' days)', total: a.obs, left: a.obs, applies: false, note: 'Clock starts only when the bottle is loaded' });
      out.push({ key: 'openvial', label: 'Open-vial stability (' + a.openVial + ' days, capped at 2-8 °C)', total: a.openVial, left: a.openVial, applies: false, note: 'Clock starts only at first opening' });
    }
    out.push({ key: 'excursion', label: 'Temperature-excursion budget (' + a.excursionBudgetH + ' h above 8 °C)', total: a.excursionBudgetH, left: a.excursionBudgetH - lot.excursionUsedH,
      applies: true, unit: 'h', soft: lot.excursionUsedH < a.excursionBudgetH, note: lot.excursionUsedH ? lot.excursionUsedH + ' h consumed' : 'No excursion recorded' });
    return out;
  }

  function twin(lot, opts) {
    opts = opts || {};
    const a = A[lot.assay];
    const perTest = lot.price / lot.bottleTests;
    const cl = clocks(lot);
    const res = { lot, assay: a, clocks: cl, perTest, value: lot.remaining * perTest };
    if (lot.state === 'quarantine' || lot.excursionUsedH >= a.excursionBudgetH) {
      return Object.assign(res, { status: 'quarantine', binding: cl.find(c => c.key === 'excursion'), usable: 0, waste: lot.remaining, wasteValue: lot.remaining * perTest, windowDays: 0,
        burn: [], headline: 'Quarantined - excursion budget exceeded', days: [] });
    }
    if (lot.state !== 'onboard') {
      const p = lotPlan(lot.assay)[lot.id] || {};
      const waste = p.waste || 0;
      let best = lot.remaining;                       // most that could still be used if this lot were issued ahead of the queue
      if (waste > 0) {
        const an0 = Object.keys(state.routing[lot.assay] || {})[0], span = Math.min(daysTo(lot.expiry), a.obs);
        let cap = 0; for (let i = 0; i < span; i++) { const n = need(lot.assay, an0, i); cap += n.patient + n.qc; }
        best = Math.max(0, Math.min(lot.remaining - a.dead - a.calTests, cap));
      }
      res.best = best; res.rescuable = Math.max(0, waste - (lot.remaining - best));
      return Object.assign(res, { status: waste > lot.bottleTests * 0.05 ? (waste > lot.bottleTests * 0.4 ? 'critical' : 'risk') : 'ok', binding: cl[0], usable: lot.remaining - waste,
        waste, wasteValue: waste * perTest, windowDays: daysTo(lot.expiry), plan: p, burn: [], days: [],
        headline: waste > 0 ? (daysTo(lot.expiry) < 60 ? 'Will expire on the shelf before the queue reaches it' : 'Pack is larger than demand can empty inside its on-board stability') : 'On track to be consumed before expiry' });
    }
    const hard = cl.filter(c => c.applies && !c.soft && c.unit !== 'h');
    const binding = hard.reduce((m, c) => (c.left < m.left ? c : m), hard[0]);
    const window = Math.max(0, binding.left);
    const an = opts.analyzer || lot.analyzer;
    const mult = opts.demandMult || 1;
    const calIn = cl.find(c => c.key === 'cal').left;
    let rem = Math.max(0, lot.remaining - a.dead), usedP = 0, usedQ = 0, usedCal = 0, emptyDay = null;
    const days = [], burn = [{ d: 0, rem: lot.remaining, lo: lot.remaining, hi: lot.remaining }];
    let remLo = rem, remHi = rem;
    const band = D.demand.band[lot.assay];
    for (let i = 0; i < Math.ceil(window); i++) {
      const frac = Math.min(1, window - i);
      const n = need(lot.assay, an, i, opts.routing);
      let p = n.patient * frac * mult, q = n.qc * frac, c = (calIn >= i && calIn < i + 1 && i > 0) ? a.calTests : 0;
      const want = p + q + c, take = Math.min(rem, want), k = want ? take / want : 0;
      usedP += p * k; usedQ += q * k; usedCal += c * k; rem -= take;
      remLo = Math.max(0, remLo - (p * band.p90 + q + c)); remHi = Math.max(0, remHi - (p * band.p10 + q + c));
      days.push({ i, patient: p * k, qc: q * k, cal: c * k });
      burn.push({ d: i + frac, rem: rem + a.dead, lo: remLo + a.dead, hi: remHi + a.dead });
      if (rem <= 0.5 && emptyDay == null) { emptyDay = i + (want ? take / want : 1); break; }
    }
    const waste = rem;                                // usable reagent that the clocks will take away
    const wasteLo = remLo, wasteHi = remHi;
    const wv = waste * perTest;
    const status = waste > 0.25 * lot.bottleTests || wv > 5000 ? 'critical' : (waste > 0.05 * lot.bottleTests || wv > 1200 ? 'risk' : 'ok');
    return Object.assign(res, {
      status, binding, windowDays: window, usable: usedP + usedQ + usedCal, usedPatient: usedP, usedQc: usedQ, usedCal, dead: a.dead,
      waste, wasteLo, wasteHi, wasteValue: wv, emptyDay, burn, days,
      avgDaily: window > 0 ? (usedP + (waste > 0 ? 0 : 0)) / Math.max(1, Math.min(window, emptyDay || window)) : 0,
      headline: waste > 1 ? Math.round(waste) + ' tests will be lost when the ' + (binding.key === 'shelf' ? 'printed expiry' : binding.key === 'bay' ? 'bay temperature claim' : 'on-board stability') + ' ends'
        : 'Will be fully consumed ' + (emptyDay != null ? 'in ' + emptyDay.toFixed(1) + ' days' : 'within its stability window'),
    });
  }

  /* The worked example from the brief, as a pure function - used by the calculator on the Reagent screen. */
  function quickTwin(remaining, perDay, onboardLeft, expiryLeft, opened, qcPerDay, dead) {
    const window = opened ? Math.min(onboardLeft, expiryLeft) : expiryLeft;
    const binding = opened ? (onboardLeft <= expiryLeft ? 'on-board stability' : 'manufacturer expiry') : 'manufacturer expiry';
    const capacity = window * (perDay + (qcPerDay || 0));
    const available = Math.max(0, remaining - (dead || 0));
    const usable = Math.min(available, capacity);
    const naive = Math.min(remaining, Math.min(onboardLeft, expiryLeft) * perDay);
    return { window, binding, capacity, usable, waste: available - usable, dead: dead || 0, naiveUsable: naive, runOut: perDay ? available / (perDay + (qcPerDay || 0)) : Infinity };
  }

  // ---- lot plan: simulate FEFO consumption of an assay across all its lots ----------------------
  const planCache = {};
  function lotPlan(code, opts) {
    opts = opts || {};
    const key = code + JSON.stringify(opts) + JSON.stringify(state.routing[code]) + JSON.stringify(state.downDays) + JSON.stringify(state.override);
    if (planCache[key]) return planCache[key];
    const a = A[code], routing = opts.routing || state.routing;
    const H = opts.horizon || 150;
    const lots = D.lots.filter(l => l.assay === code);
    const out = { _daily: [], _stockout: null, _waste: 0, _wasteValue: 0, _unmet: 0 };
    const onb = {};
    Object.keys(routing[code] || {}).forEach(an => { onb[an] = null; });
    lots.filter(l => l.state === 'onboard').forEach(l => {
      const c = clocks(l).filter(x => x.applies && !x.soft && x.unit !== 'h');
      const left = Math.min.apply(null, c.map(x => x.left));
      const b = { id: l.id, rem: l.remaining, left, per: l.price / l.bottleTests };
      out[l.id] = { openDay: daysTo(l.loaded), emptyDay: null, waste: 0, cause: null };
      if (l.analyzer in onb) onb[l.analyzer] = b; else { out[l.id].waste = Math.max(0, l.remaining - a.dead); out[l.id].cause = 'unrouted'; }
    });
    let stock = lots.filter(l => l.state === 'stored' || l.state === 'transit')
      .map(l => ({ id: l.id, tests: l.bottleTests, exp: daysTo(l.expiry), arr: l.state === 'transit' ? 2 : 0, per: l.price / l.bottleTests }))
      .sort((x, y) => x.exp - y.exp);
    (opts.extraStock || []).forEach(s => stock.push(s));
    stock.forEach(s => { out[s.id] = { openDay: null, emptyDay: null, waste: 0, cause: null }; });
    for (let d = 0; d < H; d++) {
      stock.filter(s => s.exp < d).forEach(s => { out[s.id].waste = s.tests; out[s.id].cause = 'shelf'; out._waste += s.tests; out._wasteValue += s.tests * s.per; });
      stock = stock.filter(s => s.exp >= d);
      for (const an in onb) {
        const n = need(code, an, d, routing);
        let want = n.patient + n.qc, guard = 0;
        while (want > 0.01 && guard++ < 4) {
          let b = onb[an];
          if (b && (b.left <= 0 || b.rem <= a.dead)) {
            const w = Math.max(0, b.rem - a.dead);
            if (w > 0.5) { out[b.id].waste = w; out[b.id].cause = 'onboard'; out._waste += w; out._wasteValue += w * b.per; }
            out[b.id].emptyDay = d; onb[an] = b = null;
          }
          if (!b) {
            const idx = stock.findIndex(s => s.arr <= d);
            if (idx < 0) { if (out._stockout == null) out._stockout = d; out._unmet += n.patient; break; }
            const s = stock.splice(idx, 1)[0];
            b = onb[an] = { id: s.id, rem: s.tests - a.calTests, left: Math.min(a.obs, s.exp - d), per: s.per };
            out[s.id].openDay = d; out[s.id].analyzer = an;
          }
          const take = Math.min(b.rem - a.dead, want);
          b.rem -= take; want -= take;
          if (b.rem > a.dead + 0.01) break;
        }
      }
      for (const an in onb) if (onb[an]) onb[an].left -= 1;
      out._daily.push(sum(Object.values(onb).map(b => (b ? Math.max(0, b.rem - a.dead) : 0))) + sum(stock.filter(s => s.arr <= d).map(s => s.tests)));
    }
    planCache[key] = out;
    return out;
  }

  // ---- pre-load advisor: what happens if the technician opens / loads this kit now? -------------
  function advise(code, anId, opts) {
    opts = opts || {};
    const a = A[code];
    const cur = D.lots.find(l => l.assay === code && l.state === 'onboard' && l.analyzer === anId);
    const curT = cur ? twin(cur) : null;
    const stored = D.lots.filter(l => l.assay === code && l.state === 'stored').sort((x, y) => daysTo(x.expiry) - daysTo(y.expiry));
    const kit = opts.lot || stored[0];
    const shelfLeft = kit ? daysTo(kit.expiry) : a.shelfMonths * 30;
    const coverDays = curT ? (curT.emptyDay != null ? curT.emptyDay : curT.windowDays) : 0;   // days the current bottle keeps serving
    function sim(startDay, tests, price, an, routing) {
      // a new bottle opened on startDay: its on-board clock starts at once, but it is only drawn on once the current bottle is done
      const drawFrom = an === anId ? Math.max(startDay, Math.ceil(coverDays - 0.001)) : startDay;
      const end = startDay + Math.min(a.obs, shelfLeft - startDay);
      let rem = tests - a.calTests - a.dead, used = 0;
      for (let d = drawFrom; d < end && rem > 0; d++) { const n = need(code, an, d, routing); const t = Math.min(rem, n.patient + n.qc); rem -= t; used += t; }
      const per = price / tests;
      return { waste: Math.max(0, rem), wasteValue: Math.max(0, rem) * per, used, end, idleDays: drawFrom - startDay, per };
    }
    const options = [];
    const mk = (id, title, detail, r, extra) => options.push(Object.assign({ id, title, detail, waste: r.waste, wasteValue: r.wasteValue + ((extra && extra.cost) || 0), sim: r }, extra || {}));
    const now = sim(0, a.bottle, a.price, anId);
    mk('now', 'Open and load on ' + anId + ' now', now.idleDays > 0 ? 'The current bottle still serves ' + anId + ' for ' + coverDays.toFixed(1) + ' days. The new bottle would sit on board with its ' + a.obs + '-day clock running, unused, for ' + now.idleDays + ' days.' : 'No bottle in use - the new bottle is drawn on immediately.', now);
    if (cur && coverDays >= 1) {
      const w = Math.ceil(coverDays - 0.001);
      const later = sim(w, a.bottle, a.price, anId);
      mk('wait', 'Wait - load on ' + fmtDay(w) + ' when the current bottle ends', 'The on-board clock starts only when the reagent is needed. Keep the kit sealed in cold storage until then.', later, { day: w });
      const small = sim(w, a.smallBottle, a.smallPrice, anId);
      const smallExtra = (small.used) * (small.per - a.price / a.bottle);
      mk('small', 'Wait, then load the ' + a.smallBottle + '-test pack instead', 'The smaller pack matches ' + a.obs + ' days of demand on this analyzer. It costs ' + Math.round((small.per / (a.price / a.bottle) - 1) * 100) + '% more per test but leaves nothing to discard.', small, { day: w, cost: smallExtra, premium: smallExtra });
    }
    D.analyzers.filter(x => x.id !== anId && x.menu.includes(code)).forEach(x => {
      const has = D.lots.some(l => l.assay === code && l.state === 'onboard' && l.analyzer === x.id);
      if (has) return;
      const routing = JSON.parse(JSON.stringify(state.routing)); routing[code] = routing[code] || {};
      const ids = Object.keys(routing[code]).concat([x.id]); ids.forEach(id => { routing[code][id] = 1 / ids.length; });
      const r = sim(0, a.bottle, a.price, x.id, routing);
      mk('other-' + x.id, 'Load on ' + x.id + ' and split ' + code + ' across ' + ids.length + ' analyzers', 'Adds a second position: redundancy improves, but each bottle now sees 1/' + ids.length + ' of the demand and ' + a.qcPerDay + ' extra QC tests a day.', r, { analyzer: x.id, cost: a.qcPerDay * a.obs * a.price / a.bottle });
    });
    options.sort((x, y) => x.wasteValue - y.wasteValue);
    const best = options[0], nowOpt = options.find(o => o.id === 'now');
    const verdict = nowOpt.wasteValue - best.wasteValue > 500 ? 'hold' : (nowOpt.waste > 0.1 * a.bottle ? 'caution' : 'go');
    return { assay: a, analyzer: anId, current: curT, kit, options, best, now: nowOpt, verdict, saving: nowOpt.wasteValue - best.wasteValue, coverDays };
  }

  // ---- cold-chain stores: reorder levels from consumption patterns ------------------------------
  function reorder(code) {
    const a = A[code];
    const hist = D.demand.history[code].slice(-56);
    const positions = Object.keys(state.routing[code] || {}).length || 1;
    const mu = mean(Array.from({ length: 28 }, (_, i) => fc(code, i))) + positions * a.qcPerDay;
    const sigma = sd(hist);
    const cv = sigma / Math.max(1, mean(hist));
    const supName = (D.lots.find(l => l.assay === code) || {}).supplier;
    const sup = D.suppliers.find(s => s.name === supName) || D.suppliers[0];
    const z = 1.65;                                               // 95% cycle service level
    const safety = z * Math.sqrt(sup.leadMean * sigma * sigma + mu * mu * sup.leadSd * sup.leadSd);
    const rop = mu * sup.leadMean + safety;
    const plan = lotPlan(code);
    const lots = D.lots.filter(l => l.assay === code);
    const onHand = sum(lots.filter(l => l.state === 'onboard' || l.state === 'stored').map(l => l.remaining));
    const usable = onHand - plan._waste;
    const onOrder = sum(lots.filter(l => l.state === 'transit').map(l => l.bottleTests));
    const cover = plan._stockout != null ? plan._stockout : 150;
    const perPos = (mu / positions);
    const largeLife = Math.min(a.obs, (a.bottle - a.dead) / perPos), smallLife = Math.min(a.obs, (a.smallBottle - a.dead) / perPos);
    const costL = a.price / (perPos * largeLife), costS = a.smallPrice / (perPos * smallLife);     // effective cost per test actually used
    const pack = costS < costL ? 'S' : 'L';
    const bottle = pack === 'S' ? a.smallBottle : a.bottle, price = pack === 'S' ? a.smallPrice : a.price;
    const reviewDays = 7, targetCover = 30;
    const shelfCap = mu * Math.min(a.shelfMonths * 30 * 0.5, 75);  // never hold more than can be used within half the shelf life
    const target = Math.min(mu * (sup.leadMean + reviewDays + targetCover) + safety, shelfCap + safety);
    const position = usable + onOrder;
    const qtyTests = Math.max(0, target - position);
    const qty = position <= rop ? Math.ceil(qtyTests / bottle) : 0;
    const orderIn = Math.max(0, Math.floor((position - rop) / mu));
    return { code, assay: a, mu, sigma, cv, supplier: sup, safety, rop, onHand, usable, onOrder, position, cover, pack, bottle, price, qty, orderValue: qty * price,
      orderIn, status: position <= rop ? (cover < sup.leadMean ? 'critical' : 'order') : (orderIn <= 7 ? 'soon' : 'ok'), plan,
      xyz: cv < 0.35 ? 'X' : (cv < 0.6 ? 'Y' : 'Z'), annualValue: mu * 365 * a.perTest, costL, costS, wasteValue: plan._wasteValue,
      effL: Math.min(1, perPos * a.obs / (a.bottle - a.dead)), effS: Math.min(1, perPos * a.obs / (a.smallBottle - a.dead)) };
  }
  function abc(rows) {
    const s = rows.slice().sort((x, y) => y.annualValue - x.annualValue), tot = sum(s.map(r => r.annualValue));
    let c = 0; s.forEach(r => { c += r.annualValue; r.abc = c / tot <= 0.7 ? 'A' : (c / tot <= 0.9 ? 'B' : 'C'); });
    return rows;
  }
  function excursions(st) {                                      // hours above range in a storage temperature log
    let hours = 0, peak = -99, start = null; const ev = [];
    st.temps.forEach((t, i) => {
      if (t != null && t > st.range[1]) { hours++; peak = Math.max(peak, t); if (start == null) start = i; }
      else if (start != null) { ev.push({ start, hours: i - start, peak: Math.max.apply(null, st.temps.slice(start, i)) }); start = null; }
    });
    if (start != null) ev.push({ start, hours: st.temps.length - start, peak: Math.max.apply(null, st.temps.slice(start).filter(x => x != null)), open: true });
    return { hours, peak, events: ev };
  }
  function trace(lot) {                                          // batch genealogy: supplier -> stores -> analyzer -> tests
    const a = A[lot.assay], ev = [];
    const rec = lot.received || null;
    const d = n => addDays(n).toISOString().slice(0, 10);
    if (rec) {
      const r = daysTo(rec);
      ev.push({ date: d(r - 3), type: 'Dispatch', text: 'Shipped by ' + lot.supplier + ' in a validated cold box, data logger attached', ok: true });
      ev.push({ date: rec, type: 'Goods receipt', text: 'Logger read at the dock: in range throughout transit. Shelf life at receipt ' + (daysTo(lot.expiry) - r) + ' days. Accepted by stores.', ok: true });
      ev.push({ date: rec, type: 'Put-away', text: 'Bin ' + (lot.state === 'onboard' ? 'CR1-B2' : (lot.location || '').replace(/^(BA.*)$/, 'CR1-B2')) + ', FEFO position assigned', ok: true });
    } else ev.push({ date: d(-2), type: 'Dispatch', text: 'Shipped by ' + lot.supplier + ', expected in 2 days', ok: true });
    if (lot.excursionUsedH) ev.push({ date: d(-3), type: 'Temperature excursion', text: lot.excursionUsedH + ' h above 8 °C during the power cut (peak 13.1 °C). Budget ' + a.excursionBudgetH + ' h: ' + (lot.excursionUsedH >= a.excursionBudgetH ? 'exceeded - lot quarantined' : 'within the manufacturer allowance, lot stays usable'), ok: lot.excursionUsedH < a.excursionBudgetH, warn: true });
    if (lot.loaded) {
      const used = lot.bottleTests - lot.remaining;
      ev.push({ date: lot.loaded, type: 'Issued and loaded', text: 'Opened and loaded on ' + lot.analyzer + '. On-board clock started (' + a.obs + ' days).', ok: true });
      ev.push({ date: lot.loaded, type: 'Calibration + QC', text: '2-point calibration accepted, QC levels 1 and 2 within ±2 SD. ' + a.calTests + ' tests consumed.', ok: true });
      ev.push({ date: d(0), type: 'In use', text: Math.max(0, Math.round(used - a.calTests - a.qcPerDay * -daysTo(lot.loaded))) + ' patient results and ' + (a.qcPerDay * -daysTo(lot.loaded)) + ' QC runs traceable to this lot', ok: true });
    }
    return ev.sort((x, y) => (x.date < y.date ? -1 : 1));
  }

  // ---- analyzer status --------------------------------------------------------------------------
  const COMP_LABEL = { lamp: 'Photometer lamp', probe: 'Sample probe & syringe', cooler: 'Reagent refrigeration', wash: 'Cuvette wash station', drive: 'Carousel drive', bath: 'Reaction bath', board: 'Power / control electronics' };
  function analyzerStatus(anId) {
    const an = AN[anId], thr = D.models.risk.thresholdProb;
    const comps = Object.keys(an.components).map(k => Object.assign({ key: k, label: COMP_LABEL[k] }, an.components[k]));
    const worst = comps.filter(c => c.health != null).sort((x, y) => x.health - y.health)[0];
    const withRul = comps.filter(c => c.rul).sort((x, y) => x.rul.lo - y.rul.lo)[0];
    const tier = !an.alerting ? 'ok' : (withRul && withRul.rul.lo < 5 ? 'critical' : 'risk');
    const health = Math.round(0.6 * worst.health + 0.4 * mean(comps.filter(c => c.health != null).map(c => c.health)));
    return { an, comps, worst, withRul, tier, health, alerting: an.alerting, risk: an.risk, thr,
      label: tier === 'ok' ? 'Normal' : tier === 'critical' ? 'Act now' : 'Plan service' };
  }

  // ---- cross-module decision engine -------------------------------------------------------------
  function hourlyLoad(anId, day) {                               // expected tests per hour on one analyzer for a day offset
    let tot = 0; D.assays.forEach(a => { tot += need(a.code, anId, day).patient; });
    return D.hourProfile.map(p => p * tot);
  }
  function decide(anId) {
    const st = analyzerStatus(anId), an = st.an, c = st.withRul || st.worst;
    const mode = c.key, down = D.modes[mode] ? D.modes[mode].down : 8;
    const deadline = c.rul ? Math.max(1, Math.floor(c.rul.lo)) : 7;
    const dur = Math.min(6, Math.max(2, Math.round(down * state.params.plannedHoursFactor)));
    // 1. maintenance window: least-disruption slot before the earliest plausible failure
    const slots = [];
    for (let d = 0; d <= Math.min(deadline, 6); d++) {
      const load = hourlyLoad(anId, d);
      [[7, 'early morning'], [14, 'afternoon'], [18, 'evening']].forEach(([h, name]) => {
        if (d === 0 && h < 14) return;
        const displaced = sum(load.slice(h, h + dur));
        slots.push({ day: d, hour: h, name, dur, displaced, date: addDays(d), score: displaced + d * 0.5 });
      });
    }
    slots.sort((x, y) => x.score - y.score);
    const slot = slots[0];
    // 2. re-route: where does each assay go while the analyzer is in service?
    const reroute = [];
    D.assays.forEach(a => {
      const sh = (state.routing[a.code] || {})[anId];
      if (!sh) return;
      const tests = sum(hourlyLoad(anId, slot.day).slice(slot.hour, slot.hour + dur)) * (need(a.code, anId, slot.day).patient / Math.max(1, sum(D.assays.map(x => need(x.code, anId, slot.day).patient))));
      const alts = D.analyzers.filter(x => x.id !== anId && x.menu.includes(a.code));
      const loaded = alts.filter(x => D.lots.some(l => l.assay === a.code && l.state === 'onboard' && l.analyzer === x.id));
      const healthy = loaded.filter(x => analyzerStatus(x.id).tier !== 'critical');
      let action, target = null, kind;
      if (healthy.length) { target = healthy.sort((x, y) => analyzerStatus(y.id).health - analyzerStatus(x.id).health)[0].id; action = 'Route to ' + target + ' (reagent on board, calibrated)'; kind = 'route'; }
      else if (alts.length) { target = alts[0].id; action = 'Hold and batch after service - ' + target + ' is validated but has no ' + a.code + ' on board; opening a bottle for ' + Math.round(tests) + ' tests would waste it'; kind = 'hold'; }
      else { action = 'Hold and batch after service - ' + anId + ' is the only validated analyzer'; kind = 'hold'; }
      reroute.push({ code: a.code, name: a.name, tests, action, target, kind });
    });
    const routed = sum(reroute.filter(r => r.kind === 'route').map(r => r.tests)), held = sum(reroute.filter(r => r.kind === 'hold').map(r => r.tests));
    // capacity check on receiving analyzers
    const cap = {};
    reroute.filter(r => r.kind === 'route').forEach(r => { cap[r.target] = (cap[r.target] || 0) + r.tests; });
    const capacity = Object.keys(cap).map(id => {
      const own = sum(hourlyLoad(id, slot.day).slice(slot.hour, slot.hour + dur));
      return { id, extra: cap[id], own, limit: AN[id].throughput * dur * 0.8, ok: own + cap[id] <= AN[id].throughput * dur * 0.8 };
    });
    // 3. reagent consequences: unplanned failure vs planned service
    const lots = D.lots.filter(l => l.state === 'onboard' && l.analyzer === anId);
    const failDay = c.rul ? Math.round(c.rul.mid) : 5;
    const saved = JSON.stringify(state.downDays);
    const wasteWith = scen => { state.downDays = scen; const v = sum(lots.map(l => twin(l).wasteValue)); state.downDays = JSON.parse(saved); return v; };
    const base = wasteWith(JSON.parse(saved));
    const unplannedScen = JSON.parse(saved); unplannedScen[anId] = Object.assign({}, unplannedScen[anId]); unplannedScen[anId][failDay] = Math.min(1, down / 10); if (down > 10) unplannedScen[anId][failDay + 1] = Math.min(1, (down - 10) / 10);
    const plannedScen = JSON.parse(saved); plannedScen[anId] = Object.assign({}, plannedScen[anId]); plannedScen[anId][slot.day] = sum(D.hourProfile.slice(slot.hour, slot.hour + dur));
    const wUnplanned = wasteWith(unplannedScen), wPlanned = wasteWith(plannedScen);
    const reagent = [];
    lots.forEach(l => {
      const t = twin(l);
      if (t.windowDays <= slot.day + 1 && t.waste < 1) reagent.push({ lot: l, text: l.assay + ' bottle ends before the service slot - do not load a replacement on ' + anId + ' until the service is signed off', kind: 'hold' });
      else if (t.status !== 'ok') reagent.push({ lot: l, text: l.assay + ' lot ' + l.lotNo + ': ' + Math.round(t.waste) + ' tests (₹' + Math.round(t.wasteValue).toLocaleString('en-IN') + ') already at risk - keep ' + l.assay + ' on ' + anId + ' right up to the slot, and do not open a new kit', kind: 'protect' });
    });
    // 3b. refrigeration fault: burn down the exposed bottles first by sending their assays to this analyzer
    let burn = null;
    if (mode === 'cooler') {
      reagent.length = 0;
      const until = Math.max(1, Math.ceil(bayOutlook(anId).crossIn || slot.day)), keep = JSON.stringify(state.override), ov = {};
      let before = 0, after = 0;
      lots.forEach(l => {
        if (twin(l).waste <= 1) return;
        const peers = D.lots.filter(x => x.assay === l.assay && x.state === 'onboard');      // every bottle of this assay, on any analyzer
        const w0 = sum(peers.map(x => twin(x).wasteValue)), t0 = twin(l).waste;
        state.override[l.assay] = { an: anId, until };
        const w1 = sum(peers.map(x => twin(x).wasteValue)), t1 = twin(l).waste;
        state.override = JSON.parse(keep);
        if (w0 - w1 > 50) { ov[l.assay] = { an: anId, until }; before += w0; after += w1;
          reagent.push({ lot: l, kind: 'burn', text: l.assay + ' lot ' + l.lotNo + ': run all ' + l.assay + ' on ' + anId + ' for the next ' + until + ' days - tests at risk fall from ' + Math.round(t0) + ' to ' + Math.round(t1) + ', with no new loss on the other analyzers' }); }
        else reagent.push({ lot: l, kind: 'hold', text: l.assay + ' lot ' + l.lotNo + ': re-routing would only move the loss to another bottle - leave routing as it is and do not replace this bottle on ' + anId });
      });
      burn = { before, after, override: ov, until };
    }
    // 4. money
    const p = state.params, tph = an.tests30 / 30 / 10;
    const workH = down * p.workHourShare;
    const unplannedCost = workH * tph * p.premiumPerTest + p.calloutCost + (wUnplanned - base);
    const plannedCost = slot.displaced * 0 + p.plannedVisitCost + held * 0 + (wPlanned - base);
    return { st, comp: c, mode, deadline, dur, slots: slots.slice(0, 4), slot, reroute, routed, held, capacity, reagent, failDay, down, burn, plannedScen,
      wasteBase: base, wasteUnplanned: wUnplanned, wastePlanned: wPlanned, unplannedCost, plannedCost, avoided: unplannedCost - plannedCost, tph, workH,
      truth: an.hidden.find(h => h.mode === mode) || null };
  }

  // ---- savings ----------------------------------------------------------------------------------
  function savings() {
    const p = state.params, b = D.backtest.base, l = D.backtest.lp, rec = D.models.risk.modeRecall;
    const tph = mean(D.analyzers.map(a => a.tests30 / 30 / 10));
    let baseDown = 0, lpDown = 0, hoursBase = 0, hoursLp = 0;
    const rows = D.siteFailures.map(e => {
      const pr = Math.min(0.9, rec[e.mode] == null ? 0 : rec[e.mode]);   // capped: a handful of held-out events cannot justify 100%
      const full = e.downH * p.workHourShare * tph * p.premiumPerTest + p.calloutCost;
      const planned = e.downH * p.plannedHoursFactor * p.workHourShare * tph * p.premiumPerTest * p.plannedCostFactor + p.plannedVisitCost;
      const withLp = pr * planned + (1 - pr) * full;
      baseDown += full; lpDown += withLp; hoursBase += e.downH; hoursLp += pr * e.downH * p.plannedHoursFactor + (1 - pr) * e.downH;
      return Object.assign({ p: pr, full, withLp }, e);
    });
    const waste = (b.wasteOnboard + b.wasteShelf) - (l.wasteOnboard + l.wasteShelf);
    const qc = b.qc - l.qc;
    const stockout = (b.stockoutTests - l.stockoutTests) * p.premiumPerTest;
    const reagentGross = waste + qc + stockout, downGross = baseDown - lpDown;
    const k = p.realisation;
    const total = (reagentGross + downGross) * k;
    return { rows, baseDown, lpDown, downGross, hoursBase, hoursLp, waste, qc, stockout, reagentGross, total, net: total - p.subscription,
      roi: total / p.subscription, paybackMonths: p.subscription / (total / 12), k, tph,
      wasteRateBase: (b.wasteOnboard + b.wasteShelf) / (b.usedTests ? b.spend : 1), baseWaste: b.wasteOnboard + b.wasteShelf, lpWaste: l.wasteOnboard + l.wasteShelf };
  }

  function riskText(r) { return r >= 0.9 ? 'above 90%' : Math.round(r * 100) + '%'; }
  function fmtDay(n) { return addDays(n).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' }); }

  root.LP = { riskText, D, A, AN, NOW, TODAY, state, daysTo, addDays, fmtDay, fc, need, clocks, twin, quickTwin, lotPlan, advise, reorder, abc, excursions, trace,
    bayOutlook, analyzerStatus, decide, savings, hourlyLoad, COMP_LABEL, defaultRouting, sum, mean, sd, clearCache: () => { for (const k in planCache) delete planCache[k]; } };
})(typeof window !== 'undefined' ? window : global);
