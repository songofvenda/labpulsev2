/* LabPulse V2 - shared widgets: icon KPI cards, half-dial gauge, CSV export, global search, header wiring. */
(function () {
  'use strict';
  const LP = window.LP, D = LP.D, U = window.LPUI, $ = U.$;
  const KIC = {
    gauge: '<path d="M4 15a8 8 0 1 1 16 0"/><path d="M12 15l4-5"/><path d="M4 19h16"/>',
    wrench: '<path d="M14.5 6.5a4 4 0 0 0 5 5L11 20a2.1 2.1 0 0 1-3-3z"/><path d="M14.5 6.5l3-3"/>',
    calok: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16M9 15l2 2 4-4"/>',
    calx: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M8 3v4M16 3v4M4 10h16M10 14l4 4M14 14l-4 4"/>',
    alert: '<path d="M12 4l9 16H3z"/><path d="M12 10v4M12 17.5v.1"/>',
    check: '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l3 3 5-6"/>',
    flask: '<path d="M9 3h6M10 3v6L4.5 19a1.5 1.5 0 0 0 1.3 2.2h12.4a1.5 1.5 0 0 0 1.3-2.2L14 9V3"/><path d="M7.5 15h9"/>',
    coin: '<circle cx="12" cy="12" r="9"/><path d="M9 8h6M9 11.5h6M9.5 8c3.5 0 3.5 5.5 0 5.5L14 17"/>',
    cube: '<path d="M12 2l9 5v10l-9 5-9-5V7z"/><path d="M3 7l9 5 9-5M12 12v10"/>',
    snow: '<path d="M12 2v20M4 6l16 12M20 6L4 18"/>',
    chart: '<path d="M4 20V4M4 20h16M8 16v-5M12 16V8M16 16v-3"/>',
    cart: '<path d="M4 5h2l2.5 10h9L20 8H7"/><circle cx="10" cy="19" r="1.4"/><circle cx="17" cy="19" r="1.4"/>',
    box: '<path d="M4 8l8-4 8 4v8l-8 4-8-4z"/><path d="M4 8l8 4 8-4M12 12v8"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    thermo: '<path d="M10 14V5a2 2 0 0 1 4 0v9a4 4 0 1 1-4 0z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4"/>',
  };
  const kic = k => '<svg viewBox="0 0 24 24">' + (KIC[k] || KIC.chart) + '</svg>';
  // kpi(label, value, context, tone, icon, tag) - value first, label under it, icon top-left, tag top-right
  U.kpi = (lab, val, ctx, cls, ic, tag) => '<div class="card kpi ' + (cls || '') + '"><div class="k-top"><span class="k-ic">' + kic(ic || { ok: 'check', warn: 'alert', bad: 'alert', twin: 'cube' }[cls] || 'chart') + '</span><span class="k-tag">' + (tag || '') + '</span></div><div class="val">' + val + '</div><div class="lab">' + lab + '</div><div class="ctx">' + (ctx || '') + '</div></div>';
  U.kic = kic;
  U.PAL = ['#0e7fa3', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#0ea5e9', '#84cc16', '#f97316', '#14b8a6', '#eab308'];
  U.legendOn = { display: true, position: 'bottom', labels: { boxWidth: 26, boxHeight: 10, padding: 14, font: { size: 12 } } };

  U.semi = function (v, max, label) {            // half-dial gauge; amber above 60%, red above 80%
    const cx = 120, cy = 118, r = 78, pt = (f, rr) => [cx - Math.cos(Math.PI * f) * rr, cy - Math.sin(Math.PI * f) * rr];
    const arc = (f0, f1, col) => { const a = pt(f0, r), b = pt(f1, r); return '<path d="M' + a[0].toFixed(1) + ' ' + a[1].toFixed(1) + ' A' + r + ' ' + r + ' 0 0 1 ' + b[0].toFixed(1) + ' ' + b[1].toFixed(1) + '" fill="none" stroke="' + col + '" stroke-width="9"/>'; };
    let t = '';
    for (let i = 0; i <= 10; i++) { const p = pt(i / 10, r + 24); t += '<text x="' + p[0].toFixed(1) + '" y="' + (p[1] + 4).toFixed(1) + '" font-size="10" text-anchor="middle" fill="' + (i >= 8 ? '#dc2626' : i >= 6 ? '#d97706' : '#5b6b7f') + '">' + Math.round(max * i / 10) + '</text>'; }
    for (let i = 0; i <= 50; i++) { const a = pt(i / 50, r + 8), b = pt(i / 50, r + 13); t += '<line x1="' + a[0].toFixed(1) + '" y1="' + a[1].toFixed(1) + '" x2="' + b[0].toFixed(1) + '" y2="' + b[1].toFixed(1) + '" stroke="' + (i >= 40 ? '#dc2626' : i >= 30 ? '#d97706' : '#94a3b8') + '" stroke-width="1.5"/>'; }
    const f = Math.max(0, Math.min(1, v / max)), n = pt(f, r - 16), col = f >= 0.8 ? '#dc2626' : f >= 0.6 ? '#d97706' : '#0b6b85';
    return '<svg viewBox="0 0 240 150" width="100%" style="max-width:290px;display:block;margin:0 auto">' + arc(0, 0.6, '#cbd5e1') + arc(0.6, 0.8, '#f0b35a') + arc(0.8, 1, '#e05252') + t +
      '<line x1="' + cx + '" y1="' + cy + '" x2="' + n[0].toFixed(1) + '" y2="' + n[1].toFixed(1) + '" stroke="' + col + '" stroke-width="3.5" stroke-linecap="round"/><circle cx="' + cx + '" cy="' + cy + '" r="6" fill="' + col + '"/>' +
      '<text x="' + cx + '" y="' + (cy - 26) + '" text-anchor="middle" font-size="21" font-weight="700" fill="' + col + '">' + Math.round(v) + '</text><text x="' + cx + '" y="' + (cy + 24) + '" text-anchor="middle" font-size="11" fill="#5b6b7f">' + label + '</text></svg>';
  };
  U.strip = (vals, cls) => { const v = vals.filter(x => x != null), mn = Math.min.apply(null, v), mx = Math.max.apply(null, v), r = mx - mn || 1; return '<div class="strip ' + (cls || '') + '">' + vals.map(x => '<i style="height:' + (x == null ? 8 : 25 + 75 * (x - mn) / r) + '%"></i>').join('') + '</div>'; };

  function exportCsv() {                          // exports the first table on the current screen
    const t = document.querySelector('#page table');
    if (!t) { U.toast('No table on this screen to export'); return; }
    const csv = Array.from(t.rows).map(r => Array.from(r.cells).map(c => '"' + c.innerText.replace(/\s+/g, ' ').trim().replace(/"/g, '""') + '"').join(',')).join('\r\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv' }));
    a.download = 'labpulse-' + (location.hash.replace(/[^a-z0-9]+/gi, '-').replace(/^-|-$/g, '') || 'overview') + '.csv';
    a.click(); U.toast('Exported ' + (t.rows.length - 1) + ' rows');
  }
  function search(q) {
    q = q.trim().toLowerCase(); if (!q) return;
    const an = D.analyzers.find(a => a.id.toLowerCase().includes(q) || a.model.toLowerCase().includes(q));
    if (an) return U.go('analyzer/' + an.id);
    const lot = D.lots.find(l => l.lotNo.toLowerCase().includes(q) || l.id.toLowerCase() === q) || D.lots.find(l => l.assay.toLowerCase() === q && l.state === 'onboard') || D.lots.find(l => LP.A[l.assay].name.toLowerCase().includes(q));
    if (lot) return U.go('reagents/' + lot.id);
    U.toast('Nothing found for "' + q + '"');
  }
  U.wireHeader = function () {
    $('#site').textContent = D.meta.site.replace('District Hospital Laboratory, ', 'District Hospital · ');
    $('#belln').textContent = D.analyzers.filter(a => a.alerting).length + D.assays.filter(a => ['order', 'critical'].includes(LP.reorder(a.code).status)).length;
    $('#refresh').onclick = () => { U.refresh(); U.toast('Recalculated from the latest readings'); };
    $('#export').onclick = exportCsv;
    $('#gsearch').onkeydown = e => { if (e.key === 'Enter') { search(e.target.value); e.target.blur(); } };
  };
})();
