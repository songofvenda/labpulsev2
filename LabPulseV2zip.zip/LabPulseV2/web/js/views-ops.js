/* LabPulse V2 - operations screens: Command centre, Analyzer twin, Decision engine. */
(function () {
  'use strict';
  const LP = window.LP, D = LP.D, U = window.LPUI;
  const { $, $$, esc, num, inr, inrK, pct, dfmt, tfmt, pill, C, kpi, card } = U;
  const SIG = [
    { k: 'probe_kpa', label: 'Aspiration pressure', unit: 'kPa', d: 1, comp: 'probe' }, { k: 'lamp_int', label: 'Lamp intensity', unit: '% of reference', d: 1, comp: 'lamp' },
    { k: 'bay_temp', label: 'Reagent bay temperature', unit: '°C', d: 1, comp: 'cooler', limit: 8 }, { k: 'blank_abs', label: 'Cuvette blank absorbance', unit: 'mAbs', d: 1, comp: 'wash' },
    { k: 'vib', label: 'Carousel vibration', unit: 'mm/s', d: 2, comp: 'drive' }, { k: 'bath_temp', label: 'Reaction bath temperature', unit: '°C', d: 2, comp: 'bath' },
    { k: 'qc_sdi', label: 'QC deviation', unit: 'SDI', d: 2 }, { k: 'errors', label: 'Error codes', unit: 'per day', d: 0 },
  ];
  const COMP_INFO = {
    lamp: ['Lamp intensity, QC deviation', 'Photometric noise rises, results drift, then the lamp fails and all photometric tests stop.'],
    probe: ['Aspiration pressure (level and noise), error codes, QC deviation', 'Short sampling and clot errors first, then a blocked or leaking probe stops sampling.'],
    cooler: ['Reagent bay temperature, load-normalised power draw', 'Bay warms past 8 °C. On-board stability claims are void before the unit actually stops.'],
    wash: ['Cuvette blank absorbance, bath noise, error codes', 'Carry-over and high blanks, then cuvette wash failure halts the reaction ring.'],
    drive: ['Vibration, power draw, error codes', 'Positioning errors, then the carousel stalls.'],
    bath: ['Bath temperature against this analyzer’s own baseline', 'Enzyme rates shift with temperature; QC fails before hardware does.'],
    board: ['None that give warning', 'Sudden stop. This failure class has no precursor in the telemetry, so LabPulse does not claim to predict it.'],
  };
  const allTwins = () => D.lots.map(l => LP.twin(l));
  const lotStatusFor = id => D.lots.filter(l => l.state === 'onboard' && l.analyzer === id).map(l => { const t = LP.twin(l); return { id: l.id, status: t.status, tip: '<b>' + l.assay + '</b> lot ' + l.lotNo + '<br>' + l.remaining + ' tests left · ' + t.headline }; });
  const compStatus = c => (c.health == null ? 'ok' : c.rul && c.rul.lo < 5 ? 'critical' : (c.rul || c.health < 75) ? 'risk' : 'ok');
  function statusMap(st) { const m = {}; st.comps.forEach(c => { m[c.key] = st.alerting ? compStatus(c) : 'ok'; }); return m; }
  const rulTxt = r => r ? num(r.lo, 0) + '–' + num(r.hi, 0) + ' days' : 'no wear trend';

  function actions() {
    const out = [];
    D.analyzers.forEach(a => { const st = LP.analyzerStatus(a.id); if (!st.alerting) return; const d = LP.decide(a.id);
      out.push({ cls: st.tier, title: 'Service ' + a.id + ' ' + d.comp.label.toLowerCase() + ' on ' + LP.fmtDay(d.slot.day) + ', ' + d.slot.hour + ':00', text: 'Predicted to fail in ' + rulTxt(d.comp.rul) + '. A planned ' + d.dur + ' h slot displaces ' + num(d.slot.displaced) + ' tests instead of an unplanned ' + num(d.down) + ' h stop.', value: d.avoided, go: 'decisions/' + a.id, tag: 'Maintenance + reagents' }); });
    const b3 = LP.bayOutlook('BA-03');
    D.assays.forEach(a => { Object.keys(LP.state.routing[a.code] || {}).forEach(an => { const cur = D.lots.find(l => l.assay === a.code && l.state === 'onboard' && l.analyzer === an); if (!cur) return; const t = LP.twin(cur); if (t.binding.key !== 'onboard' || t.waste < 20) return; const ad = LP.advise(a.code, an);
      if (ad.verdict === 'hold') out.push({ cls: 'risk', title: 'Do not open a new ' + a.code + ' kit on ' + an + ' yet', text: Math.round(t.waste) + ' tests on the current bottle will outlive their on-board stability. ' + ad.best.title + '.', value: ad.saving, go: 'reagents/' + cur.id, tag: 'Reagent twin' }); }); });
    allTwins().filter(t => t.lot.state === 'stored' && t.status === 'critical').forEach(t => out.push({ cls: 'critical', title: t.lot.assay + ' lot ' + t.lot.lotNo + ' expires in ' + LP.daysTo(t.lot.expiry) + ' days, unopened', text: 'In the current queue it expires untouched. Issued first, about ' + num(t.best) + ' of ' + t.lot.bottleTests + ' tests can still be used; transfer the rest to a higher-volume site.', value: t.wasteValue, go: 'reagents/' + t.lot.id, tag: 'Expiry' }));
    LP.abc(D.assays.map(a => LP.reorder(a.code))).filter(r => r.status === 'critical' || r.status === 'order').forEach(r => out.push({ cls: r.status === 'critical' ? 'critical' : 'risk', title: 'Order ' + r.qty + ' × ' + r.code + ' (' + r.bottle + '-test pack) today', text: num(r.cover) + ' days of cover against a ' + r.supplier.leadMean + '-day lead time from ' + r.supplier.name + '.', value: r.orderValue, valueLabel: 'order value', go: 'coldchain', tag: 'Reorder' }));
    return out.sort((x, y) => (x.cls === 'critical' ? 0 : 1) - (y.cls === 'critical' ? 0 : 1) || y.value - x.value);
  }

  // ------------------------------------------------------------------ Command centre
  U.view('overview', { title: 'Command centre', sub: 'One ranked view of analyzers, reagents and stores for today', nav: { sec: 'Operations', label: 'Command centre', icon: 'home' }, render(el) {
    const sts = D.analyzers.map(a => LP.analyzerStatus(a.id)), tw = allTwins(), acts = actions(), sv = LP.savings();
    const atRisk = tw.filter(t => t.status !== 'ok'), riskVal = LP.sum(atRisk.map(t => t.wasteValue));
    const ro = D.assays.map(a => LP.reorder(a.code)), due = ro.filter(r => r.status === 'order' || r.status === 'critical');
    const today = LP.sum(D.assays.map(a => LP.fc(a.code, 0))), week = LP.sum(D.assays.map(a => LP.sum([0, 1, 2, 3, 4, 5, 6].map(i => LP.fc(a.code, i)))));
    el.innerHTML =
      '<div class="grid g5">' +
      kpi('Analyzers needing action', sts.filter(s => s.alerting).length + '<small>of ' + sts.length + '</small>', sts.filter(s => s.alerting).map(s => s.an.id + ': ' + s.label.toLowerCase()).join(' \u00B7 ') || 'All normal', sts.some(s => s.tier === 'critical') ? 'bad' : 'warn', 'wrench', 'Fleet') +
      kpi('Reagent value at risk', inrK(riskVal), atRisk.length + ' lots will lose tests to stability or expiry', 'warn', 'flask', 'Reagents') +
      kpi('Orders due', due.length + '<small>' + (due.length === 1 ? 'assay' : 'assays') + '</small>', due.map(r => r.code).join(', ') || 'Nothing to order this week', due.some(r => r.status === 'critical') ? 'bad' : '', 'cart', 'Stores') +
      kpi('Forecast workload', num(today) + '<small>tests today</small>', num(week) + ' over the next 7 days', '', 'chart', 'Forecast') +
      kpi('Modelled annual saving', inrK(sv.total), 'Back-test on 12 months, ' + pct(sv.k) + ' realisation', 'ok', 'coin', 'Value') +
      '</div>' +
      '<div class="grid g-main mt">' +
      '<div class="card"><div class="card-h"><div><h3>Laboratory floor twin</h3><div class="sub">Live state of every analyzer and its on-board reagents. Drag to rotate, select an analyzer to open its twin.</div></div>' + '<span class="pill twin">3D digital twin</span></div><div class="card-b"><div class="stage floor" id="floor"></div></div></div>' +
      '<div class="card"><div class="card-h"><div><h3>Coordinated actions for today</h3><div class="sub">One ranked list across maintenance, reagents and stores</div></div><span class="pill blue">' + acts.length + ' open</span></div><div class="card-b" style="max-height:428px;overflow:auto">' +
      acts.map(a => '<div class="opt" style="grid-template-columns:minmax(0,1fr) auto;cursor:pointer" data-go="' + a.go + '"><div><div class="row" style="gap:7px;margin-bottom:3px">' + pill(a.cls, a.cls === 'critical' ? 'Act now' : 'Plan') + '<span class="note">' + a.tag + '</span></div><h5>' + esc(a.title) + '</h5><p>' + esc(a.text) + '</p></div><div class="amt">' + inrK(a.value) + '<small>' + (a.valueLabel || 'avoidable') + '</small></div></div>').join('') +
      '</div></div></div>' +
      '<div class="mt">' +
      card('Analyzer fleet', 'Three vendors, one view. Health is scored against each analyzer’s own baseline.', '<div class="scroll"><table class="tbl"><thead><tr><th>Analyzer</th><th>Health</th><th>7-day failure risk</th><th>Weakest sub-assembly</th><th>Uptime, 12 mo</th><th>Tests, 30 d</th><th></th></tr></thead><tbody>' +
        sts.map(s => '<tr class="click" data-go="analyzer/' + s.an.id + '"><td><b>' + s.an.id + '</b><span class="s">' + s.an.model + ' · installed ' + s.an.installed + '</span></td><td><div class="row">' + U.gauge(s.health, s.tier, 44) + pill(s.tier, s.label) + '</div></td><td>' + (s.alerting ? '<b class="' + (s.tier === 'critical' ? 'c-bad' : 'c-warn') + '">' + LP.riskText(s.risk) + '</b>' : '<span class="c-mute">below alert threshold</span>') + '<span class="s">' + U.spark(s.an.riskSeries.slice(-80), s.tier === 'ok' ? C.ok : s.tier === 'critical' ? C.bad : C.warn) + '</span></td><td>' + s.worst.label + '<span class="s">' + num(s.worst.health) + '% health · ' + rulTxt(s.worst.rul) + '</span></td><td class="mono">' + pct(s.an.uptime365, 1) + '</td><td class="mono">' + num(s.an.tests30) + '</td><td><span class="btn ghost sm">Open twin</span></td></tr>').join('') +
        '</tbody></table></div>', '', '') + '</div>' +
      '<div class="grid g-side mt">' +
      card('Reagent lots losing value', 'Ranked by rupees that the stability clocks will take', '<div class="scroll"><table class="tbl"><thead><tr><th>Lot</th><th>Where</th><th>Binding rule</th><th class="num">At risk</th></tr></thead><tbody>' +
        atRisk.sort((x, y) => y.wasteValue - x.wasteValue).slice(0, 7).map(t => '<tr class="click" data-go="reagents/' + t.lot.id + '"><td><b>' + t.lot.assay + '</b><span class="s">' + t.lot.lotNo + '</span></td><td>' + esc(t.lot.location) + '</td><td>' + pill(t.status, t.status === 'quarantine' ? 'Excursion' : t.binding.key === 'shelf' ? 'Printed expiry' : t.binding.key === 'bay' ? 'Bay temperature' : 'On-board stability') + '</td><td class="num"><b>' + inr(t.wasteValue) + '</b><span class="s">' + num(t.waste) + ' tests</span></td></tr>').join('') +
        '</tbody></table></div>') +
      card('Test-volume forecast', 'All assays, daily. The forecast drives reagent burn-down, reorder points and the choice of maintenance window.', '<div class="chart" id="ovfc"></div><div class="legend mt-s"><span><i style="background:' + C.slate + '"></i>Actual</span><span><i style="background:' + C.blue + '"></i>Forecast (' + esc(D.models.forecast.best) + ')</span><span>Hold-out error ' + pct(D.models.forecast.metrics[D.models.forecast.best].wape, 1) + ' WAPE, bias ' + pct(D.models.forecast.metrics[D.models.forecast.best].bias, 1) + '</span></div>') + '</div>';
    // forecast chart
    const codes = D.assays.map(a => a.code), hist = [], fcst = [], labels = [];
    for (let i = 45; i > 0; i--) { const idx = D.demand.history[codes[0]].length - i; hist.push(LP.sum(codes.map(c => D.demand.history[c][idx]))); fcst.push(null); labels.push(dfmt(LP.addDays(-i))); }
    fcst[fcst.length - 1] = hist[hist.length - 1];
    for (let i = 0; i < 21; i++) { hist.push(null); fcst.push(LP.sum(codes.map(c => LP.fc(c, i)))); labels.push(dfmt(LP.addDays(i))); }
    U.chart($('#ovfc'), { type: 'line', data: { labels, datasets: [{ data: hist, borderColor: C.slate, backgroundColor: 'rgba(148,163,184,.14)', fill: true }, { data: fcst, borderColor: C.blue, borderDash: [6, 4], backgroundColor: 'rgba(29,78,216,.08)', fill: true }] },
      options: { scales: U.axes(), plugins: { ref: { items: [{ x: 45, color: C.mute, label: 'Today' }] } } } });
    // 3D floor
    if (window.LP3D.supported()) {
      const f = window.LP3D.mountFloor($('#floor'), sts.map(s => ({ an: s.an, tier: s.tier, health: s.health, status: statusMap(s), bottles: lotStatusFor(s.an.id).map(b => b.status),
        html: '<b>' + s.an.id + ' · ' + s.label + '</b><span>' + (s.alerting ? s.worst.label + ' · ' : s.an.model + ' · ') + 'health ' + s.health + '</span>' })), { onPick: id => U.go('analyzer/' + id) });
      U.onLeave(f.dispose);
    } else $('#floor').innerHTML = '<div class="note" style="padding:20px">3D view needs WebGL, which this browser has disabled.</div>';
  } });

  // ------------------------------------------------------------------ Analyzer twin
  U.view('analyzer', { title: id => 'Analyzer twin · ' + (id || 'BA-01'), sub: 'Live 3D twin, condition monitoring and remaining-life estimates', nav: { sec: 'Operations', label: 'Analyzer twin', icon: 'cube', count: () => ({ n: D.analyzers.filter(a => a.alerting).length }) }, render(el, id) {
    id = LP.AN[id] ? id : 'BA-01';
    const st = LP.analyzerStatus(id), an = st.an, R = D.models.risk, bay = LP.bayOutlook(id);
    const lots = lotStatusFor(id), dec = st.alerting ? LP.decide(id) : null, cond = U.condition(st, compStatus);
    el.innerHTML =
      '<div class="row sp wrap" style="margin-bottom:14px"><div class="seg">' + D.analyzers.map(a => { const s = LP.analyzerStatus(a.id); return '<button class="' + (a.id === id ? 'on' : '') + '" data-go="analyzer/' + a.id + '"><span class="dot ' + s.tier + '"></span> ' + a.id + ' · ' + a.model + '</button>'; }).join('') + '</div>' +
      '<div class="note">Telemetry completeness ' + pct(an.dataQuality, 1) + ' over 21 days · throughput ' + an.throughput + ' tests/h · ' + an.menu.length + ' assays validated</div></div>' +
      '<div class="grid g-main">' +
      '<div class="card"><div class="stage" id="stage"><div class="stage-tools"><div class="seg" id="tools"><button data-t="explode">Exploded view</button><button data-t="xray">See inside</button><button data-t="lid" class="on">Reagent lid</button><button data-t="run" class="on">Running</button></div></div><div class="stage-hint">Drag to rotate · scroll to zoom · select a part or a reagent bottle</div></div>' +
      '<div class="card-b"><div class="scroll"><table class="tbl"><thead><tr><th>Sub-assembly</th><th style="width:26%">Health</th><th>Remaining useful life</th><th>Evidence</th></tr></thead><tbody>' +
      st.comps.map(c => { const cs = st.alerting ? compStatus(c) : 'ok'; return '<tr class="click" data-comp="' + c.key + '"><td><b>' + c.label + '</b></td><td>' + (c.health == null ? '<span class="pill">Not observable</span>' : '<div class="row"><div class="bar" style="flex:1"><i class="' + (cs === 'ok' ? '' : cs) + '" style="width:' + c.health + '%"></i></div><span class="mono fw" style="width:38px;text-align:right">' + num(c.health) + '%</span></div>') + '</td><td>' + (c.health == null ? '<span class="c-mute">No precursor signal exists</span>' : c.rul ? '<b class="' + (cs === 'critical' ? 'c-bad' : 'c-warn') + '">' + rulTxt(c.rul) + '</b>' : '<span class="c-mute">No wear trend</span>') + '</td><td class="note">' + COMP_INFO[c.key][0] + '</td></tr>'; }).join('') +
      '</tbody></table></div></div></div>' +
      '<div class="stack">' +
      '<div class="callout ' + st.tier + '"><div>' + U.gauge(st.health, st.tier, 78) + '</div><div><h4>' + (st.tier === 'ok' ? 'Operating normally' : st.tier === 'critical' ? 'Act now: ' + st.withRul.label.toLowerCase() + ' is wearing out' : 'Plan service: ' + (st.withRul || st.worst).label.toLowerCase() + ' is drifting') + '</h4><p>' +
        (st.alerting ? 'Chance of failure within 7 days: <b>' + LP.riskText(st.risk) + '</b> (score calibrated on a held-out period of synthetic data). Projected to reach its service limit in <b>' + rulTxt((st.withRul || st.worst).rul) + '</b>.' : 'Risk score is below the alert threshold and every monitored sub-assembly is within its own baseline.') + '</p>' +
        (dec ? '<div class="row mt-s wrap"><span class="btn" data-go="decisions/' + id + '">Open the coordinated plan</span><span class="note">Avoids about ' + inr(dec.avoided) + ' against an unplanned stop</span></div>' : '') + '</div></div>' +
      card('Why LabPulse says this', 'Signals that have moved furthest from this analyzer’s own baseline, not a universal threshold', '<table class="tbl"><thead><tr><th>Signal</th><th class="num">Now</th><th class="num">Own baseline</th><th class="num">Shift</th></tr></thead><tbody>' +
        an.drivers.slice(0, 5).map(d => '<tr><td>' + d.signal + '</td><td class="num">' + num(d.now, 2) + '</td><td class="num">' + num(d.base, 2) + '</td><td class="num"><b class="' + (Math.abs(d.z) > 3 ? 'c-bad' : Math.abs(d.z) > 2 ? 'c-warn' : 'c-mute') + '">' + (d.z > 0 ? '+' : '') + num(d.z, 1) + ' σ</b></td></tr>').join('') + '</tbody></table>') +
      card('Risk score, last 60 days', 'Gradient-boosted model, scored every 6 hours', '<div class="chart sm" id="riskc"></div>') +
      card('On-board reagents', lots.length + ' bottles in the bay at ' + num(bay.now, 1) + ' °C' + (bay.crossIn != null ? ', rising ' + num(bay.slope, 2) + ' °C per day' : ''),
        (bay.crossIn != null ? '<div class="callout risk" style="padding:10px 12px;margin-bottom:10px"><div><h4>Bay will pass 8 °C in about ' + num(bay.crossIn, 0) + ' days</h4><p>Above 8 °C the manufacturer’s on-board stability no longer applies. Every bottle in this bay inherits that deadline in its reagent twin.</p></div></div>' : '') +
        '<div class="row wrap" style="gap:6px">' + lots.map(l => '<span class="chip ' + (l.status === 'ok' ? '' : l.status) + '" style="cursor:pointer;font-size:12px;padding:3px 8px" data-go="reagents/' + l.id + '">' + D.lots.find(x => x.id === l.id).assay + '</span>').join('') + '</div><div class="legend mt-s"><span><i style="background:' + C.ok + '"></i>On track</span><span><i style="background:' + C.warn + '"></i>At risk</span><span><i style="background:' + C.bad + '"></i>Critical</span></div>') +
      '</div></div>' +
      cond.html +
      '<div class="h-sec">Telemetry against this analyzer\u2019s own baseline, last 90 days</div><div class="grid g4" id="tele"></div>' +
      '<div class="grid g2 mt">' + card('Maintenance and failure history', 'Service records are the labels the model learns from', '<div class="tl">' + (an.events.slice(-7).reverse().map(e => '<div class="tl-i ' + (e.caught ? '' : 'bad') + '"><div class="d">' + tfmt(e.at) + '</div><div class="t">' + e.comp + (e.caught ? ' · degradation corrected at routine service' : ' · unplanned failure') + '</div><div class="tx">' + (e.caught ? 'No downtime' : num(e.downH, 1) + ' h of downtime') + '</div></div>').join('') || '<div class="note">No recorded events.</div>') + '</div>') +
      card('Preventive maintenance calendar', 'Routine visits re-anchor the baseline so a service does not trigger a false alarm', '<div class="tl">' + an.pm.filter(p => new Date(p) > LP.addDays(-200)).slice(0, 5).map(p => '<div class="tl-i ' + (new Date(p) > LP.NOW ? 'warn' : '') + '"><div class="d">' + dfmt(p, { day: 'numeric', month: 'short', year: 'numeric' }) + '</div><div class="t">' + (new Date(p) > LP.NOW ? 'Scheduled quarterly service' : 'Quarterly service completed') + '</div></div>').join('') + '</div>') + '</div>';

    // telemetry small multiples
    const n = an.daily.tests.length, from = n - 90, labels = Array.from({ length: 90 }, (_, i) => dfmt(new Date(new Date(an.daily.start).getTime() + (from + i) * 86400000)));
    $('#tele').innerHTML = SIG.map(s => '<div class="card"><div class="card-h"><div><h3>' + s.label + '</h3><div class="sub">' + s.unit + '</div></div><b class="mono">' + num(an.daily[s.k][n - 1], s.d) + '</b></div><div class="card-b"><div class="chart xs" id="t-' + s.k + '"></div></div></div>').join('');
    SIG.forEach(s => { const flagged = s.comp && st.alerting && compStatus(st.comps.find(c => c.key === s.comp)) !== 'ok';
      const items = []; if (an.baseline[s.k] != null) items.push({ y: an.baseline[s.k], color: C.slate, label: 'baseline' }); if (s.limit) items.push({ y: s.limit, color: C.bad, label: 'limit ' + s.limit });
      U.chart($('#t-' + s.k), { type: 'line', data: { labels, datasets: [{ data: an.daily[s.k].slice(from), borderColor: flagged ? C.bad : C.brand, borderWidth: 1.7, spanGaps: true }] }, options: { scales: U.axes({ x: { display: false }, y: { grid: { color: C.grid }, border: { display: false }, ticks: { maxTicksLimit: 3 }, suggestedMax: s.limit ? s.limit + 0.3 : undefined } }), plugins: { ref: { items } } } }); });
    U.chart($('#riskc'), { type: 'line', data: { labels: an.riskTs.map(t => dfmt(t)), datasets: [{ data: an.riskSeries, borderColor: st.tier === 'ok' ? C.ok : st.tier === 'critical' ? C.bad : C.warn, backgroundColor: 'rgba(220,38,38,.06)', fill: true, stepped: true }] },
      options: { scales: U.axes({ y: { min: 0, max: 1, grid: { color: C.grid }, border: { display: false }, ticks: { maxTicksLimit: 3, callback: v => v * 100 + '%' } } }), plugins: { ref: { items: [{ y: R.thresholdProb, color: C.mute, label: 'alert threshold' }] } } } });

    cond.draw();
    // component drawer
    const openComp = k => { const c = st.comps.find(x => x.key === k); if (!c) return; const m = D.modes[k === 'bath' ? 'wash' : k] || {};
      const dr = U.drawer(c.label, an.id + ' · ' + an.model, '<div class="eq"><div class="' + (compStatus(c) === 'ok' || !st.alerting ? 'ok' : 'bad') + '"><div class="l">Health</div><div class="v">' + (c.health == null ? 'n/a' : num(c.health) + '%') + '</div></div><div><div class="l">Remaining useful life</div><div class="v" style="font-size:16px">' + (c.health == null ? 'not predictable' : rulTxt(c.rul)) + '</div></div><div><div class="l">Typical unplanned stop</div><div class="v">' + (m.down || '-') + ' h</div></div></div>' +
        '<div class="h-sec">Health index, last 120 days</div><div class="chart sm" id="compc"></div>' +
        '<div class="h-sec">What feeds this estimate</div><p>' + COMP_INFO[k][0] + '.</p><div class="h-sec">Failure effect</div><p>' + COMP_INFO[k][1] + '</p>' +
        '<div class="h-sec">How the life estimate is made</div><p class="note">Two extrapolations of the recent wear trend bound the answer: wear continuing at today’s pace, and wear continuing to accelerate. The range between them is shown, not a single date. ' + (k === 'board' ? '' : 'Warning window seen in the fleet for this failure mode: ' + (m.pre ? m.pre[0] + '–' + m.pre[1] + ' days.' : '')) + '</p>');
      if (c.series.length) { const ch = new Chart($('#compc', dr).appendChild(document.createElement('canvas')), { type: 'line', data: { labels: c.series.map((_, i) => dfmt(LP.addDays(i - c.series.length + 1))), datasets: [{ data: c.series, borderColor: C.brand, backgroundColor: 'rgba(14,116,144,.08)', fill: true }] }, options: { scales: U.axes({ y: { min: 0, max: 100, grid: { color: C.grid }, border: { display: false }, ticks: { maxTicksLimit: 4 } } }) } }); U.onLeave(() => ch.destroy()); }
      else $('#compc', dr).innerHTML = '<div class="note box">No health index is shown because no telemetry signal gives advance warning of this failure. In the fleet back-test the model caught ' + R.board.detected + ' of ' + R.board.events + ' such failures.</div>'; };
    $$('[data-comp]', el).forEach(r => { r.onclick = () => openComp(r.dataset.comp); });

    // 3D
    if (window.LP3D.supported()) {
      const tw = window.LP3D.mount($('#stage'), an, { onPart: k => { if (LP.COMP_LABEL[k]) openComp(k); else if (k === 'cabinet') openComp('board'); }, onLot: lid => U.go('reagents/' + lid),
        calloutText: k => { const c = st.comps.find(x => x.key === k); return '<b>' + c.label + '</b><span>' + num(c.health) + '% health · ' + rulTxt(c.rul) + '</span>'; } });
      const sm = statusMap(st); delete sm.board; tw.setStatus(sm, st.health, st.tier); tw.setBottles(lots);
      const flags = { explode: false, xray: false, lid: true, run: true };
      $$('#tools button').forEach(b => { b.onclick = () => { const t = b.dataset.t; flags[t] = !flags[t]; b.classList.toggle('on', flags[t]); if (t === 'explode') tw.setExploded(flags[t]); if (t === 'xray') tw.setXray(flags[t]); if (t === 'lid') tw.setLid(flags[t]); if (t === 'run') tw.setRunning(flags[t]); }; });
      U.onLeave(tw.dispose);
    } else $('#stage').insertAdjacentHTML('beforeend', '<div class="note" style="padding:70px 20px">3D view needs WebGL, which this browser has disabled.</div>');
  } });

  // ------------------------------------------------------------------ Decision engine
  U.view('decisions', { title: 'Decision engine', sub: 'One alert, one coordinated plan across maintenance, workload, reagents and stores', nav: { sec: 'Operations', label: 'Decision engine', icon: 'flow', count: () => ({ n: D.analyzers.filter(a => a.alerting).length, cls: 'warn' }) }, render(el, id) {
    const flagged = D.analyzers.filter(a => a.alerting);
    if (!flagged.length) { el.innerHTML = '<div class="callout ok"><div><h4>No coordinated plan is needed</h4><p>No analyzer is above its alert threshold.</p></div></div>'; return; }
    id = flagged.some(a => a.id === id) ? id : flagged[0].id;
    const d = LP.decide(id), st = d.st, an = st.an, done = LP.state.approved.find(a => a.id === id);
    const load = LP.hourlyLoad(id, d.slot.day);
    const routeAll = d.reroute.filter(r => r.tests >= 0.05).sort((x, y) => (x.kind === 'hold' ? 0 : 1) - (y.kind === 'hold' ? 0 : 1) || y.tests - x.tests), routeRows = routeAll.slice(0, 8);
    el.innerHTML =
      '<div class="row sp wrap" style="margin-bottom:14px"><div class="seg">' + flagged.map(a => '<button class="' + (a.id === id ? 'on' : '') + '" data-go="decisions/' + a.id + '"><span class="dot ' + LP.analyzerStatus(a.id).tier + '"></span> ' + a.id + ' · ' + LP.analyzerStatus(a.id).withRul.label + '</button>').join('') + '</div><span class="note">One event, traced through maintenance, workload, reagents, stores and cost</span></div>' +
      '<div class="callout ' + st.tier + '"><div class="ic">!</div><div><h4>Trigger: ' + an.id + ' ' + d.comp.label.toLowerCase() + ' is predicted to fail in ' + rulTxt(d.comp.rul) + '</h4><p>Health ' + num(d.comp.health) + '%, 7-day failure risk ' + LP.riskText(st.risk) + '. A conventional alarm panel would stop here. LabPulse works out what this means for tomorrow’s tests and for the reagent already on board.</p></div></div>' +
      '<div class="grid g-main mt"><div class="card"><div class="card-b"><div class="steps">' +
      '<div class="step"><h4>Pick the least disruptive service window</h4><div class="why">Searched every slot before the earliest plausible failure (day ' + d.deadline + ') against the hourly test forecast for ' + an.id + '.</div>' +
        '<div class="chart sm" id="slotc"></div><div class="row wrap mt-s">' + d.slots.map((s, i) => '<span class="pill ' + (i === 0 ? 'ok' : '') + '">' + LP.fmtDay(s.day) + ' ' + s.hour + ':00–' + (s.hour + s.dur) + ':00 · ' + num(s.displaced) + ' tests displaced</span>').join('') + '</div></div>' +
      '<div class="step"><h4>Re-route the workload, assay by assay</h4><div class="why">An assay moves only to an analyzer that is validated for it, already has calibrated reagent on board, and has spare capacity.</div>' +
        '<div class="scroll"><table class="tbl"><thead><tr><th>Assay</th><th class="num">Tests in window</th><th>Decision</th></tr></thead><tbody>' + routeRows.map(r => '<tr><td><b>' + r.code + '</b></td><td class="num">' + num(r.tests, 1) + '</td><td>' + (r.kind === 'route' ? pill('ok', 'Route') : pill('warn', 'Hold')) + ' <span class="note">' + esc(r.action) + '</span></td></tr>').join('') + '</tbody></table></div>' + (routeAll.length > 8 ? '<div class="note mt-s">and ' + (routeAll.length - 8) + ' more assays, all routed.</div>' : '') +
        '<div class="row wrap mt-s">' + d.capacity.map(c => '<span class="pill ' + (c.ok ? 'ok' : 'bad') + '">' + c.id + ' capacity check: ' + num(c.own + c.extra) + ' of ' + num(c.limit) + ' tests in the window</span>').join('') + '<span class="note">' + num(d.held, 1) + ' tests held and batched after sign-off; none are urgent-care assays without an alternative.</span></div></div>' +
      '<div class="step"><h4>Protect the reagent already on board</h4><div class="why">' + (d.burn ? 'The bay will pass 8 °C before the unit fails. For ' + d.burn.until + ' days, sending these assays to ' + an.id + ' first uses the exposed bottles while their stability claim still holds. Each assay is re-routed only if total loss across every analyzer goes down.' : 'Stability clocks keep running while an analyzer is down. The plan keeps short-dated bottles working and stops new ones being opened into a service window.') + '</div>' +
        (d.reagent.length ? '<div class="stack" style="--g:6px">' + d.reagent.slice(0, 6).map(r => '<div class="row" style="align-items:flex-start"><span class="dot ' + (r.kind === 'hold' ? 'warn' : 'twin') + '" style="margin-top:6px"></span><span>' + esc(r.text) + '</span></div>').join('') + '</div>' : '<div class="note">No on-board bottle is affected by this window.</div>') +
        (d.burn ? '<div class="eq mt-s"><div class="bad"><div class="l">At risk today, these assays, all analyzers</div><div class="v">' + inr(d.burn.before) + '</div></div><div class="ok"><div class="l">After burn-down routing</div><div class="v">' + inr(d.burn.after) + '</div></div></div>' : '') + '</div>' +
      '<div class="step"><h4>Adjust stores and procurement</h4><div class="why">The same plan changes what needs to be issued and ordered.</div>' +
        '<div class="stack"><div class="row" style="align-items:flex-start"><span class="dot ok" style="margin-top:6px"></span><span>Reserve the ' + d.comp.label.toLowerCase() + ' service kit for ' + LP.fmtDay(d.slot.day) + '; raise a planned work order instead of an emergency call-out.</span></div>' +
        '<div class="row" style="align-items:flex-start"><span class="dot ok" style="margin-top:6px"></span><span>Hold reagent issue to ' + an.id + ' from cold storage until the service is signed off and QC has passed.</span></div>' +
        '<div class="row" style="align-items:flex-start"><span class="dot ok" style="margin-top:6px"></span><span>Reorder points are recalculated on the new routing the moment the plan is approved.</span></div></div></div>' +
      '<div class="step ' + (done ? 'done' : '') + '"><h4>Human approval</h4><div class="why">LabPulse recommends; the laboratory in-charge decides. Nothing is changed on any analyzer.</div>' +
        (done ? '<div class="callout ok"><div><h4>Approved ' + tfmt(done.at) + '</h4><p>Work order ' + done.wo + ' raised. Routing and reagent twins have been recalculated.</p></div></div>' : '<div class="row wrap"><button class="btn" id="approve">Approve plan and raise work order</button><button class="btn ghost" id="defer">Defer and keep monitoring</button></div>') + '</div>' +
      '</div></div></div>' +
      '<div class="stack">' +
      card('What it is worth', 'Same event, two outcomes', '<div class="vs"><div class="pane bad"><div class="note">If it fails unplanned</div><div class="big c-bad">' + inr(d.unplannedCost) + '</div><div class="note mt-s">' + num(d.down) + ' h stop, ' + num(d.workH, 1) + ' h in working hours<br>' + num(d.workH * d.tph) + ' tests outsourced or delayed<br>Emergency call-out<br>' + inr(Math.max(0, d.wasteUnplanned - d.wasteBase)) + ' extra reagent lost</div></div><div class="mid">vs</div><div class="pane ok"><div class="note">Planned service</div><div class="big c-ok">' + inr(d.plannedCost) + '</div><div class="note mt-s">' + d.dur + ' h slot, off-peak<br>' + num(d.routed) + ' tests re-routed, ' + num(d.held, 1) + ' held<br>Scheduled visit<br>' + inr(Math.max(0, d.wastePlanned - d.wasteBase)) + ' extra reagent lost</div></div></div><div class="callout ok mt-s" style="padding:10px 14px"><div><h4>' + inr(d.avoided) + ' avoided on this one event</h4><p>Cost assumptions are editable on the Savings screen.</p></div></div>') +
      card('Check the prediction against the simulator', 'The model never saw what happens next. The simulator did.', '<div id="truth"><button class="btn twin" id="reveal">Reveal what actually happens</button><p class="note mt-s">Use this in the demo after the plan is on screen.</p></div>', '<span class="pill twin">Simulation</span>') +
      card('Audit trail', 'Every recommendation and decision is recorded', '<div class="tl" id="audit">' + '<div class="tl-i warn"><div class="d">' + tfmt(an.riskTs[Math.max(0, an.riskTs.length - 1 - an.riskSeries.slice().reverse().findIndex(v => v < D.models.risk.thresholdProb))]) + '</div><div class="t">Alert raised by risk model</div><div class="tx">Score stayed above threshold for three consecutive 6-hour readings</div></div><div class="tl-i"><div class="d">' + tfmt(D.meta.now) + '</div><div class="t">Coordinated plan generated</div><div class="tx">Maintenance window, routing, reagent holds and cost impact</div></div>' + (done ? '<div class="tl-i"><div class="d">' + tfmt(done.at) + '</div><div class="t">Approved by laboratory in-charge</div><div class="tx">' + done.wo + '</div></div>' : '') + '</div>') +
      '</div></div>';
    U.chart($('#slotc'), { type: 'bar', data: { labels: load.map((_, h) => h + ':00'), datasets: [{ data: load, backgroundColor: load.map((_, h) => (h >= d.slot.hour && h < d.slot.hour + d.dur ? C.ok : '#cbd5e1')), borderRadius: 3 }] },
      options: { scales: U.axes({ y: { grid: { color: C.grid }, border: { display: false }, ticks: { maxTicksLimit: 3 }, title: { display: true, text: 'tests / hour, ' + LP.fmtDay(d.slot.day) } } }) } });
    const ap = $('#approve'); if (ap) ap.onclick = () => { LP.state.downDays = d.plannedScen; if (d.burn) Object.assign(LP.state.override, d.burn.override); LP.state.approved.push({ id, at: new Date(LP.NOW.getTime() + (4 + LP.state.approved.length * 3) * 60000).toISOString(), wo: 'WO-2611-' + (40 + LP.state.approved.length) }); U.toast('Plan approved. Reagent twins and reorder points recalculated.'); U.refresh(); };
    const df = $('#defer'); if (df) df.onclick = () => U.toast('Deferred. LabPulse will re-evaluate at the next 6-hour reading.');
    $('#reveal').onclick = () => { const t = d.truth; $('#truth').innerHTML = t ? '<div class="reveal"><div class="note">Simulator ground truth, hidden from the model</div><div class="big c-twin" style="font-size:24px;margin:4px 0">' + t.comp + ' fails on ' + tfmt(t.at) + '</div><p>' + num(t.inDays, 1) + ' days from now, ' + num(t.downH) + ' h of downtime. LabPulse predicted ' + rulTxt(d.comp.rul) + ' and scheduled the service for ' + LP.fmtDay(d.slot.day) + ', <b>' + num(t.inDays - d.slot.day - d.slot.hour / 24 + 0.25, 1) + ' days before the failure</b>.</p></div>' : '<div class="note">No failure of this type occurs in the simulated future.</div>'; };
  } });

  window.LPV = { actions, allTwins, rulTxt };
})();
