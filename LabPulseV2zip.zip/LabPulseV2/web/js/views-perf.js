/* LabPulse V2 - Performance analytics (fleet reliability and utilisation) + condition-monitoring widgets for the analyzer twin. */
(function () {
  'use strict';
  const LP = window.LP, D = LP.D, U = window.LPUI;
  const { $, esc, num, inr, pct, dfmt, tfmt, pill, C, kpi, card } = U;

  // ------------------------------------------------------------------ Performance analytics
  U.view('performance', { title: 'Performance analytics', sub: 'Reliability, utilisation and downtime across the analyzer fleet', nav: { sec: 'Operations', label: 'Performance analytics', icon: 'coin' }, render(el) {
    const fails = D.siteFailures, an = D.analyzers;
    const unplanned = LP.sum(fails.map(f => f.downH));
    const pmDone = LP.sum(an.map(a => a.pm.filter(p => new Date(p) <= LP.NOW && new Date(p) > LP.addDays(-365)).length)), planned = pmDone * 3;
    const opH = an.length * 365 * 24 - unplanned - planned, mtbf = fails.length ? opH / fails.length : opH, mttr = fails.length ? unplanned / fails.length : 0;
    const n = an[0].daily.tests.length, labels = Array.from({ length: 30 }, (_, i) => dfmt(new Date(new Date(an[0].daily.start).getTime() + (n - 30 + i) * 86400000)));
    const util = an.map(a => LP.mean(a.daily.tests.slice(-30)) / (a.throughput * 8) * 100);
    const byMode = {}; fails.forEach(f => { byMode[f.comp] = (byMode[f.comp] || 0) + f.downH; });
    el.innerHTML =
      '<div class="grid g4">' + kpi('Mean time between failures', num(mtbf) + ' hrs', an.length + ' analyzers, last 12 months', '', 'gauge', 'MTBF') + kpi('Mean time to repair', num(mttr, 1) + ' hrs', fails.length + ' unplanned failures', 'ok', 'wrench', 'MTTR') +
      kpi('Planned downtime', num(planned) + ' hrs', pmDone + ' routine service visits', '', 'calok', 'Planned') + kpi('Unplanned downtime', num(unplanned) + ' hrs', 'Would be about ' + num(LP.savings().hoursLp) + ' hrs with advance warning', 'bad', 'calx', 'Unplanned') + '</div>' +
      '<div class="mt">' + card('Throughput trends (last 30 days)', 'Tests reported per analyzer, per day', '<div class="chart lg" id="pf-thr"></div>') + '</div>' +
      '<div class="grid g2 mt">' + card('Average instrument utilisation', 'Daily tests as a share of rated capacity over an 8-hour shift. Spare capacity is what makes re-routing possible.', '<div class="chart md" id="pf-util"></div>') +
      card('Downtime distribution', 'Hours in the last 12 months', '<div class="chart md" id="pf-down"></div>') + '</div>' +
      '<div class="grid g2 mt">' + card('Unplanned downtime by sub-assembly', 'Hours lost, last 12 months', '<div class="chart md" id="pf-mode"></div>') +
      '<div class="card"><div class="card-h"><div><h3>Failure log</h3><div class="sub">Every unplanned stop in the last 12 months</div></div></div><div class="card-b flush"><table class="tbl"><thead><tr><th>Date</th><th>Analyzer</th><th>Sub-assembly</th><th class="num">Hours down</th></tr></thead><tbody>' +
      fails.slice().sort((x, y) => (x.at < y.at ? 1 : -1)).map(f => '<tr><td>' + dfmt(f.at, { day: 'numeric', month: 'short', year: 'numeric' }) + '</td><td><span class="lnk" data-go="analyzer/' + f.unit + '">' + f.unit + '</span></td><td>' + f.comp + '</td><td class="num">' + num(f.downH, 1) + '</td></tr>').join('') + '</tbody></table></div></div></div>';
    U.chart($('#pf-thr'), { type: 'line', data: { labels, datasets: an.map((a, i) => ({ label: a.id + ' · ' + a.model, data: a.daily.tests.slice(-30), borderColor: U.PAL[i], backgroundColor: U.PAL[i] + '22', pointRadius: 3, pointBackgroundColor: '#fff', pointBorderColor: U.PAL[i], pointBorderWidth: 1.6, tension: 0.4, borderWidth: 2.4 })) },
      options: { scales: U.axes({ x: { grid: { color: C.grid }, ticks: { maxTicksLimit: 15, maxRotation: 30 } } }), plugins: { legend: U.legendOn } } });
    U.chart($('#pf-util'), { type: 'bar', data: { labels: an.map(a => a.id + ' ' + a.model), datasets: [{ data: util, backgroundColor: '#f59e0b', borderRadius: 3, maxBarThickness: 90 }] }, options: { scales: U.axes({ y: { min: 0, max: 40, grid: { color: C.grid }, border: { display: false }, ticks: { callback: v => v + '%' } } }), plugins: { tooltip: { callbacks: { label: c => num(c.parsed.y, 1) + '% of rated capacity' } } } } });
    U.chart($('#pf-down'), { type: 'doughnut', data: { labels: ['Planned service', 'Unplanned failure'], datasets: [{ data: [planned, unplanned], backgroundColor: ['#3b82f6', '#ef4444'], borderColor: '#fff', borderWidth: 2 }] }, options: { cutout: '52%', plugins: { legend: U.legendOn, tooltip: { callbacks: { label: c => c.label + ': ' + num(c.parsed) + ' hrs' } } } } });
    const mk = Object.keys(byMode).sort((x, y) => byMode[y] - byMode[x]);
    U.chart($('#pf-mode'), { type: 'bar', data: { labels: mk, datasets: [{ data: mk.map(k => byMode[k]), backgroundColor: '#0e9fc4', borderRadius: 3 }] }, options: { indexAxis: 'y', scales: { x: { grid: { color: C.grid }, border: { display: false } }, y: { grid: { display: false } } } } });
  } });

  // ------------------------------------------------------------------ Condition-monitoring widget grid (used by the analyzer twin)
  const allAnom = [].concat.apply([], D.analyzers.map(a => a.anomSeries)), aMin = Math.min.apply(null, allAnom), aMax = Math.max.apply(null, allAnom);
  const idx = v => Math.max(0, Math.min(1000, (v - aMin) / (aMax - aMin) * 1000));
  const TILES = [['probe_kpa', 'Aspiration pressure', 'kPa', 1, 'probe'], ['vib', 'Carousel vibration', 'mm/s', 2, 'drive'], ['bay_temp', 'Reagent bay temperature', '°C', 1, 'cooler']];
  U.condition = function (st, compStatus) {
    const an = st.an, thr = D.models.risk.thresholdProb, cur = idx(LP.mean(an.anomSeries.slice(-4)));
    const sev = st.tier === 'critical' ? 3 : st.tier === 'risk' ? 2 : 0, sevCol = sev === 3 ? '#dc2626' : sev === 2 ? '#d97706' : '#16a34a';
    const since = an.riskTs[Math.max(0, an.riskTs.length - 1 - an.riskSeries.slice().reverse().findIndex(v => v < thr))];
    const alarms = [];
    if (st.alerting) {
      alarms.push(['', 'Failure-risk threshold exceeded', tfmt(since), an.id + ' · ' + (st.withRul || st.worst).label]);
      an.drivers.filter(d => Math.abs(d.z) >= 3).slice(0, 2).forEach(d => alarms.push(['warn', d.signal + ' outside own baseline', tfmt(D.meta.now), (d.z > 0 ? '+' : '') + num(d.z, 1) + ' σ · now ' + num(d.now, 2) + ', baseline ' + num(d.base, 2)]));
    }
    const tile = t => { const v = an.daily[t[0]], now = v[v.length - 1], prev = LP.mean(v.slice(-8, -1).filter(x => x != null)), ch = (now - prev) / prev * 100, c = st.alerting ? compStatus(st.comps.find(x => x.key === t[4])) : 'ok';
      return '<div class="card wd"><div class="wd-title">' + t[1] + '</div><div class="wd-big">' + num(now, t[3]) + '<small> ' + t[2] + '</small></div><div class="note">' + num(Math.abs(ch), 2) + '% ' + (ch >= 0 ? 'higher' : 'lower') + ' than last week’s average</div>' + U.strip(v.slice(-40), c === 'ok' ? '' : c) + '</div>'; };
    const html = '<div class="h-sec">Condition monitoring</div><div class="grid g4">' +
      '<div class="card wd"><div class="wd-title">General anomaly index</div>' + U.semi(cur, 1000, 'Anomaly index') + '</div>' +
      '<div class="card wd"><div class="wd-title">Device health</div><div class="sev" style="margin-top:14px"><div><div class="note">Device health</div><div class="wd-big">' + sev + ' Severity</div><div class="note">' + tfmt(D.meta.now) + '</div><div style="margin-top:8px">' + pill(st.tier, st.label) + '</div></div>' +
        '<svg width="120" height="120" viewBox="0 0 120 120"><circle cx="60" cy="60" r="46" fill="none" stroke="#e9eef4" stroke-width="9" stroke-dasharray="217 289" transform="rotate(135 60 60)"/><circle cx="60" cy="60" r="46" fill="none" stroke="' + sevCol + '" stroke-width="9" stroke-linecap="round" stroke-dasharray="' + (217 * Math.max(0.08, sev / 3)).toFixed(0) + ' 289" transform="rotate(135 60 60)"/><text x="60" y="66" text-anchor="middle" font-size="26" font-weight="700" fill="#0f1b2d">' + sev + '</text><text x="60" y="84" text-anchor="middle" font-size="10" fill="#5b6b7f">of 3</text></svg></div></div>' +
      tile(TILES[0]) + tile(TILES[1]) + '</div>' +
      '<div class="grid g4 mt">' +
      '<div class="card wd"><div class="wd-title">Open alarms</div>' + (alarms.length ? alarms.map(a => '<div class="alarm ' + a[0] + '"><span class="tri">▲</span><div><b>' + esc(a[1]) + '</b><span>' + a[2] + '</span><span>' + esc(a[3]) + '</span></div></div>').join('') : '<div class="note" style="padding:18px 0">No open alarms. Every signal is inside this analyzer’s own baseline.</div>') + '</div>' +
      '<div class="card wd"><div class="wd-title">Alarm trend · 0 normal, 1 imminent failure, 2 failure</div><div class="chart sm" id="cm-alarm"></div></div>' +
      '<div class="card wd"><div class="wd-title">Root cause analysis</div><div class="chart sm" id="cm-rca"></div></div>' +
      '<div class="stack">' + tile(TILES[2]) + '<div class="card wd"><div class="wd-title">Processing</div><div class="row sp"><span class="note">Status: <b style="color:var(--ink)">Monitoring</b></span><span class="note">' + tfmt(D.meta.now) + '</span></div><div class="pipe"><div><i>1</i>Buffering</div><div><i>2</i>Baseline</div><div><i>3</i>Learning</div><div class="live"><i>4</i>Monitoring</div></div></div></div>' +
      '</div>';
    const draw = () => {
      const fail = an.events.filter(e => !e.caught).map(e => new Date(e.at).getTime());
      const level = an.riskSeries.map((v, i) => { const t = new Date(an.riskTs[i]).getTime(); return fail.some(f => t >= f && t - f < 36 * 3600000) ? 2 : v >= thr ? 1 : 0; });
      U.chart($('#cm-alarm'), { type: 'line', data: { labels: an.riskTs.map(t => dfmt(t)), datasets: [{ data: level, borderColor: '#c026d3', stepped: true, borderWidth: 1.8 }] }, options: { scales: U.axes({ y: { min: -0.2, max: 2.2, grid: { color: C.grid }, border: { display: false }, ticks: { stepSize: 1, callback: v => (Number.isInteger(v) ? v : '') } } }) } });
      const dr = an.drivers.slice(0, 5);
      U.chart($('#cm-rca'), { type: 'bar', data: { labels: dr.map(d => d.signal.replace(' (load-normalised)', '').replace('Reaction ', '').replace('Carousel ', '')), datasets: [{ data: dr.map(d => Math.abs(d.z)), backgroundColor: dr.map(d => (Math.abs(d.z) >= 3 ? '#dc2626' : Math.abs(d.z) >= 2 ? '#f59e0b' : '#5eb8ae')), borderRadius: 3 }] },
        options: { indexAxis: 'y', scales: { x: { grid: { color: C.grid }, border: { display: false }, title: { display: true, text: 'shift from own baseline, σ' } }, y: { grid: { display: false }, ticks: { font: { size: 11 } } } } } });
    };
    return { html, draw };
  };
})();
