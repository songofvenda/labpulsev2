/* LabPulse V2 - procedural 3D digital twin of a benchtop biochemistry analyzer (Three.js, no external models).
   A generic random-access analyzer: sample carousel, reaction cuvette ring, refrigerated reagent carousel,
   sampling / reagent arms, wash station, photometer, syringe pumps, carousel drive, electronics. */
(function () {
  'use strict';
  const T = window.THREE;
  const COL = { ok: 0x15803d, risk: 0xd97706, critical: 0xdc2626, quarantine: 0x7c3aed, none: 0x94a3b8 };
  const BRAND = { 'Mindray BS-480': 0x0e7490, 'Erba XL-640': 0x1d4ed8, 'Beckman AU480': 0x6d28d9 };

  function mat(color, o) { return new T.MeshStandardMaterial(Object.assign({ color, roughness: 0.62, metalness: 0.05 }, o || {})); }
  function mesh(geo, m, x, y, z, cast) { const b = new T.Mesh(geo, m); b.position.set(x || 0, y || 0, z || 0); b.castShadow = cast !== false; b.receiveShadow = true; return b; }
  function box(w, h, d, m, x, y, z) { return mesh(new T.BoxGeometry(w, h, d), m, x, y, z); }
  function cyl(r, h, m, x, y, z, seg) { return mesh(new T.CylinderGeometry(r, r, h, seg || 40), m, x, y, z); }
  function label(text, sub, color) {
    const c = document.createElement('canvas'); c.width = 512; c.height = 128; const g = c.getContext('2d');
    g.fillStyle = '#f8fafc'; g.fillRect(0, 0, 512, 128);
    g.fillStyle = color; g.fillRect(0, 0, 14, 128);
    g.fillStyle = '#0f1b2d'; g.font = '600 46px Inter, Segoe UI, sans-serif'; g.fillText(text, 34, 58);
    g.fillStyle = '#5b6b7f'; g.font = '400 30px Inter, Segoe UI, sans-serif'; g.fillText(sub, 34, 102);
    const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; t.anisotropy = 4; return t;
  }

  /* Build one analyzer. Returns { group, parts: {key: Group}, bottles: [Mesh], anim(t) }. */
  function buildAnalyzer(an) {
    const g = new T.Group(), parts = {}, pick = [];
    const brand = BRAND[an.model] || 0x0e7490;
    const shell = mat(0xeef1f5), shellDark = mat(0xcfd6df), deck = mat(0xf8fafc, { roughness: 0.5 }), steel = mat(0xb6c0cc, { metalness: 0.75, roughness: 0.28 });
    const part = (key, name, explode) => { const p = new T.Group(); p.userData = { key, name, explode: explode || [0, 0, 0], home: null }; parts[key] = p; g.add(p); return p; };
    const reg = (p, m, noAdd) => { m.userData.part = p.userData.key; pick.push(m); if (!noAdd) p.add(m); return m; };

    // cabinet
    const cab = part('cabinet', 'Cabinet', [0, -0.55, 0]);
    const body = box(3.5, 0.9, 1.75, shell, 0, 0.5, 0); cab.add(body);
    cab.add(box(3.56, 0.1, 1.8, shellDark, 0, 0.05, 0));
    cab.add(box(3.5, 0.045, 1.75, deck, 0, 0.972, 0));
    cab.add(box(3.5, 0.06, 0.02, mat(brand), 0, 0.82, 0.885));                          // brand stripe
    cab.add(box(0.5, 0.34, 0.02, mat(0xdfe5ec), -1.2, 0.5, 0.885)); cab.add(box(0.5, 0.34, 0.02, mat(0xdfe5ec), 1.2, 0.5, 0.885));
    const back = box(3.5, 0.62, 0.08, shell, 0, 1.3, -0.84); cab.add(back);
    const plate = mesh(new T.PlaneGeometry(1.5, 0.375), new T.MeshBasicMaterial({ map: label(an.id, an.model, '#' + brand.toString(16).padStart(6, '0')) }), -0.85, 1.32, -0.795, false); cab.add(plate);
    cab.userData.shell = [body, back];

    // sample carousel
    const sc = part('sample', 'Sample carousel', [-0.9, 0.5, 0.5]); sc.position.set(-1.1, 1.0, 0.2);
    const scDisc = new T.Group(); sc.add(scDisc);
    scDisc.add(cyl(0.5, 0.07, mat(0xdde3ea), 0, 0.035, 0, 48));
    scDisc.add(cyl(0.12, 0.16, mat(0xc5cdd8), 0, 0.08, 0));
    const caps = [0xdc2626, 0x7c3aed, 0xeab308, 0x2563eb, 0x16a34a], glass = mat(0xe9f2f7, { transparent: true, opacity: 0.55, roughness: 0.15 });
    [[0.42, 22], [0.3, 14]].forEach(([r, n], ri) => { for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; const x = Math.cos(a) * r, z = Math.sin(a) * r; if ((i * 7 + ri) % 9 === 0) continue; scDisc.add(cyl(0.021, 0.15, glass, x, 0.14, z, 10)); scDisc.add(cyl(0.023, 0.03, mat(caps[(i + ri * 2) % 5]), x, 0.225, z, 10)); } });

    // reaction ring + incubation bath
    const bath = part('bath', 'Reaction bath', [0, 0.75, 0.2]); bath.position.set(0.02, 1.0, 0.12);
    reg(bath, mesh(new T.CylinderGeometry(0.56, 0.56, 0.09, 64, 1, true), mat(0xbfd9ea, { side: T.DoubleSide }), 0, 0.045, 0));
    reg(bath, mesh(new T.RingGeometry(0.4, 0.56, 64), mat(0xa9d3ec, { transparent: true, opacity: 0.75, roughness: 0.1, side: T.DoubleSide }), 0, 0.07, 0, false)).rotation.x = -Math.PI / 2;
    bath.add(cyl(0.4, 0.1, mat(0xe3e8ee), 0, 0.05, 0, 48));
    const ring = new T.Group(); bath.add(ring);
    const cu = mat(0xf4fbff, { transparent: true, opacity: 0.6, roughness: 0.05 });
    const liq = [0xfde68a, 0xfca5a5, 0xbfdbfe, 0xd9f99d, 0xf5d0fe];
    for (let i = 0; i < 56; i++) { const a = i / 56 * Math.PI * 2; const c = box(0.028, 0.11, 0.04, cu, Math.cos(a) * 0.48, 0.1, Math.sin(a) * 0.48); c.rotation.y = -a; ring.add(c);
      if (i % 3) { const l = box(0.02, 0.05, 0.03, mat(liq[i % 5], { transparent: true, opacity: 0.85 }), Math.cos(a) * 0.48, 0.075, Math.sin(a) * 0.48); l.rotation.y = -a; l.castShadow = false; ring.add(l); } }

    // refrigerated reagent carousel
    const rc = part('cooler', 'Reagent refrigeration', [0.95, 0.55, 0.45]); rc.position.set(1.12, 1.0, 0.16);
    reg(rc, mesh(new T.CylinderGeometry(0.6, 0.6, 0.2, 64, 1, true), mat(0xd7e3ec, { side: T.DoubleSide }), 0, 0.1, 0));
    rc.add(cyl(0.6, 0.02, mat(0xc9d6e2), 0, 0.01, 0, 48));
    const rcDisc = new T.Group(); rc.add(rcDisc);
    const bottles = [];
    [[0.44, 16, 0.11, 0.17], [0.24, 8, 0.1, 0.13]].forEach(([r, n, w, d]) => { for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; const b = new T.Group(); b.position.set(Math.cos(a) * r, 0.03, Math.sin(a) * r); b.rotation.y = -a;
      const bodyM = box(d, 0.2, w, mat(0xffffff, { roughness: 0.35 }), 0, 0.1, 0); const cap = cyl(0.03, 0.035, mat(COL.none), 0, 0.215, 0, 14); const band = box(d + 0.004, 0.05, w + 0.004, mat(COL.none), 0, 0.11, 0);
      b.add(bodyM, cap, band); bodyM.userData.bottle = bottles.length; cap.userData.bottle = bottles.length; band.userData.bottle = bottles.length; pick.push(bodyM, cap, band);
      b.userData = { cap, band, lot: null }; rcDisc.add(b); bottles.push(b); } });
    const lid = mesh(new T.CylinderGeometry(0.62, 0.62, 0.03, 64, 1, false, 0, Math.PI * 1.45), mat(0x9cc5e0, { transparent: true, opacity: 0.28, roughness: 0.1 }), 0, 0.245, 0, false); rc.add(lid);
    const chill = box(0.7, 0.3, 0.6, mat(0x8fb4cf, { metalness: 0.4, roughness: 0.4 }), 0, -0.36, 0); reg(rc, chill);
    for (let i = 0; i < 7; i++) rc.add(box(0.02, 0.26, 0.56, steel, -0.3 + i * 0.1, -0.36, 0.03));

    // arms
    function arm(key, name, px, pz, len, color, explode) {
      const p = part(key, name, explode); p.position.set(px, 1.0, pz);
      p.add(cyl(0.05, 0.06, shellDark, 0, 0.03, 0, 20));
      const sw = new T.Group(); p.add(sw);
      reg(p, cyl(0.032, 0.36, steel, 0, 0.2, 0, 16)); sw.position.y = 0.36;
      const bar = box(len, 0.045, 0.07, mat(color), len / 2 - 0.03, 0.02, 0); sw.add(bar); reg(p, bar, true);
      const needle = cyl(0.007, 0.26, steel, len - 0.06, -0.12, 0, 8); sw.add(needle);
      sw.add(cyl(0.022, 0.05, mat(0x334155), len - 0.06, 0.02, 0, 12));
      p.userData.swing = sw; p.userData.needle = needle; return p;
    }
    const probe = arm('probe', 'Sample probe & syringe', -0.5, -0.32, 0.52, 0xf1f5f9, [-0.35, 0.8, -0.45]);
    const rarm = arm('rarm', 'Reagent probe', 0.58, -0.36, 0.56, 0xf1f5f9, [0.3, 0.9, -0.5]);
    const mixer = arm('mixer', 'Mixer', 0.02, 0.84, 0.3, 0xe2e8f0, [0, 0.6, 0.6]);
    // syringe pump module belongs to the probe sub-system
    const syr = new T.Group(); syr.position.set(-0.47, -0.42, 0.9); probe.add(syr);
    const syrPlate = box(0.5, 0.36, 0.05, mat(0xe2e8f0), 0, 0, 0); syr.add(syrPlate); reg(probe, syrPlate, true);
    [-0.12, 0.12].forEach(x => { syr.add(cyl(0.035, 0.22, mat(0xdff3ff, { transparent: true, opacity: 0.6, roughness: 0.05 }), x, 0, 0.05, 16)); const pl = cyl(0.03, 0.04, mat(0x1e293b), x, -0.03, 0.05, 16); pl.userData.plunger = true; syr.add(pl); });

    // wash station
    const wash = part('wash', 'Cuvette wash station', [-0.3, 0.9, -0.6]); wash.position.set(-0.22, 1.0, -0.42);
    reg(wash, cyl(0.03, 0.3, steel, 0, 0.15, 0, 12));
    reg(wash, box(0.34, 0.1, 0.16, mat(0xe2e8f0), 0.12, 0.33, 0.1));
    for (let i = 0; i < 6; i++) wash.add(cyl(0.008, 0.16, steel, 0.0 + i * 0.045, 0.21, 0.13 + i * 0.012, 6));

    // photometer (lamp + detector)
    const lamp = part('lamp', 'Photometer lamp', [0.25, 0.7, 0.75]); lamp.position.set(0.02, 1.0, 0.12);
    reg(lamp, box(0.2, 0.15, 0.16, mat(0x334155, { roughness: 0.4 }), 0.42, 0.075, 0.5));
    const bulb = mesh(new T.SphereGeometry(0.035, 16, 12), new T.MeshStandardMaterial({ color: 0xfff3c4, emissive: 0xffc94d, emissiveIntensity: 1.6 }), 0.36, 0.1, 0.43, false); lamp.add(bulb);
    const beam = mesh(new T.CylinderGeometry(0.012, 0.012, 0.3, 8), new T.MeshBasicMaterial({ color: 0xffd766, transparent: true, opacity: 0.55 }), 0.27, 0.1, 0.33, false);
    beam.rotation.z = Math.PI / 2; beam.rotation.y = -0.82; lamp.add(beam);
    reg(lamp, box(0.09, 0.1, 0.09, mat(0x475569), 0.17, 0.06, 0.21));
    lamp.userData.bulb = bulb; lamp.userData.beam = beam; bulb.userData.keepEmissive = true;

    // carousel drive (inside the cabinet, under the reaction ring)
    const drive = part('drive', 'Carousel drive', [0, -0.75, 0.9]); drive.position.set(0.02, 0.55, 0.12);
    reg(drive, cyl(0.13, 0.3, mat(0x475569, { metalness: 0.6, roughness: 0.35 }), 0.3, 0.0, 0, 24));
    const gear = cyl(0.3, 0.035, steel, 0, 0.2, 0, 36); reg(drive, gear); drive.userData.gear = gear;
    reg(drive, cyl(0.035, 0.26, steel, 0, 0.3, 0, 12));
    const belt = mesh(new T.TorusGeometry(0.24, 0.012, 8, 40), mat(0x1e293b), 0.14, 0.17, 0, false); belt.rotation.x = Math.PI / 2; belt.scale.set(1.35, 0.75, 1); drive.add(belt);

    // electronics
    const board = part('board', 'Power / control electronics', [-1.1, -0.6, -0.7]); board.position.set(-1.15, 0.5, -0.45);
    reg(board, box(0.8, 0.5, 0.5, mat(0xd5dbe3, { metalness: 0.3 }), 0, 0, 0));
    reg(board, box(0.62, 0.36, 0.02, mat(0x166534, { roughness: 0.5 }), 0, 0, 0.262));
    for (let i = 0; i < 8; i++) board.add(box(0.07, 0.05, 0.03, mat(i % 3 ? 0x0f172a : 0xca8a04), -0.24 + (i % 4) * 0.16, -0.08 + Math.floor(i / 4) * 0.16, 0.285));

    // operator console
    const mon = part('console', 'Operator console', [0.9, 0.3, 0.2]); mon.position.set(1.95, 1.0, -0.3);
    mon.add(cyl(0.03, 0.5, steel, 0, 0.25, 0, 12));
    const scr = box(0.62, 0.42, 0.035, mat(0x1e293b), -0.05, 0.62, 0.05); scr.rotation.y = -0.5; scr.rotation.x = -0.12; mon.add(scr);
    const c2 = document.createElement('canvas'); c2.width = 320; c2.height = 208; const scrTex = new T.CanvasTexture(c2); scrTex.colorSpace = T.SRGBColorSpace;
    const face = mesh(new T.PlaneGeometry(0.57, 0.37), new T.MeshBasicMaterial({ map: scrTex }), 0, 0, 0.019, false); scr.add(face);
    mon.userData.draw = (status, health) => { const x = c2.getContext('2d'); x.fillStyle = '#f8fafc'; x.fillRect(0, 0, 320, 208);
      x.fillStyle = status === 'ok' ? '#15803d' : status === 'critical' ? '#dc2626' : '#d97706'; x.fillRect(0, 0, 320, 44);
      x.fillStyle = '#fff'; x.font = '600 24px Segoe UI, sans-serif'; x.fillText(an.id + '  ' + (status === 'ok' ? 'Normal' : status === 'critical' ? 'Act now' : 'Plan service'), 14, 30);
      x.fillStyle = '#0f1b2d'; x.font = '700 78px Segoe UI, sans-serif'; x.fillText(String(health), 14, 132); x.font = '400 22px Segoe UI, sans-serif'; x.fillStyle = '#5b6b7f'; x.fillText('health score', 14, 168);
      x.strokeStyle = '#1d4ed8'; x.lineWidth = 3; x.beginPath(); for (let i = 0; i < 16; i++) { const yy = 120 - Math.sin(i * 0.9) * 14 - (status === 'ok' ? 0 : i * 2.2); x[i ? 'lineTo' : 'moveTo'](170 + i * 9, yy); } x.stroke(); scrTex.needsUpdate = true; };

    Object.values(parts).forEach(p => { p.userData.home = p.position.clone(); });
    const sAng = { probe: [2.55, 0.62], rarm: [0.42, 2.45], mixer: [-1.25, -1.9] };
    function anim(t, running, status) {
      const ph = (t % 4) / 4, e = x => x * x * (3 - 2 * x);
      scDisc.rotation.y = running ? -(Math.floor(t / 4) + e(Math.min(1, ph * 5))) * (Math.PI * 2 / 22) : scDisc.rotation.y;
      ring.rotation.y = running ? Math.floor(t / 1) * (Math.PI * 2 / 56) * 3 + e(Math.min(1, (t % 1) * 3)) * (Math.PI * 2 / 56) * 3 : ring.rotation.y;
      rcDisc.rotation.y = running ? Math.floor(t / 2) * (Math.PI / 8) + e(Math.min(1, (t % 2) * 2)) * (Math.PI / 8) : rcDisc.rotation.y;
      gear.rotation.y = ring.rotation.y * 2;
      if (status && status.drive && status.drive !== 'ok') drive.position.x = (drive.userData.cur || drive.userData.home).x + Math.sin(t * 60) * 0.004;
      [['probe', probe, 0], ['rarm', rarm, 0.5], ['mixer', mixer, 0.25]].forEach(([k, p, off]) => {
        const q = running ? ((t / 4 + off) % 1) : 0.1; let a, dip = 0;
        if (q < 0.2) { a = 0; dip = Math.sin(q / 0.2 * Math.PI); } else if (q < 0.45) a = e((q - 0.2) / 0.25); else if (q < 0.65) { a = 1; dip = Math.sin((q - 0.45) / 0.2 * Math.PI); } else a = 1 - e((q - 0.65) / 0.35);
        const jitter = (k === 'probe' && status && status.probe && status.probe !== 'ok') ? Math.sin(t * 37) * 0.012 * (status.probe === 'critical' ? 1.6 : 1) : 0;
        p.userData.swing.rotation.y = sAng[k][0] + (sAng[k][1] - sAng[k][0]) * a + jitter; p.userData.swing.position.y = 0.36 - dip * 0.1;
      });
      syr.children.forEach(c => { if (c.userData.plunger) c.position.y = -0.03 - Math.abs(Math.sin(t * Math.PI / 2)) * 0.06; });
      const lampSt = status && status.lamp;
      bulb.material.emissiveIntensity = lampSt && lampSt !== 'ok' ? 0.5 + Math.abs(Math.sin(t * 9)) * (Math.sin(t * 2.3) > 0.4 ? 0.2 : 1.0) : 1.6;
      beam.material.opacity = lampSt && lampSt !== 'ok' ? 0.18 + 0.2 * Math.abs(Math.sin(t * 9)) : 0.55;
    }
    return { group: g, parts, bottles, pick, anim, lid, mon, shell: cab.userData.shell };
  }

  /* Shared stage: renderer, lights, orbit controls, picking, HTML callouts. */
  function stage(el, opts) {
    const renderer = new T.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = T.PCFSoftShadowMap;
    renderer.outputColorSpace = T.SRGBColorSpace; renderer.toneMapping = T.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.12;
    el.appendChild(renderer.domElement); renderer.domElement.style.display = 'block';
    const scene = new T.Scene();
    const cam = new T.PerspectiveCamera(opts.fov || 26, 1, 0.1, 100);
    scene.add(new T.HemisphereLight(0xffffff, 0xcdd6e0, 1.15));
    const sun = new T.DirectionalLight(0xffffff, 1.9); sun.position.set(4.5, 8, 5.5); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
    const sc = sun.shadow.camera; sc.left = -opts.span; sc.right = opts.span; sc.top = opts.span; sc.bottom = -opts.span; sc.near = 1; sc.far = 30; sun.shadow.bias = -0.0004; sun.shadow.radius = 5; scene.add(sun);
    const fill = new T.DirectionalLight(0xdbeafe, 0.55); fill.position.set(-6, 3, -4); scene.add(fill);
    const floor = mesh(new T.PlaneGeometry(60, 60), new T.ShadowMaterial({ opacity: 0.16 }), 0, 0, 0, false); floor.rotation.x = -Math.PI / 2; scene.add(floor);
    const grid = new T.GridHelper(opts.span * 4, opts.span * 8, 0xcbd5e1, 0xe2e8f0); grid.position.y = 0.001; grid.material.transparent = true; grid.material.opacity = 0.55; scene.add(grid);

    const orb = { az: opts.az != null ? opts.az : 0.62, pol: opts.pol != null ? opts.pol : 1.02, dist: opts.dist, target: new T.Vector3(opts.tx || 0, opts.ty != null ? opts.ty : 0.75, 0), auto: opts.auto !== false, idle: 0 };
    const place = () => { const s = Math.sin(orb.pol); cam.position.set(orb.target.x + orb.dist * s * Math.sin(orb.az), orb.target.y + orb.dist * Math.cos(orb.pol), orb.target.z + orb.dist * s * Math.cos(orb.az)); cam.lookAt(orb.target); };
    const dom = renderer.domElement; let drag = null, moved = 0;
    dom.style.touchAction = 'none'; dom.style.cursor = 'grab';
    const onDown = e => { drag = { x: e.clientX, y: e.clientY }; moved = 0; dom.setPointerCapture(e.pointerId); dom.style.cursor = 'grabbing'; };
    const onMove = e => { if (drag) { const dx = e.clientX - drag.x, dy = e.clientY - drag.y; moved += Math.abs(dx) + Math.abs(dy); orb.az -= dx * 0.006; orb.pol = Math.min(1.45, Math.max(0.3, orb.pol - dy * 0.005)); drag = { x: e.clientX, y: e.clientY }; orb.idle = 0; } else if (opts.onHover) hover(e); };
    const onUp = e => { dom.style.cursor = 'grab'; if (drag && moved < 5 && opts.onPick) { const h = hit(e); if (h) opts.onPick(h); } drag = null; };
    const onWheel = e => { e.preventDefault(); orb.dist = Math.min(opts.dist * 1.7, Math.max(opts.dist * 0.4, orb.dist * (1 + Math.sign(e.deltaY) * 0.08))); orb.idle = 0; };
    dom.addEventListener('pointerdown', onDown); dom.addEventListener('pointermove', onMove); dom.addEventListener('pointerup', onUp); dom.addEventListener('wheel', onWheel, { passive: false });
    const ray = new T.Raycaster(), v2 = new T.Vector2(); let pickables = [];
    function hit(e) { const r = dom.getBoundingClientRect(); v2.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); ray.setFromCamera(v2, cam); const h = ray.intersectObjects(pickables, false)[0]; return h ? h.object : null; }
    function hover(e) { const h = hit(e); dom.style.cursor = h ? 'pointer' : 'grab'; opts.onHover(h, e); }

    const tips = document.createElement('div'); tips.className = 'tw-tips'; el.appendChild(tips);
    const callouts = [];
    function callout(obj, html, cls, offsetY) { const d = document.createElement('div'); d.className = 'tw-callout ' + (cls || ''); d.innerHTML = html; tips.appendChild(d); const c = { obj, d, off: offsetY || 0.25 }; callouts.push(c); return d; }
    function clearCallouts() { callouts.splice(0).forEach(c => c.d.remove()); }
    const wp = new T.Vector3();
    function resize() { const w = el.clientWidth, h = el.clientHeight; if (!w || !h) return; renderer.setSize(w, h, false); dom.style.width = w + 'px'; dom.style.height = h + 'px'; cam.aspect = w / h; cam.updateProjectionMatrix(); }
    const ro = new ResizeObserver(resize); ro.observe(el); resize();
    let raf = 0, alive = true, last = performance.now(), time = 0; const ticks = [];
    function loop(nowMs) {
      if (!alive) return; raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (nowMs - last) / 1000); last = nowMs; time += dt; orb.idle += dt;
      if (orb.auto && orb.idle > 3 && !drag) orb.az += dt * 0.07;
      place(); ticks.forEach(f => f(time, dt));
      renderer.render(scene, cam);
      const w = el.clientWidth, h = el.clientHeight;
      callouts.forEach(c => { c.obj.getWorldPosition(wp); wp.y += c.off; wp.project(cam); const vis = wp.z < 1; c.d.style.display = vis ? '' : 'none'; c.d.style.transform = 'translate(' + ((wp.x * 0.5 + 0.5) * w).toFixed(1) + 'px,' + ((-wp.y * 0.5 + 0.5) * h).toFixed(1) + 'px)'; });
    }
    raf = requestAnimationFrame(loop);
    return { scene, cam, orb, ticks, callout, clearCallouts, setPickables: p => { pickables = p; },
      dispose() { alive = false; cancelAnimationFrame(raf); ro.disconnect(); renderer.dispose(); scene.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) { (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { if (m.map) m.map.dispose(); m.dispose(); }); } }); renderer.forceContextLoss(); el.innerHTML = ''; } };
  }

  function tint(part, status, t) {       // pulse the emissive colour of a flagged sub-assembly
    const col = status === 'critical' ? COL.critical : status === 'risk' ? COL.risk : null;
    part.traverse(o => { if (o.isMesh && o.material && o.material.emissive && !o.userData.keepEmissive) { if (!o.userData.own) { o.material = o.material.clone(); o.userData.own = true; }
      if (col) { o.material.emissive.setHex(col); o.material.emissiveIntensity = 0.16 + 0.22 * (0.5 + 0.5 * Math.sin(t * (status === 'critical' ? 5 : 2.6))); } else o.material.emissiveIntensity = 0; } });
  }

  /* Single-analyzer twin. */
  function mount(el, an, o) {
    o = o || {};
    const st = stage(el, { span: 3.2, dist: 8.4, ty: 0.85, onPick: m => { if (m.userData.bottle != null) { const b = A.bottles[m.userData.bottle]; if (b.userData.lot && o.onLot) o.onLot(b.userData.lot); } else if (m.userData.part && o.onPart) o.onPart(m.userData.part); },
      onHover: (m, e) => { const r = el.getBoundingClientRect(); let txt = ''; if (m) { if (m.userData.bottle != null) { const b = A.bottles[m.userData.bottle]; txt = b.userData.lot ? b.userData.tip : 'Empty reagent position'; } else if (m.userData.part) txt = A.parts[m.userData.part].userData.name; }
        hov.style.display = txt ? 'block' : 'none'; hov.innerHTML = txt; hov.style.left = (e.clientX - r.left + 14) + 'px'; hov.style.top = (e.clientY - r.top + 12) + 'px'; } });
    const hov = document.createElement('div'); hov.className = 'tw-hover'; el.appendChild(hov);
    const A = buildAnalyzer(an); st.scene.add(A.group); st.setPickables(A.pick);
    let status = {}, explode = 0, explodeTo = 0, xray = false, running = true, bottleSt = [];
    Object.values(A.parts).forEach(p => { p.userData.cur = p.position.clone(); });
    A.bottles.forEach(b => { b.visible = false; });
    st.ticks.push((t, dt) => {
      explode += (explodeTo - explode) * Math.min(1, dt * 5);
      Object.values(A.parts).forEach(p => { const h = p.userData.home, e = p.userData.explode; p.position.set(h.x + e[0] * explode, h.y + e[1] * explode, h.z + e[2] * explode); p.userData.cur.copy(p.position); });
      A.anim(t, running, status);
      Object.keys(A.parts).forEach(k => { if (status[k] !== undefined) tint(A.parts[k], status[k], t); });
      bottleSt.forEach((s, i) => { const b = A.bottles[i]; if (s === 'critical' || s === 'risk') { const k = 0.35 + 0.35 * Math.sin(t * (s === 'critical' ? 5 : 2.6)); b.userData.band.material.emissive.setHex(COL[s]); b.userData.band.material.emissiveIntensity = k; } });
    });
    const api = {
      setStatus(map, health, tier) { status = map; A.mon.userData.draw(tier, health); st.clearCallouts();
        Object.keys(map).forEach(k => { if (map[k] === 'ok' || !A.parts[k]) return; const info = (o.calloutText && o.calloutText(k)) || A.parts[k].userData.name; const d = st.callout(A.parts[k], info, map[k], k === 'drive' ? 0.5 : 0.62); d.onclick = () => o.onPart && o.onPart(k); }); },
      setBottles(list) { bottleSt = []; A.bottles.forEach((b, i) => { const l = list[i]; b.visible = !!l; b.userData.lot = l ? l.id : null; if (!l) return; b.userData.tip = l.tip; bottleSt[i] = l.status;
        [b.userData.cap, b.userData.band].forEach(m => { m.material = m.material.clone(); m.material.color.setHex(COL[l.status] || COL.ok); }); }); },
      setExploded(v) { explodeTo = v ? 1 : 0; st.orb.dist = v ? 11 : 8.4; }, setXray(v) { xray = v; A.shell.forEach(m => { m.material = m.material.clone(); m.material.transparent = v; m.material.opacity = v ? 0.16 : 1; m.material.depthWrite = !v; m.castShadow = !v; }); },
      setLid(v) { A.lid.visible = v; }, setRunning(v) { running = v; }, focus(k) { st.orb.idle = -4; }, dispose: st.dispose,
    };
    return api;
  }

  /* Lab floor: the three analyzers side by side, each flagged by status. */
  function mountFloor(el, list, o) {
    o = o || {};
    const st = stage(el, { span: 7.5, dist: 19.5, ty: 0.45, az: 0.22, pol: 0.9, fov: 24, auto: false, onPick: m => { let p = m; while (p && !p.userData.an) p = p.parent; if (p && o.onPick) o.onPick(p.userData.an); },
      onHover: () => {} });
    const all = [], picks = [];
    list.forEach((it, i) => { const A = buildAnalyzer(it.an); A.group.position.x = (i - (list.length - 1) / 2) * 4.5; A.group.userData.an = it.an.id; st.scene.add(A.group); all.push({ A, it });
      A.group.traverse(m => { if (m.isMesh) picks.push(m); });
      A.mon.userData.draw(it.tier, it.health); A.bottles.forEach((b, j) => { b.visible = j < it.bottles.length; if (j < it.bottles.length) [b.userData.cap, b.userData.band].forEach(m => { m.material = m.material.clone(); m.material.color.setHex(COL[it.bottles[j]] || COL.ok); }); });
      const d = st.callout(A.parts.cabinet, it.html, it.tier, 1.75); d.onclick = () => o.onPick && o.onPick(it.an.id); });
    st.setPickables(picks);
    st.ticks.push(t => { all.forEach(({ A, it }) => { A.anim(t + it.an.id.charCodeAt(4), it.tier !== 'down', it.status); Object.keys(it.status).forEach(k => { if (A.parts[k]) tint(A.parts[k], it.status[k], t); }); }); });
    return { dispose: st.dispose };
  }

  window.LP3D = { mount, mountFloor, supported: () => { try { const c = document.createElement('canvas'); return !!(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl'))); } catch (e) { return false; } } };
})();
