/* LabPulse V2 - UI core: router, formatting, chart helpers, drawer. */
(function () {
  'use strict';
  const LP = window.LP, D = LP.D;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const num = (n, d) => (n == null || isNaN(n) ? '-' : Number(n).toLocaleString('en-IN', { maximumFractionDigits: d || 0, minimumFractionDigits: d || 0 }));
  const inr = n => '₹' + num(Math.round(n));
  const inrK = n => { const a = Math.abs(n); return '₹' + (a >= 1e7 ? num(n / 1e7, 2) + ' Cr' : a >= 1e5 ? num(n / 1e5, 2) + ' L' : a >= 1e4 ? num(n / 1e3, 1) + 'k' : num(Math.round(n))); };
  const pct = (n, d) => num(n * 100, d || 0) + '%';
  const dfmt = (d, o) => new Date(d).toLocaleDateString('en-IN', o || { day: 'numeric', month: 'short' });
  const tfmt = d => new Date(d).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
  const pill = (cls, txt) => '<span class="pill ' + cls + '"><span class="dot ' + cls + '"></span>' + esc(txt) + '</span>';
  const ST = { ok: 'On track', risk: 'At risk', critical: 'Critical', quarantine: 'Quarantined' };
  const ICON = {
    home: '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    cube: '<path d="M12 2l9 5v10l-9 5-9-5V7z"/><path d="M3 7l9 5 9-5M12 12v10"/>',
    flask: '<path d="M9 3h6M10 3v6L4.5 19a1.5 1.5 0 0 0 1.3 2.2h12.4a1.5 1.5 0 0 0 1.3-2.2L14 9V3"/><path d="M7.5 15h9"/>',
    snow: '<path d="M12 2v20M4 6l16 12M20 6L4 18"/>',
    flow: '<circle cx="5" cy="6" r="2.2"/><circle cx="19" cy="6" r="2.2"/><circle cx="12" cy="18" r="2.2"/><path d="M7 7l4 9M17 7l-4 9M7.2 6h9.6"/>',
    coin: '<circle cx="12" cy="12" r="9"/><path d="M9 8h6M9 11.5h6M9.5 8c3.5 0 3.5 5.5 0 5.5L14 17"/>',
    shield: '<path d="M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.500-8-9V6z"/><path d="M8.500 12l2.500 2.500 4.500-5"/>',
    plug: '<path d="M9 3v5M15 3v5M6 8h12v3a6 6 0 0 1-12 0zM12 17v4"/>',
  };
  const icon = k => '<svg viewBox="0 0 24 24">' + ICON[k] + '</svg>';

  // ---- views + router ----
  const views = {}, order = [];
  let leave = [];
  function view(id, def) { views[id] = def; order.push(id); }
  function onLeave(fn) { leave.push(fn); }
  function go(path) { location.hash = '#/' + path; }
  function nav() {
    let html = '', sec = null;
    order.forEach(id => { const v = views[id]; if (!v.nav) return;
      if (v.nav.sec !== sec) { sec = v.nav.sec; html += '<div class="nav-sec">' + sec + '</div>'; }
      const c = v.nav.count ? v.nav.count() : null;
      html += '<div class="nav-a" data-go="' + id + '">' + icon(v.nav.icon) + '<span>' + v.nav.label + '</span>' + (c && c.n ? '<span class="cnt ' + (c.cls || '') + '">' + c.n + '</span>' : '') + '</div>'; });
    $('#nav').innerHTML = html;
  }
  function route() {
    const parts = (location.hash.replace(/^#\/?/, '') || 'overview').split('/');
    const id = views[parts[0]] ? parts[0] : 'overview', v = views[id];
    leave.splice(0).forEach(f => { try { f(); } catch (e) { console.error(e); } });
    closeDrawer();
    $$('.nav-a').forEach(a => a.classList.toggle('on', a.dataset.go === id));
    $('#title').textContent = typeof v.title === 'function' ? v.title(parts[1]) : v.title;
    $('#crumb').textContent = v.sub || v.crumb || '';
    const page = $('#page'); page.innerHTML = ''; window.scrollTo(0, 0);
    try { v.render(page, parts[1], parts[2]); } catch (e) { console.error(e); page.innerHTML = '<div class="callout critical"><div><h4>This screen failed to render</h4><p>' + esc(e.message) + '</p></div></div>'; }
  }
  document.addEventListener('click', e => {
    const g = e.target.closest('[data-go]'); if (g) { go(g.dataset.go); return; }
    if (e.target.closest('[data-close]') || e.target.id === 'scrim') closeDrawer();
  });
  function start() {
    nav();
    window.LPUI.wireHeader();
    $('#clock').textContent = 'As of ' + tfmt(D.meta.now);
    $('#present').onclick = () => { $('.app').classList.toggle('present'); window.dispatchEvent(new Event('resize')); };
    window.addEventListener('hashchange', route); route();
  }
  function refresh() { LP.clearCache(); nav(); route(); }

  // ---- drawer / toast ----
  function drawer(title, sub, body) {
    $('#drawer').innerHTML = '<div class="drawer-h"><div><h3>' + title + '</h3><div class="note">' + (sub || '') + '</div></div><button class="xbtn" data-close>×</button></div><div class="drawer-b">' + body + '</div>';
    $('#drawer').classList.add('on'); $('#scrim').classList.add('on'); return $('#drawer');
  }
  function closeDrawer() { $('#drawer').classList.remove('on'); $('#scrim').classList.remove('on'); }
  let tt; function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 2600); }

  // ---- charts (Chart.js) ----
  const C = { ink: '#0f1b2d', mute: '#5b6b7f', grid: '#e9eef4', blue: '#1d4ed8', ok: '#15803d', warn: '#d97706', bad: '#dc2626', twin: '#6c4fd8', brand: '#0e7490', slate: '#94a3b8' };
  if (window.Chart) {
    Chart.defaults.font.family = getComputedStyle(document.body).fontFamily; Chart.defaults.font.size = 11.5; Chart.defaults.color = C.mute;
    Chart.defaults.plugins.legend.display = false; Chart.defaults.animation.duration = 350; Chart.defaults.maintainAspectRatio = false;
    Chart.defaults.elements.point.radius = 0; Chart.defaults.elements.point.hoverRadius = 4; Chart.defaults.elements.line.borderWidth = 2; Chart.defaults.elements.line.tension = 0.25;
    Chart.defaults.plugins.tooltip.backgroundColor = '#0f1b2d'; Chart.defaults.plugins.tooltip.padding = 9; Chart.defaults.plugins.tooltip.cornerRadius = 7; Chart.defaults.interaction = { mode: 'index', intersect: false };
  }
  const axes = (o) => Object.assign({ x: { grid: { display: false }, ticks: { maxTicksLimit: 8, maxRotation: 0 }, border: { color: C.grid } }, y: { grid: { color: C.grid }, border: { display: false }, ticks: { maxTicksLimit: 5 } } }, o || {});
  function chart(el, cfg) { const cv = document.createElement('canvas'); el.innerHTML = ''; el.appendChild(cv); const c = new Chart(cv, cfg); onLeave(() => c.destroy()); return c; }
  // horizontal reference line / shaded band plugin
  const refPlugin = { id: 'ref', afterDatasetsDraw(c, _, o) { if (!o || !o.items) return; const { ctx, chartArea: a, scales } = c; ctx.save();
    o.items.forEach(it => { if (it.y != null) { const y = scales[it.axis || 'y'].getPixelForValue(it.y); if (y < a.top || y > a.bottom) return; ctx.strokeStyle = it.color; ctx.setLineDash(it.dash || [5, 4]); ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(a.left, y); ctx.lineTo(a.right, y); ctx.stroke(); ctx.setLineDash([]); if (it.label) { ctx.fillStyle = it.color; ctx.font = '600 11px ' + Chart.defaults.font.family; ctx.textAlign = 'right'; ctx.fillText(it.label, a.right - 4, y - 5); } }
      if (it.x != null) { const x = scales.x.getPixelForValue(it.x); ctx.strokeStyle = it.color; ctx.setLineDash(it.dash || [5, 4]); ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(x, a.top); ctx.lineTo(x, a.bottom); ctx.stroke(); ctx.setLineDash([]); if (it.label) { ctx.fillStyle = it.color; ctx.font = '600 11px ' + Chart.defaults.font.family; ctx.textAlign = it.align || 'left'; ctx.fillText(it.label, x + (it.align === 'right' ? -5 : 5), a.top + 11); } } });
    ctx.restore(); } };
  if (window.Chart) Chart.register(refPlugin);
  function spark(vals, color, w, h) {            // tiny inline SVG sparkline
    w = w || 110; h = h || 28; const v = vals.filter(x => x != null); if (!v.length) return '';
    const mn = Math.min.apply(null, v), mx = Math.max.apply(null, v), r = mx - mn || 1;
    const pts = vals.map((x, i) => x == null ? null : [(i / (vals.length - 1)) * w, h - 3 - ((x - mn) / r) * (h - 6)]).filter(Boolean);
    return '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '"><polyline fill="none" stroke="' + color + '" stroke-width="1.7" stroke-linejoin="round" points="' + pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ') + '"/><circle cx="' + pts[pts.length - 1][0].toFixed(1) + '" cy="' + pts[pts.length - 1][1].toFixed(1) + '" r="2.6" fill="' + color + '"/></svg>';
  }
  function gauge(v, cls, size) {                 // health ring
    size = size || 74; const r = size / 2 - 6, c = 2 * Math.PI * r, col = cls === 'ok' ? C.ok : cls === 'critical' ? C.bad : C.warn;
    return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 ' + size + ' ' + size + '"><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke="#e9eef4" stroke-width="7"/><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke="' + col + '" stroke-width="7" stroke-linecap="round" stroke-dasharray="' + (c * v / 100).toFixed(1) + ' ' + c.toFixed(1) + '" transform="rotate(-90 ' + size / 2 + ' ' + size / 2 + ')"/><text x="50%" y="54%" text-anchor="middle" dominant-baseline="middle" font-size="' + (size * 0.3) + '" font-weight="700" fill="#0f1b2d">' + Math.round(v) + '</text></svg>';
  }
  const kpi = (lab, val, ctx, cls) => '<div class="card kpi ' + (cls || '') + '"><div class="lab">' + lab + '</div><div class="val">' + val + '</div><div class="ctx">' + (ctx || '') + '</div></div>';
  const card = (title, sub, body, right, cls) => '<div class="card ' + (cls || '') + '"><div class="card-h"><div><h3>' + title + '</h3>' + (sub ? '<div class="sub">' + sub + '</div>' : '') + '</div>' + (right || '') + '</div><div class="card-b">' + body + '</div></div>';

  window.LPUI = { $, $$, esc, num, inr, inrK, pct, dfmt, tfmt, pill, ST, C, view, go, start, refresh, onLeave, drawer, closeDrawer, toast, chart, axes, spark, gauge, kpi, card, icon };
})();
