@echo off
cd /d "%~dp0web"
echo LabPulse V2 running at http://127.0.0.1:8765  (close this window to stop)
start "" http://127.0.0.1:8765
python -m http.server 8765 --bind 127.0.0.1
