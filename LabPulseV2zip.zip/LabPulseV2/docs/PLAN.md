# LabPulse V2 — solution plan

## Positioning

Not "two models that predict failure and expiry". An operating layer for the laboratory that links equipment state, reagent stability and stores, across analyzer vendors. The three things to be remembered for: stability-aware reagent twin, maintenance and reagents decided together, honesty about model limits.

## How the build maps to the scoring

| Criterion (weight) | Where it shows |
|---|---|
| Healthcare problem relevance (20%) | District-hospital scenario, mixed fleet, cold-chain power cut, short-dated deliveries |
| Innovation and use of AI (20%) | Per-analyzer baselines, calibrated risk, life ranges, forecast feeding rule-based twins, cross-module decision engine, 3D twin |
| Technical feasibility and demo quality (20%) | Working app, real trained models, reproducible pipeline, simulator reveal |
| Impact and inclusivity (15%) | Savings ledger; value from a barcode scan and LIS export; offline-first, phone-first |
| Responsible data use, safety, fairness (15%) | Model evidence screen, no patient data, human approval, audit trail, prototype labels |
| Scalability and adoption (10%) | Adoption path: three data levels, roll-out steps, network scaling |

## Built

- Synthetic generator: 40 analyzers, 540 days, six failure modes, and the conditions that break such models in practice.
- Failure-risk model with chronological evaluation, baselines, stress tests, operating curve.
- Demand forecast with hold-out comparison against two simpler methods.
- Reagent digital twin with separate manufacturer clocks, burn-down, loss range, pre-load advisor.
- Cold-chain stores: temperature logs, per-lot excursion budgets, bin map, reorder points, pack-size choice, traceability, goods-receipt check.
- Decision engine: service window, routing, reagent protection, cost comparison, approval, ground-truth reveal.
- Savings back-test with editable assumptions.
- 3D analyzer twin and laboratory floor.

## Not built (say so if asked)

- No backend, database, login or real integrations; the app reads one generated data file.
- No live sensor feed; telemetry is replayed from the simulator.
- Multi-site stock transfer is described, not implemented.
- Alerts by SMS or WhatsApp and local-language text are design intent only.
- The earlier .NET LabPulse/AssetPulse modules are not wired in.

## If there is time before the presentation

1. Clinical expert reviews the assay list, stability framing and wording of every recommendation.
2. Rehearse the walk-through twice on the presentation laptop.
3. Optional: a second site to show stock transfer; a phone-sized "scan a kit" screen.

## After the hackathon

Pilot with two or three laboratories on their own discard and breakdown records; load real package-insert rules; LIS export connector; retrofit sensor gateway; validate the risk model per site before switching it on.
