# LabPulse — demo script and jury Q&A

Start with `run-demo.bat` (opens http://localhost:8765). Press **Present** to hide the side menu on a projector. Run through once before presenting; the 3D views need a few seconds on first load.

## Five-minute walk-through

**1. Command centre (40 s).** "It is 6 am at a district hospital laboratory. Three analyzers from three vendors. LabPulse has one ranked list for the day." Point at the 3D floor: BA-01 red, BA-03 amber, BA-02 green. Read the top two actions aloud.

**2. Analyzer twin, BA-01 (60 s).** Click BA-01 on the floor. Rotate the model; the sample probe is pulsing. "Aspiration pressure is 4.5 sigma below this analyzer's own baseline. Remaining life is 3 to 11 days. We give a range, not a date." Click **See inside** and **Exploded view**. Point at the electronics row: "Not observable. We do not claim to predict what gives no warning."

**3. Reagent twin (75 s). This is the centrepiece.** Click a reagent bottle on the 3D carousel, or open Reagent twins. CRP lot: 400 tests left, 6 days of on-board stability, 45 days to expiry. "Demand will draw 293. 97 tests, ₹2,727, will be discarded." Show the burn-down chart stopping short of zero. Scroll to the clocks: each manufacturer rule is separate. Then the advisor: "A technician scans a new kit. LabPulse says hold: opening now wastes ₹9,327." Finish on **Check any bottle** with the brief's numbers, then switch to **Kit is still sealed**: 400 usable, where an earliest-date rule would write off 130.

**4. Decision engine (60 s).** Open the coordinated plan for BA-01. Five steps: service window, re-routing, reagent holds, stores, approval. "₹33,740 unplanned against ₹6,138 planned." Click **Reveal what actually happens**: the simulator fails the probe on 23 Nov; the plan serviced it 1.7 days earlier. Click **Approve**. Switch to BA-03: refrigeration drift, and the engine re-routes only the assays where total loss goes down.

**5. Cold chain (30 s).** LF-2 power-cut spike; one lot quarantined, one still inside its allowance. Reorder table: HDL has 6 days of cover against a 12-day lead time.

**6. Savings, then Model evidence (45 s).** Move the realisation slider. Then: "Here is where the model fails." Stress-test table, the leakage row (0.86 against an honest 0.53), 1 of 5 electronics failures.

Close: "Vendor-agnostic, useful from a barcode scan and an LIS export, and it tells you what it cannot do."

## Likely questions

**"Your data is synthetic. Why believe 79%?"** Do not defend the number. It shows the evaluation method: chronological split, event-level scoring, false alarms per analyzer. A pilot replaces the data, not the method. The reagent twin is rule-based and needs no training data at all.

**"Roche, Siemens and Abbott already do predictive maintenance."** For their own analyzers, for their service teams. LabPulse serves the laboratory in-charge across a mixed fleet and ties equipment state to reagent stability and stores. This is a positioning hypothesis; we have not benchmarked their products.

**"Where do the stability rules come from?"** From each reagent's package insert, entered once per reagent. The values in the demo are illustrative. A model never extends a stability claim.

**"How do you get telemetry from a closed analyzer?"** Three levels: CSV and barcode; LIS or middleware counts and error codes; external clip-on sensors. Nothing is connected inside the analyzer.

**"False alarms?"** About one per analyzer every 7 months at the chosen threshold; 52% of alerts were real degradation. Each alert names its signals so a bad sensor can be dismissed.

**"Is the 86% waste reduction real?"** It is a simulation against an assumed baseline, which is why the headline saving is halved and the slider is on screen. The mechanism is real: pack size matched to demand, fewer loaded positions, weekly ordering.

**"Patient safety and privacy?"** No patient data. Operational recommendations only, human approval, audit trail, no analyzer setting is ever changed.

**"Who pays?"** Start with private chains and mid-size hospitals where the saving is direct; state procurement for district hospitals later; service companies and distributors as a channel.

## Before presenting

- Fill in the team section of `ONE-PAGE-SUMMARY.md`.
- Have the clinical expert confirm the assay list and stability framing; say on stage that values are illustrative.
- Chrome or Edge, 100% zoom, 1600 px wide or more.
