# LabPulse — one-page summary

**UDBHAV 1.0 · Theme: Operational Efficiency of Healthcare Organisations**
**Problem statement: Diagnostic Lab Equipment Downtime & Reagent Wastage Predictor**

*Prototype. Synthetic data only. Not clinically validated or approved.*

## The problem

A district hospital laboratory loses testing two ways. A biochemistry analyzer stops without warning, and reagent is thrown away because it expired or outlived its on-board stability. The two are linked: a reagent bottle's clock keeps running while the analyzer it sits on is down, and a failing refrigeration unit voids the stability of every bottle in the bay before the analyzer itself stops. Alarm panels and stock registers each see half of this.

## What we built

One working application with three engines that share the same state.

1. **Reagent digital twin.** Every lot carries its manufacturer rules as separate clocks: printed expiry, on-board stability, open-vial stability, calibration interval, temperature-excursion allowance. Only the clocks that are running for the lot's current state apply. For the example in the brief (400 tests left, 45 a day, 6 days on board, 45 days to expiry) the twin reports 270 usable and 130 lost, and warns before another kit is opened. For the same kit still sealed it reports all 400 usable; a rule that takes the earliest date would wrongly write off 130.
2. **Predictive maintenance.** A gradient-boosted model scores each analyzer every 6 hours against that analyzer's own baseline, names the signals that moved, and gives remaining life as a range per sub-assembly, shown on a 3D twin of the analyzer.
3. **Decision engine.** One alert becomes one plan: the least disruptive service window, where each assay is re-routed, which reagent not to open, what to order, and the rupee difference between a planned and an unplanned stop. A person approves it.

Also included: cold-chain stores (temperature logs, excursion budgets per lot, bin map, reorder points from consumption patterns, batch traceability) and a savings ledger with editable assumptions.

## Results on synthetic data

| | |
|---|---|
| Failures warned in advance, held-out period | 26 of 33 (79%) |
| Typical warning | 6.4 days |
| False alarms | about one per analyzer every 7 months |
| Sudden electronics failures caught | 1 of 5 — no precursor exists, and the product says so |
| Demand forecast error, 7 days ahead | 18.9% WAPE (seasonal naive 29.4%) |
| Reagent loss in a 12-month policy back-test | 11.8% → 2.2% of purchases |
| Modelled saving for one laboratory | about ₹8.8 lakh a year after a 50% realisation factor |

## Approach

Four synthetic datasets from a seeded generator: 518,440 hourly telemetry rows for 40 analyzers of three models, 87 failures across six failure modes, 8,640 daily test-volume rows for 16 assays, 107 reagent lots. The generator includes what breaks such models in practice: rare failures (3.4% of readings), sensor drift that mimics wear, stuck and missing readings, benign error bursts, baseline shifts after service, failures with no warning. Training, validation and test periods are strictly chronological. Stability and expiry are rules, never model outputs.

## Why it matters

It is vendor-agnostic, which suits mixed fleets in public laboratories. The reagent twin needs only LIS test counts and a barcode scan, so a laboratory gets value before any analyzer is connected. It is designed offline-first and phone-first for sites with weak connectivity.

## Limits

- All figures come from simulation. They show the method and its sensitivity; they are not evidence about real analyzers or real laboratories.
- Stability values are illustrative of typical package inserts, not taken from a named manufacturer. A deployment loads each insert's rules.
- The baseline "current practice" in the savings back-test is an assumption, stated on screen.
- Real analyzer telemetry is often proprietary; the prototype assumes external sensors and LIS exports.
- No patient data is used or needed. The tool gives operational recommendations only and never changes an analyzer setting.

## What existed before

Earlier LabPulse / AssetPulse work by the team (asset registry, work orders, rules-based health score) was used as a blueprint only. Everything described above was built for UDBHAV. Open-source components: scikit-learn, pandas, NumPy, SciPy, three.js, Chart.js.

## Team

*Add team members, roles and the clinical expert's name and registration number here.*
